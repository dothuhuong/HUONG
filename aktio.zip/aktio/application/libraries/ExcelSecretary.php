<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');
set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * AKTIO代表幹事とAKTIOツアー担当者のエクスポート専用ファイルを作成する
 * @author VienCQ
 */
class ExcelSecretary extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    
    public function createSecretaryFile($courseData , $userData, $type,$kubun) {
        date_default_timezone_set('Asia/Tokyo');
        // 初期化
        $CI = & get_instance();
        $CI->load->model('operating_mo');
        
        // エックセルテンプレートオブジェクト作成
        //20170412 catnhp MODIFY_S change template
        if ($type == 2) {
			 if ($kubun == 1) {
				$objPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Excel_Secretary_OrderByRoom.xlsx");
			 } else{
				 $objPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Excel_Secretary_OrderByRoom_2.xlsx");
			 }
        }else {
			 if ($kubun == 1) {
				$objPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Excel_Secretary.xlsx");
			 }else{
				$objPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Excel_Secretary_2.xlsx");
			 }
        }
        //20170412 catnhp MODIFY_E change template
        //+++++++++++++++++++++++++++++++ Sheet 1 +++++++++++++++++++++++++++++++++++++
        // 0番目のシートをアクティブにします(シートは0から数えます)
        // (エクセルを新規作成した時点で0番目の空のシートが作成されています)
        $objPHPExcel->setActiveSheetIndex(0);
        // アクティブにしたシートの情報を取得(現在のシートを指定します)
        $objSheet = $objPHPExcel->getActiveSheet();
        // シートに名前を付けます
        $objSheet->setTitle("幹事作業用リスト");
        // セルに値をセットする
        $this->createContentSheet($courseData, $userData , $objSheet);
        
        // ファイルダウンロードする
        $filename='幹事作業用リスト' . '_' . date("Ymdhis") . '.xlsx';
        header("Content-Type: application/octet-stream");//ダウンロードの指示
        header('Content-Disposition: attachment;filename="'.$filename.'"');
        header('Cache-Control: max-age=0'); //no cache
        ob_end_clean();//ファイル破損エラー防止
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit;
    }
    
    private function createContentSheet($courseData, $userData ,PHPExcel_Worksheet $objSheet) {
        $this->createHeader($courseData , $objSheet);
        $this->createContent($userData , $objSheet);
    }
    
    private function createHeader($courseData , PHPExcel_Worksheet $objSheet) {
        $CI =& get_instance();
        $CI->load->library('convert_format');
        // コース氏名
        if (isset($courseData['M01_Course_Name-R'])) {
            $courseNameArr  = explode('　', $courseData['M01_Course_Name-R']);
            $courseNameStr  = '';
            $courseNameStr .= !empty($courseNameArr[0])?$courseNameArr[0]:'●●コース';
            $courseNameStr .= !empty($courseNameArr[1])?('　【' . $courseNameArr[1] . '】'):'　【●班】';
            $objSheet->setCellValue('A2', $courseNameStr);
        }
        // コース日付
        if (isset($courseData['M01_Dep_Date']) && isset($courseData['M01_Arr_Date'])) {
            $depStr = $CI->convert_format->ChangeJpDay($courseData['M01_Dep_Date']);
            $arrStr = $CI->convert_format->ChangeJpDay($courseData['M01_Arr_Date']);
            $dep_arr = $depStr . '　　～　　' . $arrStr;
            $objSheet->setCellValue('A3', $dep_arr);
        }
        // 往路フライト
        $go_air = isset($courseData['M011_Go_Air'])?('往路フライト：' . $courseData['M011_Go_Air']):'往路フライト：';
        $objSheet->setCellValue('A4', $go_air);
        $rtn_air = isset($courseData['M011_Rtn_Air'])?('往路フライト：' . $courseData['M011_Rtn_Air']):'往路フライト：';
        $objSheet->setCellValue('D4', $rtn_air);
    }
    
    private function createContent($userData , PHPExcel_Worksheet $objSheet) {
        $i = 7;
        $index = 1;
        foreach ($userData as $user) {
            if ($i == (count($userData) + 7)) break;
            //パーティー卓割
            // index
            $objSheet->setCellValue('B' . $i , $index);
            // IDNo.
            $id_1 = isset($user['R01_Id'])?$user['R01_Id']:'';
            $id_2 = isset($user['R01_Plan'])?($user['R01_Plan']+1):'';
            $id = $id_1 . '-' . $id_2;
            $objSheet->setCellValue('C' . $i , $id);
            // 会社名
            $company = isset($user['R00_Company'])?$user['R00_Company']:'';
            $objSheet->setCellValue('D' . $i , $company);
            // 所属部署
            $division = isset($user['R00_Division'])?$user['R00_Division']:'';
            $objSheet->setCellValue('E' . $i , $division);
            // 役割 (まだ処理していません)
            $role = isset($user['R01_Role'])?$user['R01_Role']:'';
            $objSheet->setCellValue('F' . $i , $role);
            // 同グループ代表者
            $daihyou_name = isset($user['R00_Group_Daihyo_Name'])?$user['R00_Group_Daihyo_Name']:'';
            $objSheet->setCellValue('G' . $i , $daihyou_name);
            // 氏  名
            $kanji_sei = isset($user['R01_Sei'])?$user['R01_Sei']:'';
            $objSheet->setCellValue('H' . $i , $kanji_sei);
            $kanji_name = isset($user['R01_Name'])?$user['R01_Name']:'';
            $objSheet->setCellValue('I' . $i , $kanji_name);
            // NAME
			if($user['R00_Dest_Kbn']==1){
				$roma_sei = isset($user['R01_Passport_Sei'])?$user['R01_Passport_Sei']:'';
				$roma_name = isset($user['R01_Passport_Name'])?$user['R01_Passport_Name']:'';
			}else{
				$roma_sei = isset($user['R01_Sei_Kana'])?$user['R01_Sei_Kana']:'';
				$roma_name = isset($user['R01_Name_Kana'])?$user['R01_Name_Kana']:'';
			}
            $objSheet->setCellValue('J' . $i , $roma_sei);
            $objSheet->setCellValue('K' . $i , $roma_name);
            
            // 性別
            $sex = '';
            if (isset($user['R01_Sex'])) {
                if ($user['R01_Sex'] == 1) {
                    $sex = 'M';
                } elseif ($user['R01_Sex'] == 2) {
                    $sex = 'F';
                } else {
                    $sex = '';
                }
            }
            $objSheet->setCellValue('L' . $i , $sex);
            // 生年月日
            $birth_day = isset($user['R01_Birthday'])?date('Y/m/d' , strtotime($user['R01_Birthday'])):'';
            $objSheet->setCellValue('M' . $i , $birth_day);
            // 部屋割り
            $room_type = isset($user['R01_RoomType'])?$user['R01_RoomType']:'';
            $objSheet->setCellValue('N' . $i , $room_type);
			// 一人部屋希望
			if($user['R01_Plan'] == 0){
				$R00_1Room_wish = isset($user['R00_1Room_wish'])?$user['R00_1Room_wish']:'';				
			}else{
				$R00_1Room_wish = '';
			}
            $objSheet->setCellValue('O' . $i , $R00_1Room_wish);
			// バス号車割り
            $bus_start = isset($user['R01_Bus_Start'])?$user['R01_Bus_Start']:'';
            $objSheet->setCellValue('P' . $i , $bus_start);
			// バス最終日号車
            $bus_end = isset($user['R01_Bus_End'])?$user['R01_Bus_End']:'';
            $objSheet->setCellValue('Q' . $i , $bus_end);
            // パーティー卓割:テーブル
            $party_table = isset($user['R01_Party_Table'])?$user['R01_Party_Table']:'';
            $objSheet->setCellValue('R' . $i , $party_table);
            // パーティー卓割:席
            $party_seat = isset($user['R01_Party_Seat'])?$user['R01_Party_Seat']:'';
            $objSheet->setCellValue('S' . $i , $party_seat);
           
           
            // 50周年記念イベント (R08_Course_Event_Reserve参照)
            $kinen = '';
            if (isset($user['R08_Reserve'])) {
                if ($user['R08_Reserve'] == 0) {
                    $kinen = '不参加';
                } elseif ($user['R08_Reserve'] == 1) {
                    $kinen = '参加';
                } else {
                    $kinen = '';
                }
            }
            $objSheet->setCellValue('T' . $i , $kinen);
            /*// Remarks
            $remarks = isset($user['R01_Remarks_Rooming'])?$user['R01_Remarks_Rooming']:'';
            $objSheet->setCellValue('T' . $i , $remarks);*/
			 // 管理者備考
            $note = isset($user['R00_Admin_Note'])?$user['R00_Admin_Note']:'';
            $objSheet->setCellValue('U' . $i , $note);
			$note2 = isset($user['R00_allergy_Note'])?$user['R00_allergy_Note']:'';
            $objSheet->setCellValue('V' . $i , $note2);
			 // 氏  名
			 if($user['R00_Dest_Kbn']== 2 ){
				$eng_sei = isset($user['R01_Sei_Eng'])?$user['R01_Sei_Eng']:'';
				$objSheet->setCellValue('W' . $i , $eng_sei);
				$eng_name = isset($user['R01_Name_Eng'])?$user['R01_Name_Eng']:'';
				$objSheet->setCellValue('X' . $i , $eng_name);
			 }
            $i++;
            $index++;
        }
        
        // $userNums = count($userData);
        // $this->setStyleSheet($userNums , $objSheet);
    }
    
    /**
     * 古いテンプレート対応
     * 元々はテンプレートの31行のみ使えるので、31行以外のデーターはテンプレートのスタイルを壊れた。
     * このメッソドは上の状況に対応する方
     * @param int $userNums 人数
     * @param PHPExcel_Worksheet $objSheet 現在シート
     */
    private function setStyleSheet($userNums , PHPExcel_Worksheet $objSheet) {
        $rowIndexs = array(
                'A' , 'B' , 'C' , 'D' , 'E' , 'F' , 'G' , 'H' ,
                'I' , 'J' ,'K' , 'L' , 'M' , 'N' , 'O' , 'P' ,
                'Q' , 'R' , 'S' , 'T'
        );
        
        /*
        $style1 = array(
            'borders' => array(
                'top'     => array('style' => PHPExcel_Style_Border::BORDER_THIN),
                'bottom'  => array('style' => PHPExcel_Style_Border::BORDER_THIN),
                'left'    => array('style' => PHPExcel_Style_Border::BORDER_THIN),
                'right'   => array('style' => PHPExcel_Style_Border::BORDER_THIN)
            )
        );
        */
        
        for ($i = 7 ; $i < 6 + $userNums ; $i++) {
            foreach ($rowIndexs as $rowIndex) {
                $objSheet->getStyle($rowIndex . $i)->getFont()->setSize(11);
                $objSheet->getStyle($rowIndex . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objSheet->getStyle($rowIndex . $i)->applyFromArray(array('font' => array('bold' => false)));
                
                if ($i > 37) {
                    $objSheet->duplicateStyle($objSheet->getStyle($rowIndex . '7') , $rowIndex . $i);
                    //$objSheet->getColumnDimension($rowIndex)->setAutoSize(true);
                }
            }
            $h = $objSheet->getRowDimension(36)->getRowHeight();
            if ($i > 36) {
                $objSheet->getRowDimension($i)->setRowHeight($h);
            }
        }
    }
}