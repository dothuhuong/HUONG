<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * ETASエクセルファイル作成クラス
 * @author THAI
 */
class ExcelETAS extends PHPExcel
{
    public function __construct() {
        parent::__construct();
 
    }

    public function excel_etas_info($etasData , $plan) {
        // 初期化
        $CI = & get_instance();
        $CI->load->model('menu_mo');
        $CI->load->library('convert_format');
        // エックセルテンプレートオブジェクト作成
        $tempObjPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/ETAS_info.xlsx");

        //+++++++++++++++++++++++++++++++ Sheet  +++++++++++++++++++++++++++++++++++++
        // 0番目のシートをアクティブにします(シートは0から数えます)
        // (エクセルを新規作成した時点で0番目の空のシートが作成されています)
        $tempObjPHPExcel->setActiveSheetIndex(0);
        // アクティブにしたシートの情報を取得(現在のシートを指定します)
        $objSheet1 = $tempObjPHPExcel->getActiveSheet();
        // シートに名前を付けます
        $objSheet1->setTitle("オーストラリアETAS登録手続きのための質問書");
        // セルに値をセットする
        $this->createContentSheet($etasData, $objSheet1);

        if ($plan == 0) {
            $personType = 1;
        } else {
            $personType = $plan + 1;
        }
        $personTypeName = mb_convert_encoding($personType, 'sjis-win', 'UTF-8');
        $filename = 'ETAS_' . $etasData['R01_Id'] . '_' . $personTypeName . '_' . date("Ymdhis") . '.xlsx';
        $objWriter = PHPExcel_IOFactory::createWriter($tempObjPHPExcel, 'Excel2007');
        // ob_clean();
        // $objWriter->save($filename);
        $objWriter->save(APPPATH . 'excel_data/' . $filename);
        // $objWriter->save('/var/www/nssproduct/html10/excel_data/'.$filename);
        return $filename;
    }

    private function createContentSheet($etasData ,PHPExcel_Worksheet $objSheet) {
    	// 本人
    	$CI = & get_instance();
    	$CI->load->model('menu_mo');
    	$CI->load->library('convert_format');
    	$objSheet->setCellValue('D11', $this->getFullNameKanji($etasData));
    	$objSheet->getStyle('D11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    	$objSheet->getStyle('D11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    	$objSheet->getStyle('D11')->getFont()->setSize(14);
    	
    	//出発日
    	if (isset($etasData['M01_Dep_Date'])){
    		
    		$objSheet->setCellValue('L11', $CI->convert_format->ChangeJpDay_NoDayOfWeek($etasData['M01_Dep_Date'] ));
    	}
    	
    	//国籍
    	if (isset($etasData['R10_National'])) {
    		$objSheet->setCellValue('D13', $etasData['R10_National']);
    	}
    	
    	//出征国
    	if (isset($etasData['R10_Country_Birth'])){
    		$objSheet->setCellValue('L13',$etasData['R10_Country_Birth']);
    	}
    	
    	//その他国籍
    	$national = $objSheet->getCell('D15')->getValue();    	
    	if (isset($etasData['R10_Other_National'])){
    		if ($etasData['R10_Other_National_Flag']==1){
    			$objSheet->setCellValue('D15',str_replace("あり（　　　　　　　　　　　　　　　　　　　　　　　　　）", "　■あり".'('.$etasData['R10_Other_National'].')', $national));
    		}
    		//elseif (($etasData['R10_Other_National_Flag']==0)){
			else{
    			$objSheet->setCellValue('D15',str_replace("なし", "■なし", $national));
    		}
    	}else{
    			$objSheet->setCellValue('D15',str_replace("なし", "■なし", $national));
    	}
    	
    	//旧姓、または別姓（英字）
    	$betsusei = $objSheet->getCell('D17')->getValue();
    	if (isset($etasData['R10_BetsuSei'])){
    		if ($etasData['R10_Betsusei_Flag']==1){
    			$objSheet->setCellValue('D17',str_replace("あり（　　　　　　　　　　　　　　　　　　　　　　　　　）", "　■あり".'('.$etasData['R10_BetsuSei'].')', $betsusei));
    		}
    		//elseif (($etasData['R10_Betsusei_Flag']==0)){
			else{
    			$objSheet->setCellValue('D17',str_replace("なし", "■なし", $betsusei));
    		}
    	}else{
    			$objSheet->setCellValue('D17',str_replace("なし", "■なし", $betsusei));
    	}
    	
//     	$betsusei = !empty($etasData['R10_BetsuSei'])?$etasData['R10_BetsuSei']:$etasData['R10_BetsuMei'];
//     	$betsusei_str = $objSheet->getCell('D17')->getValue();
//     	if (isset($betsusei)){
//     		if ($etasData['R10_Betsusei_Flag']==1){
//     			$objSheet->setCellValue('D17',str_replace("あり（　　　　　　　　　　　　　　　　　　　　　　　　　）", "■あり".'('.$betsusei.')', $betsusei_str));
//     		}elseif ($etasData['R10_Betsusei_Flag']==0){
//     			$objSheet->setCellValue('D17',str_replace("なし", "■なし", $betsusei_str));
//     		}
//     	}
    	//現住所
    	$address = $objSheet->getCell('D19')->getValue();
    	if (!empty($etasData['R10_Post1'])||!empty($etasData['R10_Post2'])){
    		$objSheet->setCellValue('D19',$address.$etasData['R10_Post1']."-".$etasData['R10_Post2']);
    	}	
    	$fullAddress = $objSheet->getCell('D20')->getValue();
    	if (!empty($etasData['R10_Address1'])||!empty($etasData['R10_Address2'])||!empty($etasData['R10_Address3'])){
    		$objSheet->setCellValue('D20',$fullAddress.$etasData['R10_Address1']." ".$etasData['R10_Address2']." ".$etasData['R10_Address3']);
    	}
    	
//     	if (!empty($etasData['R10_Address2'])||!empty($etasData['R10_Address3'])){
//     		$objSheet->setCellValue('J20',$etasData['R10_Address1'].$etasData['R10_Address2']);
//     	}
    	//電話番号
    	$contact = $objSheet->getCell('D21')->getValue();
    	if (!empty($etasData['R10_Contact_No'])){
    		$objSheet->setCellValue('D21',$contact.$etasData['R10_Contact_No']);
    		$objSheet->getStyle('D21')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
    	}
    	$contactFlg = $objSheet->getCell('D22')->getValue();
    	if (!empty($etasData['R10_Contact_Flag'])){
    		if ($etasData['R10_Contact_Flag']==1){
    			$objSheet->setCellValue('D22',str_replace("自宅", "■自宅", $contactFlg));
    		}
    		
    		elseif ($etasData['R10_Contact_Flag']==2){
    			$objSheet->setCellValue('D22',str_replace("携帯", "■携帯", $contactFlg));
    		}
    		
    		elseif ($etasData['R10_Contact_Flag']==3){
    			$objSheet->setCellValue('D22',str_replace("勤務先", "■勤務先", $contactFlg));
    		}
    		
    	}
    	//以下の項目のいずれかに該当しますか。
    	$etasElse = $objSheet->getCell('A25')->getValue();
    	if (isset($etasData['R10_EtasElse_flag'])){
    		if ($etasData['R10_EtasElse_flag']==0){
    		$objSheet->setCellValue('A25',str_replace("□いいえ", "■いいえ", $etasElse));
    		}
    		elseif ($etasData['R10_EtasElse_flag']==1){
    			$objSheet->setCellValue('A25',str_replace("□はい", "■はい", $etasElse));
    		}
    	}
    	
    	// 本人
    	$shomei = $objSheet->getCell('D35');
    	$objSheet->setCellValue('D35', str_replace("名前", "名前"." : ".$this->getFullNameKanji($etasData),$shomei));
    	$objSheet->setCellValue('D35', str_replace("記入日　　　　　　　　年　　　　月　　　　日", "記入日"." : ".$CI->convert_format->ChangeJpDay_NoDayOfWeek($etasData['R10_Create_Date']),$shomei));
    	
    	$objSheet->getStyle('D35')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    	$objSheet->getStyle('D35')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    	$objSheet->getStyle('D35')->getFont()->setSize(14);
    	
    	
    	if (!empty($etasData['R10_Id'])){
    		$objSheet->setCellValue('D37',$etasData['R10_Id']);
    		$objSheet->getStyle('D37')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
    	}
    	
    	
    }
    private function getFullFurigana($etasData) {
        $fullName = '';
        if (isset($etasData['R00_Sei_Kana']) && isset($etasData['R00_Name_Kana'])) {
            $fullName .= $etasData['R00_Sei_Kana'];
            $fullName .= " ";
            $fullName .= $etasData['R00_Name_Kana'];
        } else {
            if (isset($etasData['R01_Sei_Kana']) && isset($etasData['R01_Name_Kana'])) {
                $fullName .= $etasData['R01_Sei_Kana'];
                $fullName .= " ";
                $fullName .= $etasData['R01_Name_Kana'];
            }
        }
        $fullNameConvert = $str = mb_convert_kana($fullName ,"cH","UTF-8");
        return $fullNameConvert;
    }

    private function getFullNameKanji($etasData) {
        $fullName = '';
        if (isset($etasData['R00_Sei']) && isset($etasData['R00_Name'])) {
            $fullName .= $etasData['R00_Sei'];
            $fullName .= " ";
            $fullName .= $etasData['R00_Name'];
        } else {
            if (isset($etasData['R01_Sei']) && isset($etasData['R01_Name'])) {
                $fullName .= $etasData['R01_Sei'];
                $fullName .= " ";
                $fullName .= $etasData['R01_Name'];
            }
        }
        return $fullName;
    }

    private function getCurrentDate() {
        $today = date('Y年m月d日');
        return $today;
    }

}