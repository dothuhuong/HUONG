<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * CNMIエクセルファイル作成クラス
 * @author THAI
 */
class ExcelCNMI extends PHPExcel
{
    public function __construct() {
        parent::__construct();
 
    }

    public function excel_cnmi_info($cnmiData , $plan) {
        // 初期化
        $CI = & get_instance();
        $CI->load->model('menu_mo');
        $CI->load->library('convert_format');
        // エックセルテンプレートオブジェクト作成
        $tempObjPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/CNMI_info.xlsx");

        //+++++++++++++++++++++++++++++++ Sheet  +++++++++++++++++++++++++++++++++++++
        // 0番目のシートをアクティブにします(シートは0から数えます)
        // (エクセルを新規作成した時点で0番目の空のシートが作成されています)
        $tempObjPHPExcel->setActiveSheetIndex(0);
        // アクティブにしたシートの情報を取得(現在のシートを指定します)
        $objSheet1 = $tempObjPHPExcel->getActiveSheet();
        // シートに名前を付けます
        $objSheet1->setTitle("ビザ免除プログラムを利用した無査証入国の為の質問書");
        // セルに値をセットする
        $this->createContentSheet($cnmiData, $objSheet1);

        if ($plan == 0) {
            $personType = 1;
        } else {
            $personType = $plan + 1;
        }
        $personTypeName = mb_convert_encoding($personType, 'sjis-win', 'UTF-8');
        $filename = 'CNMI' . $cnmiData['R01_Id'] . '_' . $personTypeName . '_' . date("Ymdhis") . '.xlsx';
        $objWriter = PHPExcel_IOFactory::createWriter($tempObjPHPExcel, 'Excel2007');
        // ob_clean();
        // $objWriter->save($filename);
        $objWriter->save(APPPATH . 'excel_data/' . $filename);
        // $objWriter->save('/var/www/nssproduct/html10/excel_data/'.$filename);
        return $filename;
    }

    private function createContentSheet($cnmiData ,PHPExcel_Worksheet $objSheet) {
    	$CI = & get_instance();
    	$CI->load->model('menu_mo');
    	$CI->load->library('convert_format');
    	//質問1
    	$pass_anq_a_str = $objSheet->getCell('A18')->getValue();
    	if (isset($cnmiData['R11_CNMIPast'])){
    		if ($cnmiData['R11_CNMIPast']==0){
    			$objSheet->setCellValue('A18',str_replace("□いいえ", "■いいえ", $r11_anq_a_str));
    		}
    		elseif ($cnmiData['R11_CNMIPast']==1){
    			$objSheet->setCellValue('A18',str_replace("□はい", "■はい", $r11_anq_a_str));
    		}
    		
    	}
    	
    	//申請場所
    	$register_place_str = $objSheet->getCell('C19')->getValue();
    	if(!empty($cnmiData['R11_Register_Place'])){
    		if ($cnmiData['R11_Register_Place']==1){
    			$objSheet->setCellValue('C19',str_replace("□東京", "■東京", $register_place_str));
    		}
    		elseif ($cnmiData['R11_Register_Place']==2)
    		{
    			$objSheet->setCellValue('C19',str_replace("□大阪", "■大阪", $register_place_str));
    		}
    		elseif ($cnmiData['R11_Register_Place']==3)
    		{
    			$objSheet->setCellValue('C19',str_replace("□那覇", "■那覇	", $register_place_str));
    		}
    		elseif ($cnmiData['R11_Register_Place']==4)
    		{
    			$objSheet->setCellValue('C19',str_replace("□札幌", "■札幌", $register_place_str));
    		}
    		elseif ($cnmiData['R11_Register_Place']==5)
    		{
    			$objSheet->setCellValue('C19',str_replace("□福岡", "■福岡", $register_place_str));
    		}
    		elseif ($cnmiData['R11_Register_Place']==6)
    		{
    			$objSheet->setCellValue('C19',str_replace("□その他", "■その他"."(".$cnmiData['R11_Register_Place_Other'].")", $register_place_str));
    		}
    	}

    	//申請日
    	if (!empty($cnmiData['R11_CNMI_Issue'])){
    		$objSheet->setCellValue('C20', $CI->convert_format->ChangeJpDay_NoDayOfWeek($cnmiData['R11_CNMI_Issue']));
    	}
    	
    	//査証種別
    	$register_type_str = $objSheet->getCell('C21');
    	if(!empty($cnmiData['R11_Register_Type'])){
    		if ($cnmiData['R11_Register_Type']==1){
    			$objSheet->setCellValue('C21',str_replace("□観光（B-2）", "■観光（B-2）", $register_type_str));
    		}
    		
    		elseif ($cnmiData['R11_Register_Type']==2){
    			$objSheet->setCellValue('C21',str_replace("□商用（B-1）", "■商用（B-1）", $register_type_str));
    		}
    		elseif ($cnmiData['R11_Register_Type']==3){
    			$objSheet->setCellValue('C21',str_replace("□留学（F）", "■留学（F）", $register_type_str));
    		}
    		elseif ($cnmiData['R11_Register_Type']==4){
    			$objSheet->setCellValue('C21',str_replace("□その他", "■その他"."(".$cnmiData['R11_Register_Type_Other'].")", $register_type_str));
    		}
    	}
    	
    	//　査証交付
    	$issueResult_str = $objSheet->getCell('C22');
    	if (isset($cnmiData['R11_CNMI_IssueResult'])){
    		if ($cnmiData['R11_CNMI_IssueResult']==0){
    			$objSheet->setCellValue('C22',str_replace("□交付された", "■交付された", $issueResult_str));
    		}
    		elseif ($cnmiData['R11_CNMI_IssueResult']==1){
    			$objSheet->setCellValue('C22',str_replace("□交付されなかった", "■交付されなかった", $issueResult_str));
    		}
    	}
    	
    	//　一度交付された査証を取り消されたことがありますか：　□いいえ　□はい
    	$issueDelete_str = $objSheet->getCell('A23');
    	if (isset($cnmiData['R11_CNMI_IssueDelete'])){ 
    		if ($cnmiData['R11_CNMI_IssueDelete']==0){
    			$objSheet->setCellValue('A23',str_replace("□いいえ", "■いいえ", $issueDelete_str));
    		}
    		elseif ($cnmiData['R11_CNMI_IssueDelete']==1){
    			$objSheet->setCellValue('A23',str_replace("□はい", "■はい", $issueDelete_str));
    		}
    	}
    	//質問2
    	
    	$else_flag_str =$objSheet->getCell('A30');
    	if(isset($cnmiData['R10_CNMIElse_flag'])){
    		if ($cnmiData['R10_CNMIElse_flag']==0){
    			$objSheet->setCellValue('A30',str_replace("□いいえ", "■いいえ", $else_flag_str));
    		}
    		elseif ($cnmiData['R10_CNMIElse_flag']==1){
    			$objSheet->setCellValue('A30',str_replace("□はい", "■はい", $else_flag_str));
    		}
    	}
    	
    	// 本人
    	$r11_shomei_str = $objSheet->getCell('C43');
    	$objSheet->setCellValue('C43', str_replace("名前", "名前"." : ".$this->getFullNameKanji($cnmiData),$r11_shomei_str));
    	$objSheet->setCellValue('C43', str_replace("記入日　　　　　　　　年　　　　　　月　　　　　　日", "記入日"." : ".$CI->convert_format->ChangeJpDay_NoDayOfWeek($cnmiData['R11_Create_Date']),$r11_shomei_str));
    	 
    	$objSheet->getStyle('C43')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    	$objSheet->getStyle('C43')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
    	$objSheet->getStyle('C43')->getFont()->setSize(14);
    	
    	//社員番号
    	if (!empty($cnmiData['R11_Id'])){
    		$objSheet->setCellValue('C45',$cnmiData['R11_Id']);
    		$objSheet->getStyle('C45')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
    	}
    	
    	//出発日
    	if (isset($cnmiData['M01_Dep_Date'])){
    		$objSheet->setCellValue('C46', $CI->convert_format->ChangeJpDay_NoDayOfWeek($cnmiData['M01_Dep_Date'] ));
    	}
    	
    }
    private function getFullFurigana($cnmiData) {
        $fullName = '';
        if (isset($cnmiData['R00_Sei_Kana']) && isset($cnmiData['R00_Name_Kana'])) {
            $fullName .= $cnmiData['R00_Sei_Kana'];
            $fullName .= " ";
            $fullName .= $cnmiData['R00_Name_Kana'];
        } else {
            if (isset($cnmiData['R01_Sei_Kana']) && isset($cnmiData['R01_Name_Kana'])) {
                $fullName .= $cnmiData['R01_Sei_Kana'];
                $fullName .= " ";
                $fullName .= $cnmiData['R01_Name_Kana'];
            }
        }
        $fullNameConvert = $str = mb_convert_kana($fullName ,"cH","UTF-8");
        return $fullNameConvert;
    }

    private function getFullNameKanji($cnmiData) {
        $fullName = '';
        if (isset($cnmiData['R00_Sei']) && isset($cnmiData['R00_Name'])) {
            $fullName .= $cnmiData['R00_Sei'];
            $fullName .= " ";
            $fullName .= $cnmiData['R00_Name'];
        } else {
            if (isset($cnmiData['R01_Sei']) && isset($cnmiData['R01_Name'])) {
                $fullName .= $cnmiData['R01_Sei'];
                $fullName .= " ";
                $fullName .= $cnmiData['R01_Name'];
            }
        }
        return $fullName;
    }

    private function getCurrentDate() {
        $today = date('Y年m月d日');
        return $today;
    }

}