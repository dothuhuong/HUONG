<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 */
class ExcelAirNameList extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    /*
     *
     * air line name list
     */
    public function AirNameList($NameList) {
        date_default_timezone_set("Asia/Tokyo");
        $objPHPExcel = PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Air_NameList.xlsx");
        $objPHPExcel->setActiveSheetIndex(0);
        $objSheet = $objPHPExcel->getActiveSheet();
        $objSheet->setTitle("AirNameList");
        $this->createContentSheet($NameList, $objSheet);
        $filename = 'air_name_list.xlsx';
        header("Content-Type: application/octet-stream"); // ダウンロードの指示
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0'); // no cache
        ob_end_clean(); // ファイル破損エラー防止
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
    private function createContentSheet($NameList, PHPExcel_Worksheet $objSheet) {
        $CI = & get_instance();
        $CI->load->library('convert_format');
        $Course = $NameList['CourseDataMaster'];
        $Travelers = $NameList['SearchResult'];
        // コース名
        $objSheet->setCellValue('B2', $Course['M01_Course_Name']);
        $objSheet->getStyle('B2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        //
        $M01_Dep_Date = $CI->convert_format->ChangeJpDay($Course['M01_Dep_Date']);
        $M01_Arr_Date = $CI->convert_format->ChangeJpDay($Course['M01_Arr_Date']);
        $objSheet->setCellValue('B3', $M01_Dep_Date . '～' . $M01_Arr_Date);
        $i = 12;
        foreach ( $Travelers as $Traveler ) {
            $user_id = $Traveler['R01_Id'] . '-' . ($Traveler['R01_Plan'] + 1);
            $objSheet->setCellValue('B' . $i, $user_id);
            $objSheet->setCellValue('C' . $i, $Traveler['R01_PaxNo']);
            if ($Traveler['R01_Plan'] == 0) {
                $objSheet->setCellValue('D' . $i, $Traveler['R00_Group_No']);
                $objSheet->setCellValue('E' . $i, $Traveler['R00_Division']);
            } else {
                $objSheet->setCellValue('D' . $i, "");
                $objSheet->setCellValue('E' . $i, "");
            }
            $objSheet->setCellValue('F' . $i, $Traveler['R01_Sei']);
            $objSheet->getStyle('F' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objSheet->setCellValue('G' . $i, $Traveler['R01_Name']);
            $objSheet->getStyle('G' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            if ($Traveler['R01_Sex'] == "1") {
                $Sex = "MR";
            } else {
                $Sex = "MS";
            }
            $objSheet->setCellValue('H' . $i, $Sex);
            $objSheet->getStyle('H' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			if($Traveler['R00_Dest_Kbn'] == 1){
				$objSheet->setCellValue('I' . $i, $Traveler['R01_Passport_Sei']);
				$objSheet->getStyle('I' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$objSheet->setCellValue('J' . $i, $Traveler['R01_Passport_Name']);
				$objSheet->getStyle('J' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			}else{
				$objSheet->setCellValue('I' . $i, $Traveler['R01_Sei_Eng']);
				$objSheet->getStyle('I' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$objSheet->setCellValue('J' . $i, $Traveler['R01_Name_Eng']);
				$objSheet->getStyle('J' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			}
        
            $objSheet->setCellValue('K' . $i, $Traveler['R01_AirClass']);
            $objSheet->mergeCells('L' . $i . ':' . 'M' . $i);
            // 日付フォマット変化
            $R01_Birthday = str_replace("-", "/", $Traveler['R01_Birthday']);
            $objSheet->setCellValue('L' . $i, $R01_Birthday);
            $objSheet->mergeCells('N' . $i . ':' . 'O' . $i);
            $objSheet->setCellValue('N' . $i, $Traveler['R01_CHD_NameList']);
            $objSheet->setCellValue('P' . $i, $Traveler['R01_Remarks_NameList']);
			$objSheet->setCellValue('Q' . $i, $Traveler['R01_Sei_Kana']);
            $objSheet->getStyle('Q' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objSheet->setCellValue('R' . $i, $Traveler['R01_Name_Kana']);
            $objSheet->getStyle('R' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $i ++;
        }
    }
}