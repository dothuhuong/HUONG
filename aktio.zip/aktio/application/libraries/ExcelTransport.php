<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');
set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * ＫＮＴのお客さんからエクセルファイルノデーターをﾃﾞｰﾀｰﾍﾞｰｽにインポートする為、ライブラリー作成する
 * 新しいデーター対応
 * すでにのデーターアップデートにはまだ対応していません。
 * エクセルファイルから内容を読込んでデーターベースに保存する
 * @author VienCQ
 */
class ExcelTransport extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }

    public function readExcelData($readFile) {
        date_default_timezone_set('Asia/Tokyo');
        //Read spreadsheeet workbook
        $inputFileType = PHPExcel_IOFactory::identify($readFile);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($readFile);
        //Get worksheet dimensions
        $objPHPExcel->getSheet(0);
        // 配列形式で返す
        /*
        $dataExcel = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
        $data = $this->getTransportDataFromExcel($dataExcel);
        */
        // 20170424 modified by VienCQ , get excel data fix with date time
        $sheet = $objPHPExcel->getActiveSheet();
        $dataExcel = array();
        foreach ($sheet->getRowIterator() as $row) {
            $tmp = array();
            foreach ($row->getCellIterator() as $key => $cell) {
                $val = $cell->getValue();
                $format = $cell->getStyle()->getNumberFormat()->getFormatCode();
                // お客さんのエクセルデーターの日付形対応
                if ($val != null && $format == 'm"月"d"日"\(aaa\)') {
                    $val = PHPExcel_Style_NumberFormat::toFormattedString($val, PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDD2);
                } elseif ($format == "h:mm;@" || $format == "h:mm") {
                    $val = PHPExcel_Style_NumberFormat::toFormattedString($val, PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME3);
                }
                $tmp[$key] = $val;
            }
            $dataExcel[] = $tmp;
        }
        // 20170424 end
        $data = $this->getTransportDataFromExcel($dataExcel);
        $transportData = $this->convertDiffDataByIdAndSeq($data);
        // R01_Kitenのデーターを保存する
        $this->saveTransportKiten($transportData);
        // R07_Transportデーターに保存して、R01_Departure_PtnとR01_Arrival_Ptnのデーターをアップデートする
        $this->saveTransportData($transportData);
    }

    /**
     * データーを保存する
     * @param array|null $dataExcel Excelファイルのデーター配列
     * @return boolean $data 保存フラグ
     */
    private function getTransportDataFromExcel($dataExcel) {
        if ($dataExcel != null) {
            $transport = array();
            foreach ($dataExcel as $row => $dataRow) {
                // Excel ファイルヘーダーを外す
                if ($row < 6) continue;
                if ($row >= 6 && $dataRow['A'] == null) break;
                // 予約番号を取得する
                $userIdArr = explode('-', $dataRow['A']);
                $userId  = $userIdArr[0];
                $userSeq = $userIdArr[1] - 1;
                $tmp = array();
                foreach ($dataRow as $key => $row) {
                    if ($key == 'A' || $key == 'B' || $key == 'C') continue;
                    $tmp['A'] = $userId;
                    $tmp[$key] = $row;
                }
                $transport[$userId][$userSeq] = $tmp;
            }
            return $transport;
        } else {
            return null;
        }
    }

    /**
     * 本人と同行者のデーターを比較する、同じデーターを外す、新しい配列データーを出す
     * @param array|null $data エクセルデーター
     */
    private function convertDiffDataByIdAndSeq($data) {
        $transportData = array();
        foreach ($data as $userId => $seqTransport) {
            if (count($seqTransport) > 1) { // 2個以上
                $tmp = array(); // index 0,1,2,..によりデーター交換する配列
                $seqList = array(); // index 0,1,2,..により$seq配列
                foreach ($seqTransport as $seq => $transport) {
                    $tmp[] = $transport;
                    $seqList[] = $seq;
                }
                for ($i = 1 ; $i < count($tmp) ; $i++) {
                    if (array_diff_assoc($tmp[0], $tmp[$i]) == null) {
                        $transportData[$userId][0] = $tmp[0];
                    } else {
                        $transportData[$userId][0]  = $tmp[0];
                        $transportData[$userId][$seqList[$i]] = $tmp[$i];
                        $transportData[$userId]['seqPtn2'][] = $seqList[$i];
                    }
                }
                $transportData[$userId]['seqFull'] = $seqList;
            } else {
                $transportData[$userId] = $seqTransport;
                foreach ($seqTransport as $seq => $transport) {
                    $transportData[$userId]['seqFull'][] = $seq;
                }
            }
        }
        return $transportData;
    }

    /**
     * convertDiffDataByIdAndSeqメソッドから返すデーターをR01_Kitenのデーターに保存する
     * @param array|null $transportData エクセルデーター
     */
    private function saveTransportKiten($transportData) {
        if ($transportData != null) {
            foreach ($transportData as $userId => $dataRows) {
                if (isset($dataRows['seqFull'])) {
                    $seqFull = $dataRows['seqFull'];
                }
                if (isset($dataRows['seqPtn2'])) {
                    $seqPtn2 = $dataRows['seqPtn2'];
                    $seqPtn1 = array_diff($seqFull, $seqPtn2);
                } else {
                    $seqPtn1 = $seqFull;
                    $seqPtn2 = null;
                }

                $kiten = '';
                foreach ($dataRows as $userSeq => $dataRow) {
                    if (!is_numeric($userSeq)) continue;
                    $kiten = trim($dataRow['D']);
                    if (in_array($userSeq, $seqPtn1)) {
                        $this->saveKiten($userId , $seqPtn1 , $kiten);
                    }
                    if ($seqPtn2 != null && in_array($userSeq, $seqPtn2)) {
                        $this->saveKiten($userId , $seqPtn2 , $kiten);
                    }
                }
            }
        }
    }

    private function saveKiten($userId , $seqPtn , $kiten ) {
        foreach ($seqPtn as $userSeq) {
            // モデルを利用する為、$CIインスタンスを使う
            $CI = & get_instance();
            $CI->load->model('operating_mo');
            if ($CI->operating_mo->isExistTravelerByIdAndSeq($userId , $userSeq)) {
                $CI->operating_mo->updateKitenByIdAndSeq($userId , $userSeq , $kiten);
            }
        }
    }


    /**
     * convertDiffDataByIdAndSeqメソッドから返すデーターをR07_Transportテーブルのデータータイプに交換して、データーベースに保存する
     * @param array|null $transportData エクセルデーター
     */
    private function saveTransportData($transportData) {
        if ($transportData != null) {
            $error = array();
            foreach ($transportData as $userId => $dataRows) {
                if (isset($dataRows['seqFull'])) {
                    $seqFull = $dataRows['seqFull'];
                }
                if (isset($dataRows['seqPtn2'])) {
                    $seqPtn2 = $dataRows['seqPtn2'];
                    $seqPtn1 = array_diff($seqFull, $seqPtn2);
                } else {
                    $seqPtn1 = $seqFull;
                    $seqPtn2 = null;
                }
                // 初期化
                $transport = array();
                $arrival = array();
                foreach ($dataRows as $userSeq => $dataRow) {
                    if (!is_numeric($userSeq)) continue;
                    $transport = array(
                            // 往路データー
                            array(
                                    'R07_ReserveId' => trim($dataRow['A']) , // 予約番号
                                    'R07_Transport_No' => '' , // 別便番号
                                    'R07_Transport_Type' => '1' , // 0:未登録　1:往路　２：復路
                                    'R07_Transport_Sequence' => '1' , // データ 最大３まで
                                    'R07_Transport_Date' => (trim($dataRow['E']) != '')?date('Y-m-d' , strtotime(trim($dataRow['E']))):'0000-00-00' , // 出発日
                                    'R07_Transport_Place' => trim($dataRow['G']) , // 出発場所
                                    'R07_Transport_Dep_Time' => trim($dataRow['H']) , // 出発時刻
                                    'R07_Transport_Name' => trim($dataRow['F']) , // 便名
                                    'R07_Transport_Arr_Place' => trim($dataRow['I']) , // 到着場所
                                    'R07_Transport_Arr_Time' => trim($dataRow['J']) , // 到着時刻
                                    'R07_Note' => $dataRow['K'] , // 備考
                            ) ,
                            array(
                                    'R07_ReserveId' => trim($dataRow['A']) , // 予約番号
                                    'R07_Transport_No' => '' , // 別便番号
                                    'R07_Transport_Type' => '1' , // 0:未登録　1:往路　２：復路
                                    'R07_Transport_Sequence' => '2' , // データ 最大３まで
                                    'R07_Transport_Date' => (trim($dataRow['L']) != '')?date('Y-m-d' , strtotime(trim($dataRow['L']))):'0000-00-00' , // 出発日
                                    'R07_Transport_Place' => trim($dataRow['N']) , // 出発場所
                                    'R07_Transport_Dep_Time' => trim($dataRow['O']) , // 出発時刻
                                    'R07_Transport_Name' => trim($dataRow['M']) , // 便名
                                    'R07_Transport_Arr_Place' => trim($dataRow['P']) , // 到着場所
                                    'R07_Transport_Arr_Time' => trim($dataRow['Q']) , // 到着時刻
                                    'R07_Note' => $dataRow['R'] , // 備考
                            ) ,
                            array(
                                    'R07_ReserveId' => trim($dataRow['A']) , // 予約番号
                                    'R07_Transport_No' => '' , // 別便番号
                                    'R07_Transport_Type' => '1' , // 0:未登録　1:往路　２：復路
                                    'R07_Transport_Sequence' => '3' , // データ 最大３まで
                                    'R07_Transport_Date' => (trim($dataRow['S']) != '')?date('Y-m-d' , strtotime(trim($dataRow['S']))):'0000-00-00' , // 出発日
                                    'R07_Transport_Place' => trim($dataRow['U']) , // 出発場所
                                    'R07_Transport_Dep_Time' => trim($dataRow['V']) , // 出発時刻
                                    'R07_Transport_Name' => trim($dataRow['T']) , // 便名
                                    'R07_Transport_Arr_Place' => trim($dataRow['W']) , // 到着場所
                                    'R07_Transport_Arr_Time' => trim($dataRow['X']) , // 到着時刻
                                    'R07_Note' => $dataRow['Y'] , // 備考
                            ) ,
                            // 復路データー
                            array(
                                    'R07_ReserveId' => trim($dataRow['A']) , // 予約番号
                                    'R07_Transport_No' => '' , // 別便番号
                                    'R07_Transport_Type' => '2' , // 0:未登録　1:往路　２：復路
                                    'R07_Transport_Sequence' => '1' , // データ 最大３まで
                                    'R07_Transport_Date' => (trim($dataRow['AK']) != '')?date('Y-m-d' , strtotime(trim($dataRow['AK']))):'0000-00-00' , // 出発日
                                    'R07_Transport_Place' => trim($dataRow['AM']) , // 出発場所
                                    'R07_Transport_Dep_Time' => trim($dataRow['AN']) , // 出発時刻
                                    'R07_Transport_Name' => trim($dataRow['AL']) , // 便名
                                    'R07_Transport_Arr_Place' => trim($dataRow['AO']) , // 到着場所
                                    'R07_Transport_Arr_Time' => trim($dataRow['AP']) , // 到着時刻
                                    'R07_Note' => $dataRow['AQ'] , // 備考
                            ) ,
                            array(
                                    'R07_ReserveId' => trim($dataRow['A']) , // 予約番号
                                    'R07_Transport_No' => '' , // 別便番号
                                    'R07_Transport_Type' => '2' , // 0:未登録　1:往路　２：復路
                                    'R07_Transport_Sequence' => '2' , // データ 最大３まで
                                    'R07_Transport_Date' => (trim($dataRow['AR']) != '')?date('Y-m-d' , strtotime(trim($dataRow['AR']))):'0000-00-00' , // 出発日
                                    'R07_Transport_Place' => trim($dataRow['AT']) , // 出発場所
                                    'R07_Transport_Dep_Time' => trim($dataRow['AU']) , // 出発時刻
                                    'R07_Transport_Name' => trim($dataRow['AS']) , // 便名
                                    'R07_Transport_Arr_Place' => trim($dataRow['AV']) , // 到着場所
                                    'R07_Transport_Arr_Time' => trim($dataRow['AW']) , // 到着時刻
                                    'R07_Note' => $dataRow['AX'] , // 備考
                            ) ,
                            array(
                                    'R07_ReserveId' => trim($dataRow['A']) , // 予約番号
                                    'R07_Transport_No' => '' , // 別便番号
                                    'R07_Transport_Type' => '2' , // 0:未登録　1:往路　２：復路
                                    'R07_Transport_Sequence' => '3' , // データ 最大３まで
                                    'R07_Transport_Date' => (trim($dataRow['AY']) != '')?date('Y-m-d' , strtotime(trim($dataRow['AY']))):'0000-00-00' , // 出発日
                                    'R07_Transport_Place' => trim($dataRow['BA']) , // 出発場所
                                    'R07_Transport_Dep_Time' => trim($dataRow['BB']) , // 出発時刻
                                    'R07_Transport_Name' => trim($dataRow['AZ']) , // 便名
                                    'R07_Transport_Arr_Place' => trim($dataRow['BC']) , // 到着場所
                                    'R07_Transport_Arr_Time' => trim($dataRow['BD']) , // 到着時刻
                                    'R07_Note' => $dataRow['BE'] , // 備考
                            )
                    );

                    if (in_array($userSeq, $seqPtn1)) {
                        $transportNo = 1;
                        $transport = $this->setTransportNo($transport, $transportNo);
                        $this->saveTransport($transport , $userId , $seqPtn1 , $transportNo);
                    }

                    if ($seqPtn2 != null && in_array($userSeq, $seqPtn2)) {
                        $transportNo = 2;
                        $transport = $this->setTransportNo($transport, $transportNo);
                        $this->saveTransport($transport , $userId , $seqPtn2 , $transportNo);
                    }
                }
            }
        }
    }

    private function setTransportNo($transport , $transportPtn) {
        foreach ($transport as $key => $transportItem) {
            $transport[$key]['R07_Transport_No'] = $transportPtn;
        }
        return $transport;
    }

    /**
     * 往路・復路データー保存する
     * @param array|null $transport エクセルデーター
     * @param varchar $userId 予約番号
     * @param array|null $seqPtn 別便使う参加者配列
     * @param int $transportNo 別便番号
     * @param int $transportType 0:未登録　1:往路　２：復路
     */
    private function saveTransport($transport , $userId , $seqPtn , $transportNo) {
        // モデルを利用する為、$CIインスタンスを使う
        $CI = & get_instance();
        $CI->load->model('operating_mo');

        // 往路データーがあるかどうかチェック
        $isTransportDataFlg = $CI->operating_mo->isExistTransportByReserveIdAndType($userId , $transportNo);
        if ( $isTransportDataFlg == 0) { // データーなし
            // insert data vao database va change
            foreach ($transport as $item) {
                $CI->operating_mo->insertTransportData($item);
            }
        } else {
            foreach ($transport as $item) {
                $param = array(
                        'R07_ReserveId' => $userId ,
                        'R07_Transport_No' => $item['R07_Transport_No'] ,
                        'R07_Transport_Type' => $item['R07_Transport_Type'] ,
                        'R07_Transport_Sequence' => $item['R07_Transport_Sequence']
                );
                $isExistTransport = $CI->operating_mo->isExistTransportByParam($param);
                if ( $isExistTransport == 0) {
                    $CI->operating_mo->insertTransportItemData($item);
                } else {
                    $existData = $CI->operating_mo->getTransportDataByParam($param);
                    if (array_diff_assoc($existData, $item) != null) {
                        $CI->operating_mo->updateTransportData($item);
                    }
                }
            }
        }

        // update R01_Traveler with new data from excel
        foreach ($seqPtn as $userSeq) {
            $departurePtn = $CI->operating_mo->getDeparturePtnByIdAndSeq($userId , $userSeq);
            $arrivalPtn   = $CI->operating_mo->getArrivalPtnByIdAndSeq($userId , $userSeq);
            if ($departurePtn == '3' || $departurePtn != $transportNo) { // まだ申込まない
                $CI->operating_mo->updateDepartureTraveler($userId , $userSeq , $transportNo);
            }

            if ($arrivalPtn == '3' || $arrivalPtn != $transportNo) { // まだ申込まない
                $CI->operating_mo->updateArrivalByNewTransport($userId , $userSeq , $transportNo);
            }
        }
    }
}