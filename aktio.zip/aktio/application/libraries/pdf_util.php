<?php

if (! defined('BASEPATH'))
    exit('No direct script access allowed');

require_once APPPATH . 'libraries/pdf/japanese.php';

/**
 * PDF生成クラス
 */
class pdf_util
{
    /**
     * テンプレート格納パス<br>
     * ※コンストラクタで設定
     */
    private $TEMPLATE_PATH;
    
    /**
     * 出力格納パス<br>
     * ※コンストラクタで設定
     */
    private $OUTPUT_PATH;
    
    // *** テンプレートファイル名 *** //
    /**
     * 予約確認書
     */
    private $TMP_CONF_SLIP = 'EXPEDIA CONFIRMATION SLIP.pdf';
    private $TMP_CONF_SLIPS = 'EXPEDIA CONFIRMATION SLIPS.pdf';
    private $TMP_HOKEN_SLIPS = 'Hoken_SKI.pdf';
    
    /**
     * 利用明細
     */
    private $TMP_BILL_STATE = 'BilldingStatement.pdf';
    
    // *** 出力ファイル名 *** //
    /**
     * 予約確認書
     */
    private $NAME_CONF_SLIP = '予約確認書.pdf';
    private $NAME_CONF_DETAIL = 'ご利用明細書.pdf';
    private $HEIGHT_ADJUST_SLIP = 7;
    private $HEIGHT_ADJUST_DETAIL = 10;
    
    /**
     * コンストラクタ
     */
    function __construct() {
        $this->TEMPLATE_PATH = APPPATH . "libraries/pdf_template/";
        $this->OUTPUT_PATH = "";
    }
    
    /**
     * 保険加入者証印刷<br>
     */
    function outputHokenSlip($ReserveNo) {
        // 予約情報取得
        $CI = & get_instance();
        $bookingInfo = array ();
        $fileName = "";
        
        // インスタンス作成
        $pdf = new PDF_Japanese();
        $pdf->Open();
        // PDFの内部作成
        
        // SJISフォント(MSPGothicを使用)
        $pdf->AddSJISFont('SJIS', 1);
        $pdf->AddUniSJISFont('UniJIS', 1);
        // $pdf->AddUniJISFont('UniJIS',1);
        // ファイル名設定
        $fileName = "国内旅行傷害保険加入者証.pdf";
        // 加入者証作成
        $this->createHokenSlipPdf($pdf, $ReserveNo);
        // ファイルのエンコードを取得
        
        $encode = 'UTF8';
        // PDFの出力
        // ダウンロード
        ob_end_clean();
        $pdf->Output(mb_convert_encoding($fileName, $encode), 'D');
        
        // PDFクローズ
        $pdf->Close();
    }
    function createHokenSlipPdf($pdf, $ReserveNo) {
        date_default_timezone_set('Asia/Tokyo');
        
        $CI = & get_instance();
        $CI->load->config('user_config');
        $CI->load->model('mmypage');
        
        $reserve = $CI->mmypage->selectResAndM($ReserveNo);
        $partner = $CI->mmypage->selectPartner($ReserveNo);
        $data['reserve'] = $reserve;
        $data['partner'] = $partner;
        
        $nights = $CI->mmypage->select_nights($reserve['res']['tour_id']);
        $type = $this->getType($reserve['res']['brand_code'], $nights);
        $data['type'] = $type;
        $data['querySolatium'] = $CI->mmypage->selectSolatium($type);
        // テンプレート読み込み
        $pageno = $pdf->setSourceFile($this->TEMPLATE_PATH . $this->TMP_HOKEN_SLIPS);
        $tplidx = $pdf->ImportPage(1);
        // ページを追加(新規ページ)
        $pdf->AddPage();
        // テンプレート内容の位置、幅を調整 ※useTemplateに引数を与えなければ100%表示がデフォルト
        $pdf->useTemplate($tplidx);
        
        // ページ番号
        $pdf->SetFont('UniJIS', 'B', 13);
        $str = mb_convert_encoding('1', "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(183, 14, $str);
        $str = mb_convert_encoding('1', "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(188, 14, $str);
        // 保険期間
        $pdf->SetFont('UniJIS', 'B', 9);
        $dep = date("Y年m月d日", strtotime($reserve['res']['date_from_r'])) . "より　";
        $dep .= date("Y年m月d日", strtotime($reserve['res']['date_to_r'])) . "まで　";
        $dep .= ((strtotime($reserve['res']['date_to_r']) - strtotime($reserve['res']['date_from_r'])) / (60 * 60 * 24)) . "日間";
        $str = mb_convert_encoding($dep, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(32, 33, $str);
        // 申込日・保険料
        $pdf->SetFont('UniJIS', 'B', 9);
        $today = date("Y年m月d日");
        $str = mb_convert_encoding($today, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(150, 31.5, $str);
        $fare = number_format((intval($reserve['res']['hoken_ninzu']) * 1000)) . "円";
        $str = mb_convert_encoding($fare, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(150, 35, $str);
        // 予約番号
        $pdf->SetFont('UniJIS', 'B', 9);
        $str = mb_convert_encoding($ReserveNo, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(32, 45, $str);
        // 代表者名
        $pdf->SetFont('UniJIS', 'B', 12);
        $dname = $reserve['res']['Family_Name_Kanji'] . "　" . $reserve['res']['First_Name_Kanji'];
        $dname .= "　（" . $reserve['res']['Family_Name_Kana'] . "　" . $reserve['res']['First_Name_Kana'] . "）";
        $str = mb_convert_encoding($dname, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(32, 56, $str);
        // 年齢
        $age = "";
        $pdf->SetFont('UniJIS', 'B', 12);
        if (($reserve['res']['BirthYY'] == 1900) && ($reserve['res']['BirthMM'] == 1) && ($reserve['res']['BirthDD'] == 1)) {
        } else {
            $age = date("Y") - $reserve['res']['BirthYY'];
            if (date("m") < $reserve['res']['BirthMM'] || (date("m") == $reserve['res']['BirthMM'] && date("d") < $reserve['res']['BirthDD'])) {
                $age = $age - 1;
            }
        }
        $str = mb_convert_encoding($age, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(132, 57.5, $str);
        // タイプ
        // if($reserve['res']['hoken_check1']==1){
        // if($reserve['res']['hoken']==1){
        // $pdf->SetFont('UniJIS', 'B', 12);
        // $str = mb_convert_encoding($type."タイプ","unicode","utf-8"); // UTF8 -> UTF16変換
        // $pdf->Text(155, 70, $str);
        // }
        // 住所
        $pdf->SetFont('UniJIS', 'B', 10);
        $post = "〒" . $reserve['res']['Post1'] . "-" . $reserve['res']['Post2'];
        $addr1 = $reserve['res']['Prefectural'] . $reserve['res']['Address'] . $reserve['res']['Lot_Number'];
        $addr2 = $reserve['res']['Building_Name'];
        $str = mb_convert_encoding($post, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(32, 67.5, $str);
        $str = mb_convert_encoding($addr1, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(32, 72.5, $str);
        $str = mb_convert_encoding($addr2, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(32, 77.5, $str);
        // 性別
        $pdf->SetFont('UniJIS', 'B', 12);
        if ($reserve['res']['gender'] == 1) {
            $gender = "男";
        } else {
            $gender = "女";
        }
        $str = mb_convert_encoding($gender, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(132, 70, $str);
        // 電話番号
        $pdf->SetFont('UniJIS', 'B', 10);
        if ($reserve['res']['Tel_Mobile'] != "") {
            $tel = $reserve['res']['Tel_Mobile'];
        } else {
            $tel = $reserve['res']['Tel_Fix'];
        }
        $str = mb_convert_encoding($tel, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(37, 85, $str);
        
        // 同行者
        $posX = 30;
        $posY = 98;
        $posX2 = 97;
        $posY2 = 98;
        
        $posAdd = 6;
        $lineIndex = 1;
        $modValue = 0;
        
        $paxNum = 0;
        if ($reserve['res']['hoken'] == 1) {
            $str = mb_convert_encoding($reserve['res']['Family_Name_Kanji'] . "　" . $reserve['res']['First_Name_Kanji'], "unicode", "utf-8"); // UTF8 -> UTF16変換
            $pdf->Text($posX, $posY, $str);
            $paxNum = $paxNum + 1;
        }
        foreach ( $partner['resp'] as $row ) {
            if ($row['hoken'] == 1) {
                $pdf->SetFont('UniJIS', 'B', 10);
                // 名前
                $str = mb_convert_encoding($row['Family_Name_Kanji'] . "　" . $row['First_Name_Kanji'], "unicode", "utf-8"); // UTF8 -> UTF16変換
                if (($paxNum % 2) == 0) {
                    $tempY = $posY + floor($paxNum / 2) * $posAdd;
                    $pdf->Text($posX, $tempY, $str);
                } else {
                    $tempY2 = $posY2 + floor($paxNum / 2) * $posAdd;
                    $pdf->Text($posX2, $tempY2, $str);
                }
                
                // $posY = $posY + 5.8;
                // //年齢
                // $str = mb_convert_encoding($row['Age'],"unicode","utf-8"); // UTF8 -> UTF16変換
                // $pdf->Text($posX + 5, $posY, $str);
                // //性別
                // if($row['sex']==1){
                // $gender = "男";
                // }else{
                // $gender = "女";
                // }
                // $str = mb_convert_encoding($gender,"unicode","utf-8"); // UTF8 -> UTF16変換
                // $pdf->Text($posX + 35, $posY, $str);
                
                // $pdf->SetFont('UniJIS', 'B', 10);
                // $str = mb_convert_encoding($type."タイプ","unicode","utf-8"); // UTF8 -> UTF16変換
                // $pdf->Text($posX + 67, $posY, $str);
                
                $paxNum = $paxNum + 1;
                if ($paxNum == 30) {
                    break;
                }
            }
        }
    }
    public function getType($brand_code, $nights) {
        $type = "";
        if ($brand_code == '2') {
            if ($nights <= 1) {
                $type = 'A';
            } elseif (1 < $nights || $nights <= 3) {
                $type = 'C';
            } elseif (3 < $nights || $nights <= 6) {
                $type = 'E';
            } elseif (6 < $nights || $nights <= 13) {
                $type = 'G';
            }
        } else if ($brand_code == '1') {
            if ($nights <= 1) {
                $type = 'B';
            } elseif (1 < $nights || $nights <= 3) {
                $type = 'D';
            } elseif (3 < $nights || $nights <= 6) {
                $type = 'F';
            } elseif (6 < $nights || $nights <= 13) {
                $type = 'H';
            }
        }
        
        return $type;
    }
    
    /**
     * 予約確認書・利用明細書<br>
     * 　使用する場合は、Conntrollerに以下をロードして下さい。<br>
     * 　　　booking_mo
     *
     * @param int $bookingId
     *            予約Seq
     * @param int $target
     *            0:予約確認書、利用明細書 1:予約確認書 2:利用明細書
     * @param int $mode
     *            0:ダウンロード 1:ブラウザ表示 2:ファイル出力
     */
    function outputBookingSlip($ReserveNo) {
        
        // 予約情報取得
        $CI = & get_instance();
        $bookingInfo = array ();
        $fileName = "";
        
        // インスタンス作成
        $pdf = new PDF_Japanese();
        $pdf->Open();
        
        // PDFの内部作成
        
        // SJISフォント(MSPGothicを使用)
        $pdf->AddSJISFont('SJIS', 1);
        $pdf->AddUniSJISFont('UniJIS', 1);
        // $pdf->AddUniJISFont('UniJIS',1);
        // ファイル名設定
        $fileName = $this->NAME_CONF_SLIP;
        // 予約確認書作成
        
        $this->createConfSlipPdf($pdf, $ReserveNo);
        
        // ファイルのエンコードを取得
        
        $encode = 'UTF8';
        // PDFの出力
        // ダウンロード
        ob_end_clean();
        $pdf->Output(mb_convert_encoding($fileName, $encode), 'D');
        
        // PDFクローズ
        $pdf->Close();
    }
    
    /**
     * 予約確認書PDF作成
     *
     * @param PDF_Japanese $pdf
     *            PDFインスタンス
     * @param int $bookingNo
     *            予約情報
     *
     */
    function createConfSlipPdf($pdf, $ReserveNo) {
        $CI = & get_instance();
        $CI->load->config('user_config');
        $CI->load->model('mcxlapdf');
        
        $res = $CI->mcxlapdf->selectPdfRes($ReserveNo);
        // 設定項目初期化
        $company = ''; // 会社名
        $yubin = ''; // 郵便番号
        $adress = ''; // 住所
        $tel_fax = ''; // 電話＆FAX
        $weekday = ''; // 営業時間　平日
        $weekend = ''; // 営業時間　土日祝
        $kouza_1 = ''; // 振込先口座１
        $kouza_2 = ''; // 振込先口座２
        $kouza_other = ''; // 振込先口座備考
        $name = ''; // 代表者名
        $person_count = ''; // 参加人数
        $male_count = ''; // 男性参加人数
        $female_count = ''; // 女性参加人数
        $schedul = ''; // 日程
        $plan_name = ''; // プラン名
        $dep = '';
        $detail = '';
        $agent_yubin = '';
        $agent_adress_1 = '';
        $agent_adress_2 = '';
        $cancle_20 = '';
        $cancle_7 = '';
        $cancle_1 = '';
        $cancle_0 = '';
        $cancle = '';
        if ($res != '') {
            if ($res['company_code'] == '2') {
                $company = $CI->config->item('tabi_company'); // 会社名
                $yubin = $CI->config->item('tabi_yubin'); // 郵便番号
                $adress = $CI->config->item('tabi_adress'); // 住所
                $tel_fax = $CI->config->item('tabi_tel_fax'); // 電話＆FAX
                $weekday = $CI->config->item('tabi_weekday'); // 営業時間　平日
                $weekend = $CI->config->item('tabi_weekend'); // 営業時間　土日祝
                $kouza_1 = $CI->config->item('tabi_kouza_1'); // 振込先口座１
                $kouza_2 = $CI->config->item('tabi_kouza_2'); // 振込先口座２
                $kouza_other = $CI->config->item('tabi_kouza_other'); // 振込先口座備考
            } else {
                $company = $CI->config->item('club_company'); // 会社名
                $yubin = $CI->config->item('club_yubin'); // 郵便番号
                $adress = $CI->config->item('club_adress'); // 住所
                $tel_fax = $CI->config->item('club_tel_fax'); // 電話＆FAX
                $weekday = $CI->config->item('club_weekday'); // 営業時間　平日
                $weekend = $CI->config->item('club_weekend'); // 営業時間　土日祝
                $kouza_1 = $CI->config->item('club_kouza_1'); // 振込先口座１
                $kouza_2 = $CI->config->item('club_kouza_2'); // 振込先口座２
                $kouza_other = $CI->config->item('club_kouza_other'); // 振込先口座備考
            }
            if ($res['brand_code'] == '3') {
                $name = $res['Family_Name_Kana'] . '　' . $res['First_Name_Kana'] . '　様'; // 代表者名カナ（生協）
            } else {
                $name = $res['Family_Name_Kanji'] . '　' . $res['First_Name_Kanji'] . '　様'; // 代表者名
            }
            $male_count = $res['man_adult'] + $res['man_senior'] + $res['man_child'] + $res['man_baby']; // 男性参加人数
            $female_count = $res['female_adult'] + $res['female_senior'] + $res['female_child'] + $res['female_baby'];
            ; // 女性参加人数
            $person_count = $res['Pax_Total'] . '人（男　' . $male_count . '人　女　' . $female_count . '人）'; // 参加人数
            $date_from_str = '';
            $date_to_str = '';
            if ($CI->mcxlapdf->GetHolyday(date('Y-m-d', strtotime($res['date_from']))) == 1) {
                $date_from_str = date('Y年m月d日', strtotime($res['date_from'])) . '(祝)';
            } else {
                $date_from_str = date('Y年m月d日', strtotime($res['date_from'])) . '(' . $this->countWeek($res['date_from']) . ')';
            }
            
            if ($CI->mcxlapdf->GetHolyday(date('Y-m-d', strtotime($res['date_to']))) == 1) {
                $date_to_str = date('Y年m月d日', strtotime($res['date_to'])) . '(祝)';
            } else {
                $date_to_str = date('Y年m月d日', strtotime($res['date_to'])) . '(' . $this->countWeek($res['date_to']) . ')';
            }
            $schedul = $date_from_str . '～' . $date_to_str; // 日程
                                                        // $plan_name = $res['tour_name'].'　'.$CI->mcxlapdf->selectPdfPlan($ReserveNo);
            $plan_name = $res['tour_name'];
            $dep = $CI->mcxlapdf->selectDep($ReserveNo);
            $detail = $CI->mcxlapdf->selectPdfDetail($ReserveNo);
            if ($res['brand_code'] == '3') {
                $agent_yubin = '';
                $agent_adress_1 = '';
                $agent_adress_2 = '';
            } else {
                $agent_yubin = '〒' . $res['Post1'] . '-' . $res['Post2'];
                $agent_adress_1 = $res['Prefectural'] . $res['Address'] . $res['Lot_Number'];
                $agent_adress_2 = $res['Building_Name'];
            }
            if (intval($res['nights']) > 0) {
                $cancle_20 = date('m月d日', strtotime('-20 day', strtotime($res['date_from'])));
            } else {
                $cancle_20 = date('m月d日', strtotime('-10 day', strtotime($res['date_from'])));
            }
            $cancle_7 = date('m月d日', strtotime('-7 day', strtotime($res['date_from'])));
            $cancle_1 = date('m月d日', strtotime('-1 day', strtotime($res['date_from'])));
            $cancle_0 = date('m月d日', strtotime($res['date_from']));
            
            $cancle = 'キャンセル日　' . $cancle_20 . '～20%、' . $cancle_7 . '～30%、' . $cancle_1 . '～40%、' . $cancle_0 . ' 50%';
        }
        $CI->config->item('plan_time_weekend');
        // テンプレート読み込み
        if ($res['brand_code'] == '3') {
            $pageno = $pdf->setSourceFile($this->TEMPLATE_PATH . $this->TMP_CONF_SLIPS);
        } else {
            $pageno = $pdf->setSourceFile($this->TEMPLATE_PATH . $this->TMP_CONF_SLIP);
        }
        $tplidx = $pdf->ImportPage(1);
        // ページを追加(新規ページ)
        $pdf->AddPage();
        // テンプレート内容の位置、幅を調整 ※useTemplateに引数を与えなければ100%表示がデフォルト
        $pdf->useTemplate($tplidx);
        // 会社名
        $pdf->SetFont('UniJIS', 'B', 13);
        $str = mb_convert_encoding($company, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(124, 28, $str);
        // 郵便番号
        $pdf->SetFont('UniJIS', '', 11);
        $str = mb_convert_encoding($yubin, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(124, 33, $str);
        // agent郵便番号
        $pdf->SetFont('UniJIS', '', 9);
        $str = mb_convert_encoding($agent_yubin, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(24, 24, $str);
        // 住所
        $pdf->SetFont('UniJIS', '', 9);
        $str = mb_convert_encoding($adress, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(124, 37, $str);
        // agent住所
        $pdf->SetFont('UniJIS', '', 10);
        $str = mb_convert_encoding($agent_adress_1, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(24, 28, $str);
        $pdf->SetFont('UniJIS', '', 10);
        $str = mb_convert_encoding($agent_adress_2, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(24, 32, $str);
        $pdf->SetFont('UniJIS', 'B', 11);
        $str = mb_convert_encoding($name, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(30, 36, $str);
        // TEL / FAX
        $pdf->SetFont('UniJIS', '', 9);
        $str = mb_convert_encoding($tel_fax, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(124, 41, $str);
        // 営業時間 平日
        $pdf->SetFont('UniJIS', '', 9);
        $str = mb_convert_encoding($weekday, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(142, 49.7, $str);
        // 営業時間 土・日・祝
        $pdf->SetFont('UniJIS', '', 9);
        $str = mb_convert_encoding($weekend, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(142, 53.7, $str);
        // 発　行　日
        $pdf->SetFont('UniJIS', '', 9);
        $str = mb_convert_encoding(date('Y年m月d日'), "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(142, 59.2, $str);
        // 予約番号
        $pdf->SetFont('UniJIS', 'B', 9);
        $str = mb_convert_encoding($ReserveNo, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(70, 45.2, $str);
        // 代表者名
        $pdf->SetFont('UniJIS', 'B', 10.2);
        $str = mb_convert_encoding($name, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(45, 78.4, $str);
        // 参加人数
        $pdf->SetFont('UniJIS', 'B', 10.2);
        $str = mb_convert_encoding($person_count, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(45, 83, $str);
        // //日　程
        $pdf->SetFont('UniJIS', 'B', 10.2);
        $str = mb_convert_encoding($schedul, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(45, 87, $str);
        // //プラン名
        $pdf->SetFont('UniJIS', 'B', 10.2);
        $str = mb_convert_encoding($plan_name, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(45, 91, $str);
        // //出発時間＆集合場所
        $count = 0;
        if ($dep != '') {
            
            foreach ( $dep as $row ) {
                $pdf->SetFont('UniJIS', 'B', 10.2);
                $place = $row['assemble_count'] . '名/ ' . $row['Place_Name'] . ' (' . $row['assemble_time'] . '集合)';
                $str = mb_convert_encoding($place, "unicode", "utf-8"); // UTF8 -> UTF16変換
                $pdf->Text(61, 95 + $count, $str);
                $count = $count + 4;
            }
        } else {
            $pdf->SetFont('UniJIS', '', 10.2);
            $place = 'マイカープランにてご予約の方は、ご宿泊施設に朝7時半以降に直接お越しください';
            $str = mb_convert_encoding($place, "unicode", "utf-8"); // UTF8 -> UTF16変換
            $pdf->Text(61, 95 + $count, $str);
        }
        // 明細
        $pdf->SetXY(19, 106);
        $pdf->SetFont('UniJIS', 'B', 9.8);
        $pdf->Cell(105, 4, mb_convert_encoding('ご旅行代金', "unicode", "utf-8"), 1, 1, 'C');
        $width = array (
                40,
                25,
                15,
                25
        );
        // $width=array(40,25,15,25);
        // $posi=array(19,59,74,99);
        $title1 = mb_convert_encoding('項目名', "unicode", "utf-8");
        $title2 = mb_convert_encoding('単価', "unicode", "utf-8");
        $title3 = mb_convert_encoding('人数', "unicode", "utf-8");
        $title4 = mb_convert_encoding('金額', "unicode", "utf-8");
        $header = array (
                $title1,
                $title2,
                $title3,
                $title4
        );
        $pdf->SetX(19);
        
        for($i = 0; $i < count($header); $i ++) {
            
            $pdf->Cell($width[$i], 4, $header[$i], 1, 0, 'C');
            // $pdf->Text(15+$posi[$i], 106 , $header[$i]);
        }
        $pdf->Ln();
        $pdf->SetX(19);
        $Sales_Fare_total = 0;
        for($i = 0; $i < 10; $i ++) {
            if (isset($detail[$i])) {
                $Sales_Unit_Price = number_format($detail[$i]['Sales_Unit_Price']) . '円';
                $Sales_Fare = number_format($detail[$i]['Sales_Fare']) . '円';
                $Sales_Fare_total = $Sales_Fare_total + intval($detail[$i]['Sales_Fare']);
                
                // ”名”の文字化け対応
                $room_type_name_value = "";
                switch ($detail[$i]['room_type_code']) {
                    case "1RC" :
                        $room_type_name_value = "1名1室";
                        break;
                    case "2RC" :
                        $room_type_name_value = "2名1室";
                        break;
                    case "3RC" :
                        $room_type_name_value = "3名1室";
                        break;
                    case "4RC" :
                        $room_type_name_value = "4名1室";
                        break;
                    case "5RC" :
                        $room_type_name_value = "5名1室";
                        break;
                    case "6RC" :
                        $room_type_name_value = "6名1室";
                        break;
                    case "7RC" :
                        $room_type_name_value = "7名1室";
                        break;
                    case "FRCH" :
                        $room_type_name_value = "女性相部屋";
                        break;
                    case "MRCH" :
                        $room_type_name_value = "男性相部屋";
                        break;
                    case "SRCH" :
                        $room_type_name_value = "男女別相部屋";
                        break;
                    case "OMAKASE5" :
                        $room_type_name_value = "5名以上おまかせ";
                        break;
                    case "OMAKASE56H" :
                        $room_type_name_value = "5名・6名以上おまかせ";
                        break;
                    case "OMAKASE7H" :
                        $room_type_name_value = "7名以上おまかせ";
                        break;
                    default :
                        $room_type_name_value = "";
                }
                if ($detail[$i]['Create_User_Id'] != "user") { // 電話受付
                    $pdf->SetFont('UniJIS', '', 10.2);
                    $pdf->CellFitScale($width[0], 4, mb_convert_encoding($detail[$i]['Sales_Item'], "unicode", "utf-8"), 1, 0, 'C');
                } else { // WEB予約
                    $plan_name_work = $detail[$i]['plan_name'];
                    $room_type_name_work = $detail[$i]['Room_Type_Name'];
                    $item = mb_convert_encoding($plan_name_work . " " . $room_type_name_work, "unicode", "utf-8");
                    // $item = $plan_name_work ." ". $room_type_name_value;
                    $pdf->SetFont('UniJIS', '', 10.2);
                    // $pdf->CellFitScale($width[0],4,mb_convert_encoding($item,"unicode","utf-8"),1,0,'L');
                    $pdf->Text(80, 95 + $count, $str);
                    // $pdf->CellFitScale($width[0],4,"1名2abc",1,0,'L');
                }
                if ($detail[$i]['Sales_Unit_Price'] == 0) {
                    $pdf->Cell($width[1], 4, mb_convert_encoding('', "unicode", "utf-8"), 1, 0, 'C');
                } else {
                    $pdf->Cell($width[1], 4, mb_convert_encoding($Sales_Unit_Price, "unicode", "utf-8"), 1, 0, 'R');
                }
                $pdf->Cell($width[2], 4, mb_convert_encoding($detail[$i]['Sales_Quantity'], "unicode", "utf-8"), 1, 0, 'R');
                
                if (intval($detail[$i]['Sales_Fare']) == 0) {
                    $pdf->Cell($width[3], 4, mb_convert_encoding('', "unicode", "utf-8"), 1, 0, 'R');
                } else {
                    
                    $pdf->Cell($width[3], 4, mb_convert_encoding($Sales_Fare, "unicode", "utf-8"), 1, 0, 'R');
                }
                $pdf->Ln();
                $pdf->SetX(19);
            } else {
                $pdf->Cell($width[0], 4, mb_convert_encoding('', "unicode", "utf-8"), 1, 0, 'C');
                $pdf->Cell($width[1], 4, mb_convert_encoding('', "unicode", "utf-8"), 1, 0, 'C');
                $pdf->Cell($width[2], 4, mb_convert_encoding('', "unicode", "utf-8"), 1, 0, 'C');
                $pdf->Cell($width[3], 4, mb_convert_encoding('', "unicode", "utf-8"), 1, 0, 'C');
                //
                $pdf->Ln();
                $pdf->SetX(19);
            }
        }
        $Sales_Fare_total = number_format($Sales_Fare_total) . '円';
        $pdf->Cell(80, 4, mb_convert_encoding('総合計    ', "unicode", "utf-8"), 1, 0, 'R');
        $pdf->Cell(25, 4, mb_convert_encoding($Sales_Fare_total, "unicode", "utf-8"), 1, 1, 'R');
        $pdf->SetFont('UniJIS', 'B', 10);
        $str = mb_convert_encoding($cancle, "unicode", "utf-8"); // UTF8 -> UTF16変換
        $pdf->Text(19, 165.6, $str); // 口座1
                                     // //プラン名
        if ($res['brand_code'] != '3') {
            $pdf->SetFont('UniJIS', 'B', 9);
            $str = mb_convert_encoding($kouza_1, "unicode", "utf-8"); // UTF8 -> UTF16変換
            $pdf->Text(28, 203.6, $str); // 口座1
            $str = mb_convert_encoding($kouza_2, "unicode", "utf-8"); // UTF8 -> UTF16変換
            $pdf->Text(28, 207.6, $str); // 口座2
            $str = mb_convert_encoding($kouza_other, "unicode", "utf-8"); // UTF8 -> UTF16変換
            $pdf->Text(28, 211.6, $str); // 口座その他
        }
    }
    function countWeek($str) {
        $date = date('Y-m-d', strtotime($str));
        $datetime = new DateTime($date);
        $week = array (
                "日",
                "月",
                "火",
                "水",
                "木",
                "金",
                "土"
        );
        $w = (int)$datetime->format('w');
        return trim($week[$w]);
    }
    
    /**
     * 予約確認書PDF作成
     *
     * @param PDF_Japanese $pdf
     *            PDFインスタンス
     * @param int $bookingNo
     *            予約情報
     */
    function createConfSlipPdforig($pdf, $bookingInfo) {
        
        // テンプレート読み込み
        $pageno = $pdf->setSourceFile($this->TEMPLATE_PATH . $this->TMP_CONF_SLIP);
        $tplidx = $pdf->ImportPage(1);
        
        // ページを追加(新規ページ)
        $pdf->AddPage();
        
        // テンプレート内容の位置、幅を調整 ※useTemplateに引数を与えなければ100%表示がデフォルト
        $pdf->useTemplate($tplidx);
        
        /**
         * * ISSUED start **
         */
        $pdf->SetFont('SJIS', '', 8);
        $issueDate = date('Y/m/d', strtotime($bookingInfo['booking_timestamp']));
        $pdf->Text(125.5, 26.5 + $this->HEIGHT_ADJUST_SLIP, $issueDate);
        /**
         * * ISSUED end **
         */
        
        /**
         * * MAIN GUEST NAME start **
         */
        // $pdf->SetFont('SJIS', '', 7);
        // 縦間隔
        $indexY = 3.73;
        for($i = 0; $i < 8; $i ++) {
            /*
             * $pdf->Text(17, 33.9 + ($indexY * $i) + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_confno'.($i+1)] .
             * ' '. $bookingInfo['delegate'.($i+1)]);
             */
            $pdf->SetFont('SJIS', '', 7);
            // $pdf->Text(17, 33.7 + ($indexY * $i) + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_confno'.($i+1)]);
            $pdf->Text(17, 22.6 + ($indexY * $i) + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_confno' . ($i + 1)]);
            $pdf->SetFont('SJIS', '', 8);
            // $pdf->Text(36.3, 33.9 + ($indexY * $i) + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['delegate'.($i+1)], 0, 35));
            $pdf->Text(36.3, 22.6 + ($indexY * $i) + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['delegate' . ($i + 1)], 0, 35));
        }
        /**
         * * MAIN GUEST NAME end **
         */
        
        /**
         * * OTHER start **
         */
        if ($bookingInfo['booking_breakfast_eng'] == '') {
            $bookingInfo['booking_breakfast_eng'] = NULL;
        }
        if ($bookingInfo['booking_breakfast_eng'] != NULL && $bookingInfo['booking_internet_eng']) {
            $split = ' / ';
        } else {
            $split = '';
        }
        $other = $bookingInfo['booking_breakfast_eng'] . $split . $bookingInfo['booking_internet_eng'];
        $pdf->SetFont('SJIS', '', 8);
        // $pdf->Text(13, 67.5 + $this->HEIGHT_ADJUST_SLIP, $other);
        $pdf->Text(13, 56.4 + $this->HEIGHT_ADJUST_SLIP, $other);
        /**
         * * OTHER end **
         */
        
        /**
         * * GUESTS start **
         */
        $totalNum = $bookingInfo['booking_adult_m'] + $bookingInfo['booking_adult_f'] + $bookingInfo['booking_child'];
        $pdf->SetFont('SJIS', '', 9);
        // $pdf->Text(56, 75 + $this->HEIGHT_ADJUST_SLIP, $totalNum);
        $pdf->Text(56, 64 + $this->HEIGHT_ADJUST_SLIP, $totalNum);
        /**
         * * GUESTS end **
         */
        
        /**
         * * Rooms start **
         */
        $pdf->SetFont('SJIS', '', 9);
        // $pdf->Text(68, 75 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_numberofroom']);
        $pdf->Text(68, 64 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_numberofroom']);
        /**
         * * Rooms end **
         */
        
        /**
         * * Adult start **
         */
        $adultNum = $bookingInfo['booking_adult_m'] + $bookingInfo['booking_adult_f'];
        $pdf->SetFont('SJIS', '', 9);
        // $pdf->Text(34, 75, $adultNum);
        // $pdf->Text(18, 75 + $this->HEIGHT_ADJUST_SLIP, $adultNum);
        $pdf->Text(18, 64 + $this->HEIGHT_ADJUST_SLIP, $adultNum);
        /**
         * * Adult end **
         */
        
        /**
         * * Child start **
         */
        $childNum = $bookingInfo['booking_child'];
        $pdf->SetFont('SJIS', '', 9);
        // $pdf->Text(61, 75, $childNum);
        // $pdf->Text(31, 75 + $this->HEIGHT_ADJUST_SLIP, $childNum);
        $pdf->Text(31, 64 + $this->HEIGHT_ADJUST_SLIP, $childNum);
        /**
         * * Child end **
         */
        
        /**
         * * CHECK IN start **
         */
        $checkIn = date('Y/m/d', strtotime($bookingInfo['booking_checkin']));
        $pdf->SetFont('SJIS', 'B', 9);
        // $pdf->Text(13, 82 + $this->HEIGHT_ADJUST_SLIP, $checkIn);
        $pdf->Text(13, 71 + $this->HEIGHT_ADJUST_SLIP, $checkIn);
        /**
         * * CHECK IN end **
         */
        
        /**
         * * CHECK OUT start **
         */
        $checkOut = date('Y/m/d', strtotime($bookingInfo['booking_checkout']));
        $pdf->SetFont('SJIS', 'B', 9);
        // $pdf->Text(40, 82 + $this->HEIGHT_ADJUST_SLIP, $checkOut);
        $pdf->Text(40, 71 + $this->HEIGHT_ADJUST_SLIP, $checkOut);
        /**
         * * CHECK OUT end **
         */
        
        /**
         * * NIGHTS start **
         */
        $pdf->SetFont('SJIS', 'B', 9);
        // $pdf->Text(68, 82 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_nights']);
        $pdf->Text(68, 71 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_nights']);
        /**
         * * NIGHTS end **
         */
        
        /**
         * * HOTEL NAME start **
         */
        // $pdf->SetFont('SJIS', 'B', 10);
        // 特殊文字対応のためUnicodeJISに変更
        $pdf->SetFont('UniJIS', 'B', 10);
        // $pdf->Text(76.5, 33.8, mb_convert_encoding($bookingInfo['booking_hotelname'], 'SJIS-win'));
        // $pdf->Text(104, 33.8 + $this->HEIGHT_ADJUST_SLIP, mb_convert_encoding($bookingInfo['booking_hotelname_eng'], 'SJIS-win'));
        
        // $pdf->SetXY(104, 28 + $this->HEIGHT_ADJUST_SLIP);
        $pdf->SetXY(104, 0 + $this->HEIGHT_ADJUST_SLIP);
        $pdf->CellFitScale(95, 10, mb_convert_encoding($bookingInfo['booking_hotelname_eng'], "UTF-16", "UTF-8"), 0, 0, 'L');
        // $pdf->CellFitScale(95,10, mb_convert_encoding($bookingInfo['booking_hotelname_eng'], 'SJIS-win'), 0, 0, 'L');
        /**
         * * HOTEL NAME end **
         */
        
        $stateCode = ($bookingInfo['booking_stateprovincecode'] == NULL) ? '' : ' ' . mb_convert_encoding($bookingInfo['booking_stateprovincecode'], 'SJIS-win');
        /**
         * * HOTEL ADDRESS start **
         */
        // $pdf->SetFont('SJIS', '', 8);
        $pdf->SetFont('UniJIS', '', 8);
        // $pdf->Text(104, 37.3 + $this->HEIGHT_ADJUST_SLIP, mb_convert_encoding($bookingInfo['booking_hoteladdress'], 'SJIS-win')
        // .' '.mb_convert_encoding($bookingInfo['booking_city'], 'SJIS-win')
        // .$stateCode //スペースは上記でつける（必要に多じて
        // .' '.mb_convert_encoding($bookingInfo['booking_country'], 'SJIS-win'));
        
        // $tmp = mb_convert_encoding($bookingInfo['booking_hoteladdress'], 'SJIS-win')
        // .' '.mb_convert_encoding($bookingInfo['booking_city'], 'SJIS-win')
        // .$stateCode //スペースは上記でつける（必要に多じて
        // .' '.mb_convert_encoding($bookingInfo['booking_country'], 'SJIS-win');
        $tmp = mb_convert_encoding($bookingInfo['booking_hoteladdress'], 'UTF-16', 'UTF-8');
        // $pdf->SetXY(104, 35.3 + $this->HEIGHT_ADJUST_SLIP);
        $pdf->SetXY(104, 24.2 + $this->HEIGHT_ADJUST_SLIP);
        $pdf->MultiCell(95, 3, $tmp, 0, 'LT');
        
        $pdf->SetFont('SJIS', '', 8);
        $tmp = mb_convert_encoding($bookingInfo['booking_city'], 'SJIS-win') . $stateCode . // スペースは上記でつける（必要に多じて
' ' . mb_convert_encoding($bookingInfo['booking_country'], 'SJIS-win');
        // $pdf->SetXY(104, 38.4 + $this->HEIGHT_ADJUST_SLIP);
        $pdf->SetXY(104, 27.3 + $this->HEIGHT_ADJUST_SLIP);
        $pdf->MultiCell(95, 3, $tmp, 0, 'LT');
        /**
         * * HOTEL ADDRESS end **
         */
        
        /**
         * * HOTEL TEL start **
         */
        $pdf->SetFont('SJIS', '', 8);
        // $pdf->Text(90, 60.2 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_hoteltel']);
        $pdf->Text(90, 49.1 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_hoteltel']);
        /**
         * * HOTEL TEL end **
         */
        
        /**
         * * ROOM TYPE start **
         */
        $pdf->SetFont('SJIS', '', 8);
        // $pdf->Text(88, 67.5 + $this->HEIGHT_ADJUST_SLIP, mb_convert_encoding($bookingInfo['booking_roomtype'], 'SJIS-win'));
        // $pdf->Text(115, 67.3 + $this->HEIGHT_ADJUST_SLIP, mb_convert_encoding($bookingInfo['booking_roomtype_eng'], 'SJIS-win'));
        $pdf->Text(115, 56.2 + $this->HEIGHT_ADJUST_SLIP, htmlspecialchars_decode(mb_convert_encoding($bookingInfo['booking_roomtype_eng'], 'SJIS-win')));
        /**
         * * ROOM TYPE end **
         */
        
        /**
         * * Booking No start **
         */
        $pdf->SetFont('SJIS', '', 8);
        // $pdf->SetTextColor(255, 0, 0);
        // $pdf->Text(100, 82 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_ean_id']);
        $pdf->Text(100, 71 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_ean_id']);
        /**
         * * Booking No end **
         */
        
        /**
         * * EAN Conf No **
         */
        $pdf->SetFont('SJIS', '', 8);
        // $pdf->Text(98, 85.8 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_confno']);
        $pdf->Text(98, 74.7 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['booking_confno']);
        /**
         * * EAN Conf No **
         */
        
        /**
         * * AGENT Name **
         */
        $pdf->SetFont('SJIS', 'B', 9);
        $pdf->SetTextColor(125, 125, 125);
        // $pdf->Text(130, 100 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_name_eng']);
        $pdf->Text(130, 89 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_name_eng']);
        /**
         * * EAN Conf No **
         */
        
        // /*** AGENT Address1 ***/
        // $pdf->SetFont('SJIS', '', 8);
        // $pdf->SetTextColor(125, 125, 125);
        // $pdf->Text(130, 103.7 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 0, 42));
        // /*** EAN Conf No ***/
        
        // if(mb_strlen($bookingInfo['agent_address_eng'])>54){
        /**
         * * AGENT Address2 **
         */
        // $pdf->SetFont('SJIS', '', 8);
        // $pdf->SetTextColor(125, 125, 125);
        // $pdf->Text(130, 106.9 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 42, 84));
        /**
         * * EAN Conf No **
         */
        
        /**
         * * AGENT PostNo **
         */
        // $pdf->SetFont('SJIS', '', 8);
        // $pdf->SetTextColor(125, 125, 125);
        // $pdf->Text(130, 110.1 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 84, 118).' ' . $bookingInfo['agent_postal']);
        /**
         * * EAN PostNo **
         */
        
        // } else {
        // /*** AGENT PostNo ***/
        // $pdf->SetFont('SJIS', '', 8);
        // $pdf->SetTextColor(125, 125, 125);
        // $pdf->Text(130, 106.9 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_postal']);
        // /*** EAN PostNo ***/
        
        // }
        
        // AGENT (address_eng + postal)
        $pdf->SetFont('SJIS', '', 8);
        // $pdf->Text(130, 103.7 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 0, 45));
        $pdf->Text(130, 92.6 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 0, 45));
        if (mb_strlen($bookingInfo['agent_address_eng']) > 45) {
            // $pdf->Text(130, 106.9 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 45, 45));
            $pdf->Text(130, 95.8 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 45, 45));
            if (mb_strlen($bookingInfo['agent_address_eng']) > 90) {
                // $pdf->Text(130, 110.1 + $this->HEIGHT_ADJUST_SLIP,
                $pdf->Text(130, 99.0 + $this->HEIGHT_ADJUST_SLIP, substr($bookingInfo['agent_address_eng'], 90, 45 - 8) . ' ' . $bookingInfo['agent_postal']);
            } else {
                // $pdf->Text(130, 110.1 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_postal']);
                $pdf->Text(130, 99.0 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_postal']);
            }
        } else {
            // $pdf->Text(130, 106.9 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_postal']);
            $pdf->Text(130, 95.8 + $this->HEIGHT_ADJUST_SLIP, $bookingInfo['agent_postal']);
        }
    }
    
    /**
     * ご利用明細PDF作成
     *
     * @param PDF_Japanese $pdf
     *            PDFインスタンス
     * @param Array $bookingInfo
     *            予約情報
     */
    function createBilldingStatementPdf($pdf, $bookingInfo) {
        
        // BilldingStatement
        // テンプレート読み込み
        $pageno = $pdf->setSourceFile($this->TEMPLATE_PATH . $this->TMP_BILL_STATE);
        $tplidx = $pdf->ImportPage(1);
        // ページを追加(新規ページ)
        $pdf->AddPage('L');
        // テンプレート設定
        $pdf->useTemplate($tplidx);
        
        /**
         * * 右上 start **
         */
        /**
         * * 発行日 start **
         */
        $outputDate = date('Y/m/d', strtotime($bookingInfo['booking_timestamp']));
        $pdf->SetTextColor(165, 165, 165);
        $pdf->SetFont('SJIS', '', 11);
        $pdf->Text(262, 13 + $this->HEIGHT_ADJUST_DETAIL, $outputDate);
        /**
         * * 発行日 end **
         */
        
        /**
         * * 管理No start **
         */
        $pdf->SetTextColor(165, 165, 165);
        $pdf->SetFont('SJIS', '', 11);
        $pdf->SetXY(262, 15 + $this->HEIGHT_ADJUST_DETAIL);
        $pdf->MultiCell(23.5, 4, $bookingInfo['booking_id'], 0, 'R');
        // $pdf->Text(262, 18.5 + $this->HEIGHT_ADJUST_DETAIL, $bookingInfo['booking_id']);
        /**
         * * 管理No end **
         */
        
        /**
         * * ご担当者様 start **
         */
        $pdf->SetTextColor(165, 165, 165);
        $pdf->SetFont('SJIS', '', 11);
        $pdf->Text(262, 23.5 + $this->HEIGHT_ADJUST_DETAIL, mb_convert_encoding($bookingInfo['booking_member_name'], 'SJIS-win'));
        /**
         * * ご担当者様 end **
         */
        
        /**
         * * 右上 end **
         */
        
        /**
         * * Agento情報 start **
         */
        
        /**
         * * 会社名 start **
         */
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', 'B', 11);
        $pdf->Text(14, 12.5 + $this->HEIGHT_ADJUST_DETAIL, mb_convert_encoding($bookingInfo['agent_name'] . " 御中", 'SJIS-win'));
        /**
         * * 会社名 end **
         */
        
        /**
         * * 郵便番号 start **
         */
        $pdf->SetTextColor(150, 150, 150);
        $pdf->SetFont('SJIS', '', 10);
        $pdf->Text(14, 17 + $this->HEIGHT_ADJUST_DETAIL, mb_convert_encoding("〒" . $bookingInfo['agent_postal'], 'SJIS-win'));
        /**
         * * 郵便番号 end **
         */
        
        /**
         * * 住所１ start **
         */
        $pdf->SetTextColor(150, 150, 150);
        $pdf->SetFont('SJIS', '', 10);
        $pdf->Text(14, 22 + $this->HEIGHT_ADJUST_DETAIL, mb_convert_encoding($bookingInfo['agent_address'], 'SJIS-win'));
        /**
         * * 住所１ end **
         */
        
        /**
         * * 住所２ start **
         */
        $pdf->SetTextColor(150, 150, 150);
        $pdf->SetFont('SJIS', '', 10);
        $pdf->Text(14, 26.8 + $this->HEIGHT_ADJUST_DETAIL, mb_convert_encoding($bookingInfo['agent_bill'], 'SJIS-win'));
        /**
         * * 住所２ end **
         */
        
        /**
         * * AgentID start **
         */
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', 'B', 10);
        $pdf->Text(14, 31.5 + $this->HEIGHT_ADJUST_DETAIL, "Agent ID : " . $bookingInfo['agent_cd']);
        /**
         * * AgentID end **
         */
        
        /**
         * * Agento情報 end **
         */
        
        /**
         * * 金額情報 start **
         */
        
        /**
         * * 宿泊費 start **
         */
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('SJIS', 'B', 16);
        $pdf->Text(45, 55 + $this->HEIGHT_ADJUST_DETAIL, "\\" . number_format($bookingInfo['booking_reservrate']));
        /**
         * * 宿泊費 end **
         */
        
        /**
         * * 税金・サービス start **
         */
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('SJIS', 'B', 16);
        $pdf->Text(132, 55 + $this->HEIGHT_ADJUST_DETAIL, "\\" . number_format($bookingInfo['booking_tax']));
        /**
         * * 税金・サービス end **
         */
        
        /**
         * * 総額 start **
         */
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('SJIS', 'B', 16);
        $pdf->Text(225, 55 + $this->HEIGHT_ADJUST_DETAIL, "\\" . number_format($bookingInfo['booking_amount']));
        /**
         * * 総額 end **
         */
        
        /**
         * * 金額情報 end **
         */
        
        /**
         * * 予約情報 start **
         */
        
        /**
         * * 予約日 start **
         */
        $outputDate = date('Y/m/d', strtotime($bookingInfo['booking_timestamp']));
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', '', 6);
        $pdf->Text(15, 85.5 + $this->HEIGHT_ADJUST_DETAIL, $outputDate);
        /**
         * * 予約日 end **
         */
        
        /**
         * * 旅程番号 start **
         */
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', '', 9);
        $pdf->SetXY(30, 82 + $this->HEIGHT_ADJUST_DETAIL);
        // $pdf->MultiCell(38,6,$bookingInfo['booking_confno'],0,'C');
        $pdf->MultiCell(38, 6, $bookingInfo['booking_ean_id'], 0, 'C');
        /**
         * * 旅程番号 end **
         */
        
        /**
         * * チェックイン start **
         */
        $checkIn = date('Y/m/d', strtotime($bookingInfo['booking_checkin']));
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', '', 8);
        $pdf->SetXY(70, 82 + $this->HEIGHT_ADJUST_DETAIL);
        $pdf->MultiCell(22.5, 6, $checkIn, 0, 'C');
        /**
         * * チェックイン end **
         */
        
        /**
         * * チェックアウト start **
         */
        $checkOut = date('Y/m/d', strtotime($bookingInfo['booking_checkout']));
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', '', 8);
        $pdf->SetXY(94, 82 + $this->HEIGHT_ADJUST_DETAIL);
        $pdf->MultiCell(20.5, 6, $checkOut, 0, 'C');
        /**
         * * チェックアウト end **
         */
        
        /**
         * * ホテル名 start **
         */
        $pdf->SetTextColor(125, 125, 125);
        // $pdf->SetFont('SJIS', '', 9);
        $pdf->SetFont('SJIS', 'B', 10);
        $pdf->SetXY(116, 82 + $this->HEIGHT_ADJUST_DETAIL);
        // $pdf->MultiCell(67.5,6,mb_convert_encoding($bookingInfo['booking_hotelname'], 'SJIS-win'),0,'C');
        $pdf->MultiCell(67.5, 6, mb_convert_encoding($bookingInfo['booking_hotelname'], 'SJIS-win'), 0, 'C');
        /**
         * * ホテル名 end **
         */
        
        /**
         * * 代表者氏名 start **
         */
        $readerName = $bookingInfo['booking_readername'] . "/" . $bookingInfo['booking_readerness'];
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', '', 9);
        $pdf->SetXY(185, 82 + $this->HEIGHT_ADJUST_DETAIL);
        $pdf->MultiCell(43, 6, mb_convert_encoding($readerName, 'SJIS-win'), 0, 'C');
        /**
         * * 代表者氏名 end **
         */
        
        /**
         * * 人数 start **
         */
        $totalNum = $bookingInfo['booking_adult_m'] + $bookingInfo['booking_adult_f'] + $bookingInfo['booking_child'];
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', 'B', 9);
        $pdf->SetXY(230, 82 + $this->HEIGHT_ADJUST_DETAIL);
        $pdf->MultiCell(28, 6, $totalNum . mb_convert_encoding("名", 'SJIS-win'), 0, 'C');
        /**
         * * 人数 end **
         */
        
        /**
         * * ルーム数 start **
         */
        $roomNum = 0;
        // for($i = 1; $i < 11; $i++)
        for($i = 1; $i < 9; $i ++) {
            if ($bookingInfo['delegate' . $i] != "") {
                $roomNum ++;
            }
        }
        $pdf->SetTextColor(125, 125, 125);
        $pdf->SetFont('SJIS', 'B', 9);
        $pdf->SetXY(260, 82 + $this->HEIGHT_ADJUST_DETAIL);
        $pdf->MultiCell(28, 6, $roomNum, 0, 'C');
        /**
         * * ルーム数 end **
         */
        
        if ($bookingInfo['booking_pkrflg']) {
            $pdf->SetTextColor(0, 0, 0);
            $pdf->SetFont('SJIS', '', 9);
            $pdf->SetXY(13, 96.2 + $this->HEIGHT_ADJUST_DETAIL);
            $pkrmessage = '※こちらの料金はパッケージ用ホテル料金の為、宿泊者には開示しないでください。';
            $pdf->MultiCell(300, 5, mb_convert_encoding($pkrmessage, 'SJIS-win'), 0, 'L');
        }
    
    /**
     * * 予約情報 end **
     */
    }
}
