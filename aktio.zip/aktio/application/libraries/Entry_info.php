<?php

if (! defined('BASEPATH'))
    exit('No direct script access allowed');

require_once APPPATH . 'libraries/pdf/japanese.php';

/**
 * PDF生成クラス
 */
class Entry_info
{
    /**
     * テンプレート格納パス<br>
     * ※コンストラクタで設定
     */
    private $TEMPLATE_PATH;
    
    /**
     * 出力格納パス<br>
     * ※コンストラクタで設定
     */
    private $OUTPUT_PATH;
    
    // *** テンプレートファイル名 *** //
    /**
     * お申込み内容確認書）
     */
    private $TMP_entry_info = 'Entry_Confirm.pdf';
    private $TMP_entry_infono = 'Entry_ConfirmNo.pdf';
    
    // *** 出力ファイル名 *** //
    /**
     * 確認書）
     */
    private $NAME_entry_info = "Entry";
    
    /**
     * コンストラクタ
     */
    function __construct() {
        $this->TEMPLATE_PATH = APPPATH . "libraries/template_pdf/";
        $this->OUTPUT_PATH = "/var/www/nssproduct/html10/pdf/"; // APPPATH."pdf/";
    }
    function pdf_entry_info($data) {
        $CI = & get_instance();
        $CI->load->library('user_agent');
        date_default_timezone_set('Asia/Tokyo');
        $fileName = "";
        // インスタンス作成
        $pdf = new PDF_Japanese();
        
        // 書き込み開始
        $pdf->Open();
        
        // PDFの内部作成
        // ファイル名設定
        // $fileName = $this->NAME_entry_info."_".$data['R00_Id']."_".$data['R00_Sei'].$data['R00_Name']."_".date('YmdHis').".pdf";
        $fileName = $this->NAME_entry_info . "_" . $data['R00_Id'] . "_" . date('YmdHis') . ".pdf";
        
        // トラベルインフォメーション作成
        // SJISフォント(MSPGothicを使用)
        $pdf->AddSJISFont('SJIS', 1);
        $pdf->AddUniSJISFont('UniJIS', 1);
        
        $this->create_entryinfo_Print($pdf, $data);
        
        // ファイルのエンコードを取得
        if ($CI->agent->is_browser('MSIE')) {
            $encode = 'SJIS-win';
        } else {
            $encode = 'UTF8';
        }
        
        // PDFの出力
        // ob_end_clean();
        // $pdf->Output();
        $pdf->Output($this->OUTPUT_PATH . mb_convert_encoding($fileName, $encode), 'F');
        // $pdf->Output(mb_convert_encoding($fileName, 'SJIS-win'), 'D');
        // PDFクローズ
        $pdf->Close();
        return $fileName;
    }
    
    /**
     * トラベルインフォメーションPDF作成
     *
     * @param PDF_Japanese $pdf
     *            PDFインスタンス
     */
    function create_entryinfo_Print($pdf, $data) {
        $CI = & get_instance();
        $CI->load->model('transport_ptn_mo');
        $CI->load->model('user_top_mo');
        $CI->load->library('convert_format');
        $page_val = 0;
        $printDate = date('Y/m/d H:i');
        // 参加者の情報を取得
        // $data['R00_Id'] = 100032323;
        $data['StaffInfo'] = $CI->user_top_mo->getStaffInfo($data['R00_Id']);
        $CourseArr = $CI->user_top_mo->getKakuteiCourseId($data['R00_Id']);
        $data['kakuteiInfo'] = $CI->user_top_mo->getKakuteCourseById($CourseArr);
        $data['participantInfo'] = $CI->user_top_mo->getUserInfo($data['R00_Id']);
        $participantInfo_array = $data['participantInfo'];
        $staffInfo = $data['StaffInfo'];
        $kakuteiInfo = $data['kakuteiInfo'];
        $DeptInfo = $CI->transport_ptn_mo->getTranportlDataDept($staffInfo['R00_Id']);
        $ArrInfo = $CI->transport_ptn_mo->getTranportlDataArr($staffInfo['R00_Id']);
        
        $i = 0;
        $lineadd = 6;
        
        $total_cost = 0;
        $lineadd2 = 13;
        $lineadd3 = 4.5;
        $lineno = 0;
        $lineno2 = 0;
        $lineno3 = 0;
        $lineno4 = 0;
        $lineno5 = 0;
        
        $add3 = 0;
        $add4 = 0;
        for($p_index = 0; $p_index < count($participantInfo_array); $p_index ++) {
            $participantInfo_p = $participantInfo_array[$p_index];
            if ($p_index % 4 == 0) {
                $pageno = $pdf->setSourceFile($this->TEMPLATE_PATH . $this->TMP_entry_info);
                $tplidx = $pdf->ImportPage(1);
                // ページを追加(新規ページ)
                $pdf->AddPage();
                // テンプレート内容の位置、幅を調整 ※useTemplateに引数を与えなければ100%表示がデフォルト
                $pdf->useTemplate($tplidx);
                
                /**
                 * * 代表者情報**
                 */
                // 代表者名
                $pdf->SetFont('SJIS', '', 10);
                $pdf->Text(50, 45, mb_convert_encoding($staffInfo['R00_Sei'] . ' ' . $staffInfo['R00_Name'], 'SJIS-win'));
                // 社員番号
                $pdf->SetFont('SJIS', '', 10);
                $pdf->Text(120, 45, mb_convert_encoding($staffInfo['R00_Id'], 'SJIS-win'));
                // 部門名
                $pdf->SetFont('SJIS', '', 10);
                $pdf->Text(50, 50, mb_convert_encoding($staffInfo['R00_Division'], 'SJIS-win'));
                // コース
                $pdf->SetFont('SJIS', '', 8);
                $pdf->Text(45, 57, mb_convert_encoding($kakuteiInfo['M01_Course_Name'] . ' ' . $kakuteiInfo['M01_Han'][1] . '班', 'SJIS-win'));
                // 旅行期間
                $pdf->SetFont('SJIS', '', 10);
                // $pdf->Text(120, 57, mb_convert_encoding(date('Y年m月d日',strtotime($kakuteiInfo['M01_Dep_Date'])).'～'.date('Y年m月d日',strtotime($kakuteiInfo['M01_Arr_Date'])), 'SJIS-win'));
                $pdf->Text(110, 57, mb_convert_encoding($CI->convert_format->ChangeJpDay($kakuteiInfo['M01_Dep_Date']) . '～' . $CI->convert_format->ChangeJpDay($kakuteiInfo['M01_Arr_Date']), 'SJIS-win'));
                $lineadd = 6;
                $lineadd2 = 13;
                $lineadd3 = 4.5;
                $lineno = 0;
                $lineno2 = 0;
                $lineno3 = 0;
                $lineno4 = 0;
                $lineno5 = 0;
                $add3 = 0;
                $add4 = 0;
                // 備考
                $pdf->SetFont('SJIS', '', 9);
                $pdf->Text(45, 247, mb_convert_encoding($staffInfo['R00_allergy_Note'], 'SJIS-win'));
            }
            /**
             * * 参加者情報・ご旅行代金**
             */
            // 渡航者情報（最大4名まで）
            
            // 氏　名
            $pdf->SetFont('SJIS', '', 10);
            $pdf->Text(35, 75 + ($lineadd * $lineno), mb_convert_encoding($participantInfo_p['R01_Sei'] . ' ' . $participantInfo_p['R01_Name'], 'SJIS-win'));
            // パスポートネーム
            $pdf->SetFont('SJIS', '', 10);
            $pdf->Text(65, 75 + ($lineadd * $lineno), mb_convert_encoding($participantInfo_p['R01_Passport_Sei'] . ' ' . $participantInfo_p['R01_Passport_Name'], 'SJIS-win'));
            // 性別
            if ($participantInfo_p['R01_Sex'] == 1) {
                $gender = "男";
            } elseif ($participantInfo_p['R01_Sex'] == 2) {
                $gender = "女";
            } else {
                $gender = "";
            }
            $pdf->SetFont('SJIS', '', 10);
            $pdf->Text(100, 75 + ($lineadd * $lineno), mb_convert_encoding($gender, 'SJIS-win'));
            // 年齢
            $pdf->SetFont('SJIS', '', 10);
            $pdf->Text(110, 75 + ($lineadd * $lineno), mb_convert_encoding(floor((date('Ymd', strtotime($kakuteiInfo['M01_Dep_Date'])) - date('Ymd', strtotime($participantInfo_p['R01_Birthday']))) / 10000) . '歳', 'SJIS-win'));
            // 旅行起点
            $pdf->SetFont('SJIS', '', 10);
            $pdf->Text(125, 75 + ($lineadd * $lineno), mb_convert_encoding($participantInfo_p['R01_Kiten'], 'SJIS-win'));
            
            setlocale(LC_MONETARY, 'ja_JP.utf8');
            for($i = 1; $i <= 5; $i ++) {
                $R01_Cost = 'R01_Cost' . $i;
                if (! empty($participantInfo_p[$R01_Cost])) {
                    $total_cost += $participantInfo_p[$R01_Cost];
                    // 追加旅行代金
                    $pdf->SetFont('SJIS', '', 10);
                    $pdf->Text(160, 75 + ($lineadd * $lineno), mb_convert_encoding(money_format("%n", $participantInfo_p[$R01_Cost]), 'SJIS-win'));
                }
            }
            $lineno += 1;
            
            /*
             *
             * 国内交通・推奨便
             *
             *
             */
            
            // 往路
            if ($DeptInfo != null || $DeptInfo != '') {
                // for ($p_index1 = 0; $p_index1 < count($DeptInfo) ; $p_index1 ++){
                $deptInfo = $DeptInfo[$p_index];
                $pdf->SetFont('SJIS', '', 10);
                $pdf->Text(20, 130 + ($lineadd2 * $lineno2), mb_convert_encoding($deptInfo['R01_Sei'] . ' ' . $deptInfo['R01_Name'], 'SJIS-win'));
                $result1 = $CI->transport_ptn_mo->getTranportlDataDeptByUserId($deptInfo);
                // var_dump($result1);exit;
                if (count($result1) == 2) {
                    $add3 = 4;
                } elseif (count($result1) == 1) {
                    $add3 = 8;
                }
                
                foreach ( $result1 as $key_no => $deptResult ) {
                    
                    // 日付
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(44, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($CI->convert_format->ChangeJpDay_NoYear($deptResult['R07_Transport_Date']), 'SJIS-win'));
                    // 便名
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(65, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($deptResult['R07_Transport_Name'], 'SJIS-win'));
                    
                    // 出発地
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(85, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($deptResult['R07_Transport_Place'], 'SJIS-win'));
                    // 時刻(出発時刻)
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(110, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($deptResult['R07_Transport_Dep_Time'], 'SJIS-win'));
                    // 到着地
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(125, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($deptResult['R07_Transport_Arr_Place'], 'SJIS-win'));
                    // 到着時刻
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(150, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($deptResult['R07_Transport_Arr_Time'], 'SJIS-win'));
                    // 備考
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(160, 128 + ($lineadd3 * $lineno3) + ($add3 * $lineno2), mb_convert_encoding($deptResult['R07_Note'], 'SJIS-win'));
                    $lineno3 += 1;
                }
                
                // }
                $lineno2 += 1;
            }
            
            if ($ArrInfo != null || $ArrInfo != '') {
                // 復路
                // for ($p_index1 = 0; $p_index1 < count($ArrInfo) ; $p_index1 ++){
                $arrInfo = $ArrInfo[$p_index];
                $pdf->SetFont('SJIS', '', 10);
                $pdf->Text(20, 195 + ($lineadd2 * $lineno4), mb_convert_encoding($arrInfo['R01_Sei'] . ' ' . $arrInfo['R01_Name'], 'SJIS-win'));
                $result2 = $CI->transport_ptn_mo->getTranportlDataArrByUserId($arrInfo);
                if (count($result2) == 2) {
                    $add4 = 4;
                } elseif (count($result2) == 1) {
                    $add4 = 8;
                }
                foreach ( $result2 as $key_no => $arrResult ) {
                    // 日付
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(44, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($CI->convert_format->ChangeJpDay_NoYear($arrResult['R07_Transport_Date']), 'SJIS-win'));
                    // 便名
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(65, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($arrResult['R07_Transport_Name'], 'SJIS-win'));
                    
                    // 出発地
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(85, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($arrResult['R07_Transport_Place'], 'SJIS-win'));
                    // 時刻(出発時刻)
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(110, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($arrResult['R07_Transport_Dep_Time'], 'SJIS-win'));
                    // 到着地
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(125, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($arrResult['R07_Transport_Arr_Place'], 'SJIS-win'));
                    // 到着時刻
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(150, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($arrResult['R07_Transport_Arr_Time'], 'SJIS-win'));
                    // 備考
                    $pdf->SetFont('SJIS', '', 8);
                    $pdf->Text(160, 192 + ($lineadd3 * $lineno5) + ($add4 * $lineno4), mb_convert_encoding($arrResult['R07_Note'], 'SJIS-win'));
                    $lineno5 += 1;
                }
                $lineno4 += 1;
            }
        }
        // end foreach
        // 　　ご旅行代金　合計　　　
        
        $pdf->SetFont('SJIS', '', 10);
        $pdf->Text(160, 97, mb_convert_encoding(money_format("%n", $total_cost), 'SJIS-win'));
    } // end of createConfSlipPdf
}
