<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 */
class ExcelInvoice extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    /*
     *
     * 台帳
	 *$Data :検索データ結果　、 $CourseDataMaster:コース情報
     */
    public function getExcelInvoice($Data, $CourseDataMaster) {
        date_default_timezone_set("Asia/Tokyo");
        $objPHPExcel = PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Invoice.xlsx");
        $objPHPExcel->setActiveSheetIndex(0);
        $objSheet = $objPHPExcel->getActiveSheet();
        $objSheet->setTitle("Invoice");
        $this->createContentSheet($Data, $CourseDataMaster, $objSheet);
        $filename = 'Invoice.xlsx';
        header("Content-Type: application/octet-stream"); // ダウンロードの指示
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0'); // no cache
        ob_end_clean(); // ファイル破損エラー防止
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
    private function createContentSheet($Data, $CourseDataMaster, PHPExcel_Worksheet $objSheet) {
        $CI = & get_instance();
        $CI->load->library('convert_format');
		$CI->load->model('invoice_mo');
        // コース名
        $objSheet->setCellValue('A2', $CourseDataMaster['M01_Course_Name']);
        $objSheet->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        //例2017年05月12日(金)～2017年05月17日(水)
        $M01_Dep_Date = $CI->convert_format->ChangeJpDay($CourseDataMaster['M01_Dep_Date']);
        $M01_Arr_Date = $CI->convert_format->ChangeJpDay($CourseDataMaster['M01_Arr_Date']);		
        $objSheet->setCellValue('A3', $M01_Dep_Date . '～' . $M01_Arr_Date);		
		// フライト情報
        $go_air = isset($CourseDataMaster['M011_Go_Air'])?('往路フライト：' . $CourseDataMaster['M011_Go_Air']):'往路フライト：';
        $objSheet->setCellValue('A4', $go_air);
        $rtn_air = isset($CourseDataMaster['M011_Rtn_Air'])?('復路フフライト：' . $CourseDataMaster['M011_Rtn_Air']):'復路フフライト';
        $objSheet->setCellValue('D4', $rtn_air);	
        $i = 9;	
        foreach ( $Data as $row ) {
			if($row['R01_Id'] != '' ||$row['R01_Id'] != NULL){
				$total = 0;	
				$opt_cost1=0;
				$opt_cost2=0;
				$opt_cost3=0;
				$opt_cost4=0;
				$opt_cost5=0;
				$opt_cost6=0;
				$opt_cost7=0;
				$opt_cost8=0;
				$before_stay_cost1 =0;
				$before_stay_cost2 =0;
				$before_stay_cost3 =0;
				$after_stay_cost1 =0;
				$after_stay_cost2 =0;
				$after_stay_cost3 =0;
				$payment_total=0;
				if($row['R01_Plan'] == 0){
					$parti_cnt     = $CI->invoice_mo->getParticaipate($row['R01_Id']).'人';
					$group_no      = $row['R00_Group_No'];
					$one_room_wish = $row['R00_1Room_wish'];
					$R00_allergy_Note = $row['R00_allergy_Note'];
					$before_stay = $this->hotel_reserve($row['R01_Id'], 1);
					$after_stay = $this->hotel_reserve($row['R01_Id'], 2);
					
					if(count($before_stay)>0){
						foreach($before_stay as $stay){
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==1){
								$before_stay_cost1 = $stay['R09_Room_Price'];							
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==2){
								$before_stay_cost2 = $stay['R09_Room_Price'];							
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==3){
								$before_stay_cost3 = $stay['R09_Room_Price'];							
							}
						}
						
					}
					if(count($after_stay)>0){
						foreach($after_stay as $stay){
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==1){
								$after_stay_cost1 = $stay['R09_Room_Price'];
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==2){
								$after_stay_cost2 = $stay['R09_Room_Price'];							
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==3){
								$after_stay_cost3 = $stay['R09_Room_Price'];
							}
						}
					}
				}else{
					$parti_cnt     = '';
					$group_no      = '';
					$one_room_wish = '';
					$R00_allergy_Note = '';
					$before_stay_cost1 = 0;
					$before_stay_cost2 = 0;
					$before_stay_cost3 = 0;
					$after_stay_cost1 = 0;
					$after_stay_cost2 = 0;
					$after_stay_cost3 = 0;
				}		
				$user_id = $row['R01_Id'] . '-' . ($row['R01_Plan'] + 1);
				$objSheet->setCellValue('A' . $i, $user_id);//IDNO
				$objSheet->setCellValue('B' . $i, $row['R00_Company']);//会社名
				//$objSheet->setCellValue('C' . $i, $row['R00_Dest_Kbn'].$row['R00_Dest_Code'].$row['R00_Han'].$row['R00_Dep_Id'].$row['R00_Air_Program'] );//コースコード
				//$objSheet->setCellValue('D' . $i, $M01_Dep_Date);//出発日
				$objSheet->setCellValue('C' . $i, $row['R01_Sei']);//姓
				$objSheet->setCellValue('D' . $i, $row['R01_Name']);//名
				$objSheet->setCellValue('E' . $i, $row['R01_Sei_Kana']);//姓_カナ
				$objSheet->setCellValue('F' . $i, $row['R01_Name_Kana']);//名_カナ
				/*if($row['R00_Dest_Kbn'] ==2){
					$objSheet->setCellValue('E' . $i, $row['R01_Sei_Eng']);//姓_英字
					$objSheet->setCellValue('F' . $i, $row['R01_Name_Eng']);//名_英字
				}elseif($row['R00_Dest_Kbn'] ==1){
					$objSheet->setCellValue('E' . $i, $row['R01_Passport_Sei']);//姓_英字
					$objSheet->setCellValue('F' . $i, $row['R01_Passport_Name']);//名_英字
				}*/
				
				
				//$objSheet->setCellValue('G' . $i, $row['R01_Nationality']);//国籍
				if($row['R01_Plan'] ==0){
					$kubun = '社員';
				}else{
					$kubun = '同行者'.$row['R01_Plan'];
				}
				$objSheet->setCellValue('G' . $i, $kubun);//性別
				
				$optional_tour = $this->getOptionalTour($row['R01_Id'], $row['R01_Plan'], $row['R01_Birthday'], $CourseDataMaster['M01_Dep_Date']);
				if(count($optional_tour)>0){
					foreach($optional_tour as $optKey => $optVal){
						if($optKey ==1){						
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('P' . $i, $optVal[0]['R04_Optional_Tour_Name']);	
								}							
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('AP' . $i, $optVal[0]['opt_price']);//ＯＰ1代金1
									$opt_cost1=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('AQ' . $i, $optVal[0]['R04_Cancel_Cost']);//ＯＰ1キャンセル代金1
									$opt_cost1=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('AP' . $i, 0);
									$opt_cost1= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('Q' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('AR' . $i, $optVal[1]['opt_price']);
									$opt_cost2=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('AS' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost2=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('AR' . $i, 0);
									$opt_cost2= 0;
								}			
							}	
						
						}elseif($optKey ==2){
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('R' . $i, $optVal[0]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('AT' . $i, $optVal[0]['opt_price']);
									$opt_cost3=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('AU' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost3=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('AT' . $i, 0);
									$opt_cost3= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('S' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('AV' . $i, $optVal[1]['opt_price']);
									$opt_cost4=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('AW' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost4=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('AV' . $i, 0);
									$opt_cost4= 0;
								}									
							}			
						}elseif($optKey ==3){
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('T' . $i, $optVal[0]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('AX' . $i, $optVal[0]['opt_price']);
									$opt_cost5=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('AY' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost5=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('AX' . $i, 0);
									$opt_cost5= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('U' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('AZ' . $i, $optVal[1]['opt_price']);
									$opt_cost6=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BA' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost6=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('AZ' . $i, 0);
									$opt_cost6= 0;
								}								
							}			
						}elseif($optKey ==4){
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('V' . $i, $optVal[0]['R04_Optional_Tour_Name']);
								}
								
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('BB' . $i, $optVal[0]['opt_price']);
									$opt_cost7=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BC' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost7=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BB' . $i, 0);
									$opt_cost7= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('W' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('BD' . $i, $optVal[1]['opt_price']);
									$opt_cost8=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BE' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost8=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BD' . $i, 0);
									$opt_cost8= 0;
								}	
								
							}		
						}
					}
				}
				$total +=$opt_cost1;
				$total +=$opt_cost2;
				$total +=$opt_cost3;
				$total +=$opt_cost4;
				$total +=$opt_cost5;
				$total +=$opt_cost6;
				$total +=$opt_cost7;
				$total +=$opt_cost8;
				$objSheet->setCellValue('X' . $i, $row['R01_Cost3']);//自己負担旅行代金
				$total += $row['R01_Cost3'];			
				$objSheet->setCellValue('Y' . $i, $row['R01_Cost2']);//会費不足代金
				$total += $row['R01_Cost2'];
				$objSheet->setCellValue('AC' . $i, $row['R01_Cost4']);//一人部屋追加代金
				$total += $row['R01_Cost4'];
				$objSheet->setCellValue('Z' . $i, $row['R01_Cost8']);//ビジネスクラス追加代金
				$total += $row['R01_Cost8'];
				$objSheet->setCellValue('AA' . $i, $row['R01_Cancel_Cost']);//旅行キャンセル料
				$total += $row['R01_Cancel_Cost'];
				$objSheet->setCellValue('AB' . $i, $row['R01_Cost9']);//旅行変更料
				$total += $row['R01_Cost9'];
				$objSheet->setCellValue('AD' . $i, $row['R01_Cost10']);//自己負担交通代金
				$total += $row['R01_Cost10'];
				$objSheet->setCellValue('AE' . $i, $row['R01_Cost11']);//交通変更取消料
				$total += $row['R01_Cost11'];
				$objSheet->setCellValue('AF' . $i, ($row['R01_Cost5']+$row['R01_Cost6']+$row['R01_Cost7']));//その他	
				$total += $row['R01_Cost5'];			
				$total += $row['R01_Cost6'];			
				$total += $row['R01_Cost7'];			
				$objSheet->setCellValue('AG' . $i, $before_stay_cost1 );//前泊１	
				$total += $before_stay_cost1;			
				$objSheet->setCellValue('AH' . $i, $before_stay_cost2 );//前泊２	
				$total += $before_stay_cost2;			
				$objSheet->setCellValue('AI' . $i, $before_stay_cost3 );//前泊３
				$total += $before_stay_cost3;
				$objSheet->setCellValue('AJ' . $i, $after_stay_cost1 );//後泊１	
				$total +=  $after_stay_cost1;			
				$objSheet->setCellValue('AK' . $i, $after_stay_cost2 );//後泊２		
				$total +=  $after_stay_cost2;
				$objSheet->setCellValue('AL' . $i, $after_stay_cost3 );//後泊３
				$total +=  $after_stay_cost3;
				//if($row['R00_Dest_Code'] == 'HNL'){//ESTA料金
				if($row['M00_VISA_flag'] == 1){//ESTA料金
					$esta_cost = $row['R01_Cost1'];
				}else{
					$esta_cost = 0;
				}
				$total +=  $esta_cost;
				$objSheet->setCellValue('AM' . $i, $esta_cost );
				//if($row['R00_Dest_Code'] == 'SYD'){//ETAS料金
				if($row['M00_VISA_flag'] == 2){//ETAS料金
					$etas_cost = $row['R01_Cost1'];
				}else{
					$etas_cost = 0;
				}
				$total +=  $etas_cost;
				$objSheet->setCellValue('AN' . $i, $etas_cost );
				
				
			
				if($row['R01_Cancel_Day'] != NULL || $row['R01_Cancel_Day'] != ''){
					$objSheet->setCellValue('BH' . $i,  $row['R01_Cancel_Day'] );//	//キャンセル日	
					$diff_can_day = $this->diff_day($row['R01_Cancel_Day'],$CourseDataMaster['M01_Dep_Date']);
					$objSheet->setCellValue('BI' . $i, $diff_can_day.'日');//CXL出発の何日前
				}
				//全員の合計金額
				if($row['R01_Plan']==0){
					$all_total = $this->total_expense($row['R01_Id']);
					$all_total += $before_stay_cost1 + $before_stay_cost2+ $before_stay_cost3+$after_stay_cost1+$after_stay_cost2+$after_stay_cost3;				
					$opt_all_total = $CI->invoice_mo->getOptAllTotal($row['R01_Id']);
					$opt_cancel_total = $CI->invoice_mo->getOptCancelTotal($row['R01_Id']);
					$all_total += $opt_all_total+$opt_cancel_total;
					$result = $all_total-$payment_total;
					$objSheet->setCellValue('BG' . $i, $all_total);//請求総合計
					//$objSheet->setCellValue('CP' . $i, $result);//差額
				}
				//$objSheet->setCellValue('CO' . $i, $payment_total);//入金合計						
				$objSheet->setCellValue('BF' . $i, $total);//請求合計			
				$payment_total=0;
				$total =0;			
				$all_total=0;
				$i ++;
			}
        }
    }
	function getOptionalTour($R04_Id, $R01_Plan, $R01_Birthday, $M01_Dep_Date){
		$CI = & get_instance();        
		$CI->load->model('invoice_mo');			
		$opt_result = $CI->invoice_mo->getOptionalTour( $R04_Id, $R01_Plan);
		$optArr = array();
		$NewOptArr = array();
		if(count($opt_result)>0){
			$j =0;
			foreach($opt_result as $opt){
				/*if($opt['R04_Optional_Kibou_Date'] == 1){
					$optArr[$opt['R04_Optional_Kibou_Date']][$j]=$opt;
					$optArr[$opt['R04_Optional_Kibou_Date']][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				}elseif($opt['R04_Optional_Kibou_Date'] == 2){
					$optArr['2'][$j]=$opt;
					$optArr['2'][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
					
				}elseif($opt['R04_Optional_Kibou_Date'] == 3){
					$optArr['3'][$j]=$opt;
					$optArr['3'][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				}elseif($opt['R04_Optional_Kibou_Date'] == 4){
					$optArr['4'][$j]=$opt;
					$optArr['4'][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				}*/
				$optArr[$opt['R04_Optional_Kibou_Date']][$j]=$opt;
				$optArr[$opt['R04_Optional_Kibou_Date']][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				$j++;
			}
		}	
		
		if(count($optArr)>0){
			foreach ($optArr as $key=>$val){
				foreach ($val as $key1=>$val1){
					$NewOptArr[$key][]=$val1;
				}
			}
		}
		return $NewOptArr;
	}
	/*
	*
	*
	*/
	public function hotel_reserve($R09_ReserveId, $R09_Type){
		$CI = & get_instance();        
		$CI->load->model('hotel_mo');
		$hotel_result = $CI->hotel_mo->getR09_Hotel_Reserve($R09_ReserveId, $R09_Type);
		return $hotel_result;
	}
	/*
	*
	*各位のオプションナルツーア取得
	*/
	public function getOptPrice($optional_tour, $R01_Birthday, $M01_Dep_Date){
		$age = floor((date('Ymd', strtotime($M01_Dep_Date)) - date('Ymd', strtotime($R01_Birthday))) / 10000);
		$opt_price =0;
		if ($age <= $optional_tour['M08_Child1_Limit_Max'] && $age >= $optional_tour['M08_Child1_Limit_Min']) {
			$opt_price = $optional_tour['M08_Optional_Cost_Child1'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Child1_haya'];
		}elseif ($age <= $optional_tour['M08_Child2_Limit_Max'] && $age >= $optional_tour['M08_Child2_Limit_Min']) {
			$opt_price = $optional_tour['M08_Optional_Cost_Child2'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Child2_haya'];
		}elseif($age <= $optional_tour['M08_Infant_Limit_Max'] && $age >= $optional_tour['M08_Infant_Limit_Min']){
			$opt_price = $optional_tour['M08_Optional_Cost_Infant'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Infant_haya'];
		}elseif($age > $optional_tour['M08_Child1_Limit_Max']){
			$opt_price = $optional_tour['M08_Optional_Cost_Adult'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Adult_haya'];			
		}
		if($opt_price==''){
			$opt_price=0;
		}		
		return round($opt_price, -1);
	}
	/*
	*入金取得
	*
	*/
	public function getPayment($R13_Id, $R13_Seq){
		$CI = & get_instance();        
		$CI->load->model('invoice_mo');
		$paymentArr = $CI->invoice_mo->getPayment($R13_Id, $R13_Seq);
		return $paymentArr;
	}
	/*
	*
	*/
	public function getPaymentMethod($data){
		$payment_method =array(
			'1'=>'銀行振込み',
			'2'=>'クレジットカード'
		);			
		return $payment_method[$data];
	}
	/*
	*CXL出発の何日前
	*/
	public function diff_day($day1, $day2){
		$dept_date = strtotime($day1);
		$can_date = strtotime($day2);
		$datediff = $can_date - $dept_date;		
		return floor($datediff / (60 * 60 * 24));
	}
	/*
	*全員合計
	*
	*/
	public function total_expense($R01_Id){
		$CI = & get_instance();        
		$CI->load->model('invoice_mo');
		$total_exp_arr = $CI->invoice_mo->getTotal_expense($R01_Id);	
		$total_exp = 0;
		foreach( $total_exp_arr as $data ){
			$total_exp += $data['R01_Cost1'];
			$total_exp += $data['R01_Cost3'];
			$total_exp += $data['R01_Cost2'];
			$total_exp += $data['R01_Cost4'];
			$total_exp += $data['R01_Cost8'];
			$total_exp += $data['R01_Cancel_Cost'];
			$total_exp += $data['R01_Cost9'];
			$total_exp += $data['R01_Cost10'];
			$total_exp += $data['R01_Cost11'];
			$total_exp += $data['R01_Cost5'];
			$total_exp += $data['R01_Cost6'];
			$total_exp += $data['R01_Cost7'];
		}
		return $total_exp;
	}
}