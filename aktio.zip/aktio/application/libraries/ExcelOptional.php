<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');
set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * ＫＮＴのお客さんからオプショナルエクセルファイルノデーターをデーターベースにインポートする為、ライブラリー作成する
 * 新しいデーター対応
 * エクセルファイルから内容を読込んでデーターベースに保存する
 * @author VienCQ
 */
class ExcelOptional extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * エクセルファイルから内容を読み込む
     * そしてデーターベースに保存する
     */
    public function readExcelData($readFile) {
        date_default_timezone_set('Asia/Tokyo');
        //Read spreadsheeet workbook
        $inputFileType = PHPExcel_IOFactory::identify($readFile);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($readFile);
        //Get worksheet dimensions
        $objPHPExcel->getSheet(0);
        // 配列形式で返す
        $dataExcel = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
        
        // エクセルの1行目からコース一覧を取得する
        if ($dataExcel != null) {
            foreach ($dataExcel as $rowIndex => $dataRows) {
                if ($rowIndex == 1) {
                    $courseListStr = $dataRows['A'];
                    break;
                }
            }
        }
        $courseList = $this->getCourseListFromExcel($courseListStr);
        // コースプライマリキーを取得する
        $coursePrimaries = $this->getCoursePrimaryKeyByCourseList($courseList);
        
        // エクセルからオプショナルデーター取得する
        $optionalData = $this->getOptionalDataFromExcel($dataExcel);
        $optionalConverts = $this->convertOptionalDataFromExcel($optionalData);
        // データーベースに保存する
        $this->saveOptionalData($optionalConverts, $coursePrimaries);
    }
    
    private function saveOptionalData($optionalConverts , $coursePrimaries) {
        // モデルを利用する為、$CIインスタンスを使う
        $CI = & get_instance();
        $CI->load->model('operating_mo');
        if ($optionalConverts != null) {
            $optional = array();
            foreach ($optionalConverts as $optionalItem) {
                $indexNew = 1;
                foreach ($coursePrimaries as $coursePrimaryArr) { // すべてコース一覧
                    $dest = $this->getCourseDestByPrimary($coursePrimaryArr);
                    $optionalCode = array('M08_Optional_Tour_Code' => $optionalItem['M08_Optional_Tour_Code']);
                    $param = array_merge($dest , $optionalCode);

                    if ($CI->operating_mo->isExistOptionalByCourseDest($param) > 0) {
                        foreach ($coursePrimaryArr as $coursePrimary) {
                            $courseNewPrimary = $this->convertCoursePrimary($coursePrimary);
                            $optional = array_merge($courseNewPrimary , $optionalItem);

                            if ($CI->operating_mo->isExistOptionalByCourse($courseNewPrimary , $optional) > 0) {
                                $optionalSeq = $CI->operating_mo->getOptionalSeqByCourse($courseNewPrimary , $optional);
                                $m08Seq = array( 'M08_Seq' => $indexNew );
                                $optionals = array_merge($optional , $m08Seq);
                                $CI->operating_mo->updateOptionalByCourseAndSeq($optionals);
                            } else {
                                $seqMax = $CI->operating_mo->getMaxSeqOfOptionalById($optional['M08_Optional_Tour_Code']);
                                $seqNew = $seqMax + 1;
                                $m08Seq = array( 'M08_Seq' => $seqNew );
                                $optionals = array_merge($optional , $m08Seq);
                                $CI->operating_mo->insertNewOptional($optionals);
                            }
                        }
                    } else {
                        foreach ($coursePrimaryArr as $coursePrimary) { //
                            $courseNewPrimary = $this->convertCoursePrimary($coursePrimary);
                            $optional = array_merge($courseNewPrimary , $optionalItem);
                            // 新しいデーター場合
                            $m08Seq = array( 'M08_Seq' => $indexNew );
                            $optionals = array_merge($optional , $m08Seq);
                            $CI->operating_mo->insertNewOptional($optionals);
                            $indexNew++;
                        }
                    }
                }
            }
        }
    }

    private function getCourseDestByPrimary($coursePrimaryArr) {
        $dest = array();
        foreach ($coursePrimaryArr as $coursePrimary) {
            $dest = array(
                'M08_Dest_kbn' => $coursePrimary['M01_Dest_Kbn'] ,
                'M08_Dest_Code' => $coursePrimary['M01_Dest_Code']
            );
            break;
        }
        return $dest;
    }
    
    private function convertCoursePrimary($coursePrimary) {
        $courseNewPrimary = array();
        foreach ($coursePrimary as $key => $course) {
            $newKey = str_replace('M01', 'M08', $key);
            if ($newKey == 'M08_Dest_Kbn') {
                $newKey = 'M08_Dest_kbn';
            }
            $courseNewPrimary[$newKey] = $course;
        }
        return $courseNewPrimary;
    }
    
    /**
     * コース文字から配列に交換する
     */
    private function getCourseListFromExcel($courseListStr) {
        $courseList = array();
        if (strpos($courseListStr, '、') !== false) { // コンマがある
            $courseList = explode('、' , $courseListStr);
        } else {
            $courseList[] = $courseListStr;
        }
        return $courseList;
    }

    /**
     * データーベースから適当なコース(1HNL01等)のプライマリキーを取得する
     */
    private function getCoursePrimaryKeyByCourseList($courseList) {
        // モデルを利用する為、$CIインスタンスを使う
        $CI = & get_instance();
        $CI->load->model('operating_mo');
        if ($courseList != null) {
            $primaries = array();
            foreach ($courseList as $courseKey) {
                $primaries[] = $CI->operating_mo->getCoursePrimaryKeyByCourseCode($courseKey);
            }
            return $primaries;
        } else {
            return null;
        }
    }

    /**
     *　オプショナルではないデーターを外す（6行以上）、配列データーに入り、オプショナルデーター配列に交換する
     * @param $dataExcel エクセルのデーター
     * @return array | null データーではない以外、配列データーに入り、オプショナルデーター配列に交換する
     */
    private function getOptionalDataFromExcel($dataExcel) {
        if ($dataExcel != null) {
            $optionalData = array();
            foreach ($dataExcel as $rowIndex => $dataRows) {
                if ($rowIndex < 6) continue;
                $optionalData[] = $dataRows;
            }
            return $optionalData;
        }
        return null;
    }

    /**
     *　numericではないデーターを外す、「0~9」と「.」のみデーターを取得する
     * @param string $costStr　エクセルデーター
     * @return string $cost 新しいコストデーター
     */
    private function convertStringToNumeric($costStr) {
        $cost = '';
        if ($costStr != '') {
            $cost = preg_replace("/[^0-9.]/", "", $costStr);
        }
        return $cost;
    }

    /**
     *  お客様選択からデーター配列に交換する
     * @param string $kibouStr エクセルのお客様選択項目データー
     * @return array | null $kibou データーベースフィルドの通りに適当な配列データー
     */
    private function convertOptionalKibou($kibouStr) {
        // 初期化
        $kibouOpt = array(
            'M08_Time'  => '0' ,
            'M08_Time1' => '0' ,
            'M08_Time2' => '0' ,
            'M08_Time3' => '0' ,
            'M08_Time4' => '0' ,
            'M08_Time5' => '0' ,
            'M08_Time6' => '0' ,
            'M08_Tour_Option_Select_Cnt' => '0' ,
            'M08_Tour_Option_Select_Type' => '' ,
            'M08_Tour_Option1_Code'  => '' ,
            'M08_Tour_Option1_Name'  => '' ,
            'M08_Tour_Option2_Code'  => '' ,
            'M08_Tour_Option2_Name'  => '' ,
            'M08_Tour_Option3_Code'  => '' ,
            'M08_Tour_Option3_Name'  => '' ,
            'M08_Tour_Option4_Code'  => '' ,
            'M08_Tour_Option4_Name'  => '' ,
            'M08_Tour_Option5_Code'  => '' ,
            'M08_Tour_Option5_Name'  => '' ,
            'M08_Tour_Option6_Code'  => '' ,
            'M08_Tour_Option6_Name'  => '' ,
            'M08_Tour_Option7_Code'  => '' ,
            'M08_Tour_Option7_Name'  => '' ,
            'M08_Tour_Option8_Code'  => '' ,
            'M08_Tour_Option8_Name'  => '' ,
            'M08_Tour_Option9_Code'  => '' ,
            'M08_Tour_Option9_Name'  => '' ,
            'M08_Tour_Option10_Code' => '' ,
            'M08_Tour_Option10_Name' => ''
        );
        // $kibouStrの中で '|' シングルがあるかどうかチェックする
        if (strpos(trim($kibouStr) , '|') !== false) { // ある場合 (title|a or b or c等)
            $kibouOpt['M08_Tour_Option_Select_Type'] = 'check';
            
            $kibouArr = explode('|', trim($kibouStr));
            $kibouKey = $kibouArr[0];
            $kibouValue = $kibouArr[1];
            // 希望開始時間 | 希望時間選択
            if (strpos(trim($kibouKey), '希望') !== false && strpos(trim($kibouKey), '時間') !== false) {
                if (strpos(trim($kibouKey) , '入') !== false) {
                    $kibouOpt['M08_Time'] = '0';
                } else {
                    $kibouOpt['M08_Time'] = '1';
                }
                
                // convert value
                if (strpos(trim($kibouArr[1]) , trim('or'))) {
                    $kibouItemArr = explode('or', trim($kibouArr[1]));
                    foreach ($kibouItemArr as $key => $kibouItem) {
                        if ($key > 5) break;
                        $kibouOpt['M08_Time' . ($key + 1)] = trim($kibouItem);
                    }
                }
            } else {
                // get numeric in kibouKey
                $select_cnt = $this->convertStringToNumeric($kibouKey);
                if ($select_cnt != '') {
                    $kibouOpt['M08_Tour_Option_Select_Cnt'] = $select_cnt;
                } else {
                    $kibouOpt['M08_Tour_Option_Select_Cnt'] = '1';
                }
                if (strpos(trim($kibouArr[1]) , trim('or'))) {
                    $kibouItemArr = explode('or', trim($kibouArr[1]));
                    foreach ($kibouItemArr as $key => $kibouItem) {
                        if ($key > 10) break;
                        $kibouOpt['M08_Tour_Option' . ($key + 1) . '_Name'] = trim($kibouItem);
                    }
                }
            }
        } else {
            if (strpos(trim($kibouStr) , '希望開始時間') !== false) { // 希望開始時間のみある
                $kibouOpt['M08_Time'] = '1';
            }
            // 別のパータンならデフォルトデーターにセットする
        }
        return $kibouOpt;
    }

    /**
     * 
     * @param  [type]
     * @return [type]
     */
    private function convertOptionalDataFromExcel($optionalData) {
        if ($optionalData != null) {
            $optionals = array();
            foreach ($optionalData as $dataRow) {
                // 大人料金1
                $M08_Optional_Cost_Adult_Str = isset($dataRow['M']) ? trim($dataRow['M']) : '';
                $M08_Optional_Cost_Adult = $this->convertStringToNumeric($M08_Optional_Cost_Adult_Str);
                // 大人早期割引
                $M08_Optional_Cost_Adult_haya_Str = isset($dataRow['N']) ? trim($dataRow['N']) : '';
                $M08_Optional_Cost_Adult_haya = $this->convertStringToNumeric($M08_Optional_Cost_Adult_haya_Str);
                // 子供料金1
                $M08_Optional_Cost_Child1_Str = isset($dataRow['Q']) ? trim($dataRow['Q']) : '';
                $M08_Optional_Cost_Child1 = $this->convertStringToNumeric($M08_Optional_Cost_Child1_Str);
                // 子供1早期割引
                $M08_Optional_Cost_Child1_haya_Str = isset($dataRow['R']) ? trim($dataRow['R']) : '';
                $M08_Optional_Cost_Child1_haya = $this->convertStringToNumeric($M08_Optional_Cost_Child1_haya_Str);
                // 子供料金2
                $M08_Optional_Cost_Child2_Str = isset($dataRow['U']) ? trim($dataRow['U']) : '';
                $M08_Optional_Cost_Child2 = $this->convertStringToNumeric($M08_Optional_Cost_Child2_Str);
                // 子供2早期割引
                $M08_Optional_Cost_Child2_haya_Str = isset($dataRow['V']) ? trim($dataRow['V']) : '';
                $M08_Optional_Cost_Child2_haya = $this->convertStringToNumeric($M08_Optional_Cost_Child2_haya_Str);

                // 子供料金3
                $M08_Optional_Cost_Infant_Str = isset($dataRow['Y']) ? trim($dataRow['Y']) : '';
                $M08_Optional_Cost_Infant = $this->convertStringToNumeric($M08_Optional_Cost_Infant_Str);
                // 子供3早期割引
                $M08_Optional_Cost_Infant_haya_Str = isset($dataRow['Z']) ? trim($dataRow['Z']) : '';
                $M08_Optional_Cost_Infant_haya = $this->convertStringToNumeric($M08_Optional_Cost_Infant_haya_Str);
                
                // お客様選択
                $kibouStr = isset($dataRow['AF']) ? trim($dataRow['AF']) : '';
                $kibouOpt = $this->convertOptionalKibou($kibouStr);
                
                $M08_Tour_1Day = isset($dataRow['A']) ? ( (trim($dataRow['A']) == '×') ? 2 : 1 ) : ''; // 1日目
                $M08_Tour_2Day = isset($dataRow['B']) ? ( (trim($dataRow['B']) == '×') ? 2 : 1 ) : ''; // 2日目
                $M08_Tour_3Day = isset($dataRow['C']) ? ( (trim($dataRow['C']) == '×') ? 2 : 1 ) : ''; // 3日目
                $M08_Tour_4Day = isset($dataRow['D']) ? ( (trim($dataRow['D']) == '×') ? 2 : 1 ) : ''; // 4日目
                $M08_Tour_5Day = isset($dataRow['E']) ? ( (trim($dataRow['E']) == '×') ? 2 : 1 ) : ''; // 5日目
                
                if ($M08_Tour_1Day == null && $M08_Tour_2Day == null && $M08_Tour_3Day == null && $M08_Tour_4Day == null && $M08_Tour_5Day == null) continue;
                
                // Mang thong tin trong M08_Optional
                $otional = array(
                    'M08_Tour_1Day' => isset($dataRow['A']) ? ( (trim($dataRow['A']) == '×') ? 2 : 1 ) : '' , // 1日目
                    'M08_Tour_2Day' => isset($dataRow['B']) ? ( (trim($dataRow['B']) == '×') ? 2 : 1 ) : '' , // 2日目
                    'M08_Tour_3Day' => isset($dataRow['C']) ? ( (trim($dataRow['C']) == '×') ? 2 : 1 ) : '' , // 3日目
                    'M08_Tour_4Day' => isset($dataRow['D']) ? ( (trim($dataRow['D']) == '×') ? 2 : 1 ) : '' , // 4日目
                    'M08_Tour_5Day' => isset($dataRow['E']) ? ( (trim($dataRow['E']) == '×') ? 2 : 1 ) : '' , // 5日目
                    
                    'M08_Optional_Page_Start' => isset($dataRow['F']) ? trim($dataRow['F']) : '0' , // 掲載ページ（開始）
                    'M08_Optional_Page_End' => isset($dataRow['G']) ? trim($dataRow['G']) : '0' , // 掲載ページ（終了）
                    'M08_Optional_Title' => isset($dataRow['H']) ? trim($dataRow['H']) : '' , // 大枠ツアータイトル
                    'M08_Optional_Name' => isset($dataRow['I']) ? trim($dataRow['I']) : '' , // ツアー名
                    'M08_Optional_Tour_Code' => isset($dataRow['K']) ? trim($dataRow['K']) : '' , // コード
                    'M08_Optional_Category' => isset($dataRow['L']) ? trim($dataRow['L']) : '' , // カテゴリ１

                    'M08_Optional_Cost_Adult' =>  $M08_Optional_Cost_Adult , // 大人料金1
                    'M08_Optional_Cost_Adult_haya' => $M08_Optional_Cost_Adult_haya , // 早期割引
                    'M08_Adult_Limit_Min' => isset($dataRow['O']) ? trim($dataRow['O']) : '0' , // 大人年齢下限1
                    'M08_Adult_Limit_Max' => isset($dataRow['P']) ? trim($dataRow['P']) : '0' , //大人年齢上限1
                    
                    'M08_Optional_Cost_Child1' => $M08_Optional_Cost_Child1 , // 子供料金1
                    'M08_Optional_Cost_Child1_haya' => $M08_Optional_Cost_Child1_haya , // 早期割引
                    'M08_Child1_Limit_Min' => isset($dataRow['S']) ? trim($dataRow['S']) : '0' , // 子供年齢下限1
                    'M08_Child1_Limit_Max' => isset($dataRow['T']) ? trim($dataRow['T']) : '0' , // 子供年齢上限1

                    'M08_Optional_Cost_Child2' => $M08_Optional_Cost_Child2 , // 子供料金2
                    'M08_Optional_Cost_Child2_haya' => $M08_Optional_Cost_Child2_haya , // 早期割引
                    'M08_Child2_Limit_Min' => isset($dataRow['W']) ? trim($dataRow['W']) : '0' , // 子供年齢下限2
                    'M08_Child2_Limit_Max' => isset($dataRow['X']) ? trim($dataRow['X']) : '0' , // 子供年齢上限2

                    'M08_Optional_Cost_Infant' => $M08_Optional_Cost_Infant , // 子供料金3
                    'M08_Optional_Cost_Infant_haya' => $M08_Optional_Cost_Infant_haya , // 早期割引
                    'M08_Infant_Limit_Min' => isset($dataRow['AA']) ? trim($dataRow['AA']) : '0' , // 子供年齢下限3
                    'M08_Infant_Limit_Max' => isset($dataRow['AB']) ? trim($dataRow['AB']) : '0' , // 子供年齢上限3
                    
                    'M08_Optional_Min_Start' => isset($dataRow['AC']) ? trim($dataRow['AC']) : '0' , // 最少催行人数
                    'M08_Optional_Note' => isset($dataRow['AD']) ? trim($dataRow['AD']) : '' , // 備考(含まれるもの)
                    'M08_Optional_Note2' => isset($dataRow['AE']) ? trim($dataRow['AE']) : '' , // 備考2
                );
                
                $optionals[] = array_merge($otional , $kibouOpt);
            }
            return $optionals;
        } else {
            return null;
        }
    }
}
