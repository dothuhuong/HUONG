<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
set_include_path ( get_include_path () . PATH_SEPARATOR . './Classes/' );
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * ＫＮＴのお客さんからエクセルファイルノデーターをﾃﾞｰﾀｰﾍﾞｰｽにインポートする為、ライブラリー作成する
 * 新しいデーター対応
 * エクセルファイルからルーム情報を読込んでデーターベースに保存する
 * 
 * @author catnhp
 */
class ExcelRooming extends PHPExcel {
	public function __construct() {
		parent::__construct ();
	}
	public function readExcelData($readFile) {
		date_default_timezone_set ( 'Asia/Tokyo' );
		
		// Read spreadsheeet workbook
		$inputFileType = PHPExcel_IOFactory::identify ( $readFile );
		$objReader = PHPExcel_IOFactory::createReader ( $inputFileType );
		$objPHPExcel = $objReader->load ( $readFile );
		
		// Get worksheet dimensions
		$objPHPExcel->getSheet( 0 );
		
		// Excelからデータを取得する
		$dataExcel = $objPHPExcel->getActiveSheet()->toArray ( null, true, true, true );
		$roomingDataList = $this->getRoomingDataFromExcel($dataExcel );
		// R01_Travelerテーブルにデーターを保存する
		$result = $this->updateRoomingData ( $roomingDataList );
		return $result;
	}
	
	/**
	 * Excelファイルのデーターを取得する
	 * 
	 * @param array|null $dataExcel
	 *        	Excelファイルのデーター配列
	 * @return array $data
	 */
	private function getRoomingDataFromExcel($dataExcel) {
		
		if ($dataExcel != null) {
			$roomingDataList = array ();
			$updatedData = array();
			foreach ( $dataExcel as $row => $dataRow ) {
				// Excel ファイルヘーダーを外す
				if ($row < 7) continue;
				if ($row > 7 && $dataRow['C'] == null) break;
				// IDNo.を取得する
				$userIdArr = explode( '-', $dataRow['C'] );
				$userId = $userIdArr[0];
				$userSeq = $userIdArr[1] - 1;
				
				$updatedData['userId'] = $userId;
				$updatedData['userSeq'] = $userSeq;
				// 部屋割りを取得する
				$updatedData ['R01_RoomType'] = $dataRow['N'];
				// バス初日号車を取得する
				//$updatedData ['R01_Bus_Start'] = $dataRow ['O'];
				$updatedData ['R01_Bus_Start'] = $dataRow ['P'];
				// バス最終日号車を取得する
				//$updatedData ['R01_Bus_End'] = $dataRow ['P'];
				$updatedData ['R01_Bus_End'] = $dataRow ['Q'];
				// RowIndexを取得する
				$roomingDataList[] = $updatedData;
			}
			return $roomingDataList;
		} else {
			return null;
		}
	}
	
	/**
	 * R01_Travelerテーブルにルームデーターを保存する
	 * 
	 * @param array|null $roomingDataList
	 *        	エクセルデーター
	 */
	private function updateRoomingData($roomingDataList) {
		// モデルを利用する為、$CIインスタンスを使う
		$CI = & get_instance ();
		$CI->load->model ( 'operating_mo' );
		$nonExitedIdList = array();

		foreach ( $roomingDataList as $item ) {
			$param = array (
					'R01_Id' => $item ['userId'],
					'R01_Plan' => $item ['userSeq'],
					'R01_RoomType' => $item ['R01_RoomType'],
					'R01_Bus_Start' => $item ['R01_Bus_Start'],
					'R01_Bus_End' => $item ['R01_Bus_End'] 
			);
			
			//
			if ($CI->operating_mo->isExitRoomingData($item) > 0) {
				$CI->operating_mo->updateRoomingData ($item);
			} else {
				$nonExitedIdList[] = $item ['userId']."-".($item ['userSeq'] + 1);
			}
		}
		return $nonExitedIdList;
	}
}