<?php

if (! defined('BASEPATH'))
    exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';

/**
 * Excel生成クラス
 */
class Excel extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    function excel_entry_info($param, $data) {
        $CI = & get_instance();
        $CI->load->model('transport_ptn_mo');
        $CI->load->model('user_top_mo');
        $CI->load->library('convert_format');
        // $test['R00_Id'] = 100058167;
        
        $staff = $CI->user_top_mo->getStaffInfo($data['R00_Id']);
        $kakuteiInfo = $CI->user_top_mo->getKakuteCourseById($param);
        $participantInfo_arr_tmp = $CI->user_top_mo->getUserInfo($data['R00_Id']);
		//キャンセル除き
		foreach($participantInfo_arr_tmp as $participantInfo){
			if($participantInfo['R01_Cancel_flag'] == 0){
				$participantInfo_arr[] = $participantInfo;
			}
		}	
        $DeptInfo = $CI->transport_ptn_mo->getTranportlDataDept($data['R00_Id']);
        $ArrInfo = $CI->transport_ptn_mo->getTranportlDataArr($data['R00_Id']);
        
        $sum_cost = 0;
        $total_cost = 0;
        $room_cost = 0;
        /*
         * $objReader = PHPExcel_IOFactory::createReader('Excel2007');
         * $load_path = APPPATH . 'libraries/template_excel/Entry_Confirm.xlsx';
         * $load_add_path = APPPATH . 'libraries/template_excel/Entry_Confirm.xlsx';
         * $objPHPExcel = $objReader->load( $load_path );
         */
        $objPHPExcel = PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Entry_Confirm.xlsx");
        // $objPHPExcel1 = PHPExcel_IOFactory::load(APPPATH."libraries/template_excel/Entry_Confirm.xlsx");
        $row = 12;
        $lineno = 0;
        $lineno1 = 0;
        $lineno2 = 0;
        $row_dept = 23;
        $row_arr = 38;
        $i = 0;
        
        for($p_index = 0; $p_index < count($participantInfo_arr); $p_index ++) {
            
            $participantInfo_p = $participantInfo_arr[$p_index];
            $row_set = $row + $lineno;
            $dep_set = $row_dept + (3 * $p_index);
            
            $arr_set = $row_arr + (3 * $p_index);
            
            $sheet = $objPHPExcel->getActiveSheet()->setTitle('お申込み内容確認書');
            if ($p_index == 4) {
                $i = 59;
                $sum_cost = 0;
                $row = 12;
                $lineno = 0;
                $lineno1 = 0;
                $lineno2 = 0;
                $row_set = $row + $lineno;
                $row_dept = 23;
                $dep_set = $row_dept + $lineno1;
                $row_arr = 38;
                $arr_set = $row_arr + $lineno2;
            }
            
            // hidden rows59 -> rows 68
            /*
             * for($i = 60; $i <= 118; $i++) {
             * $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(FALSE);
             * }
             * $objPHPExcel->getActiveSheet()->getRowDimension(17)->setVisible(FALSE);
             * /*** 代表者情報**
             */
            
            // 代表者名
            $objPHPExcel->getActiveSheet()->setCellValue('C' . ($i + 6), $staff['R00_Sei'] . ' ' . $staff['R00_Name']);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 6))->getFont()->setSize(9);
            // /社員番号
            $objPHPExcel->getActiveSheet()->setCellValue('I' . ($i + 6), $staff['R00_Id']);
            $objPHPExcel->getActiveSheet()->getStyle('I' . ($i + 6))->getFont()->setSize(9);
            // $objPHPExcel->getActiveSheet()->getStyle('I6')->getFont()->setBold(true);
            // $objPHPExcel->getActiveSheet()->getStyle('I6')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            // 部門名
            $objPHPExcel->getActiveSheet()->setCellValue('C' . ($i + 7), $staff['R00_Division']);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 7))->getFont()->setSize(9);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 7))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            // コース
            $objPHPExcel->getActiveSheet()->setCellValue('C' . ($i + 8), $kakuteiInfo['M01_Course_Name']);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 8))->getFont()->setSize(9);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 8))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            // 旅行期間
            $travel_day = $CI->convert_format->ChangeJpDay($kakuteiInfo['M01_Dep_Date']) . '～' . $CI->convert_format->ChangeJpDay($kakuteiInfo['M01_Arr_Date']);
            $objPHPExcel->getActiveSheet()->setCellValue('I' . ($i + 8), $travel_day);
            $objPHPExcel->getActiveSheet()->getStyle('I' . ($i + 8))->getFont()->setSize(9);
            $objPHPExcel->getActiveSheet()->getStyle('I' . ($i + 8))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            // 備考
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . ($i + 54), $staff['R00_allergy_Note']);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 54))->getFont()->setSize(9);
            $objPHPExcel->getActiveSheet()->getStyle('C' . ($i + 54))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            
            /*
             * $objPHPExcel->createSheet();
             * $objPHPExcel->setActiveSheetIndex(1);
             */
            
            /**
             * *●参加者情報・ご旅行代金 **
             */
            
            // 氏　名
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . ($i + $row_set), $participantInfo_p['R01_Sei'] . ' ' . $participantInfo_p['R01_Name']);
            // パスポートネーム
			if($kakuteiInfo['M01_Dest_Kbn'] ==1){
				$objPHPExcel->getActiveSheet()->SetCellValue('E' . ($i + $row_set), $participantInfo_p['R01_Passport_Sei'] . ' ' . $participantInfo_p['R01_Passport_Name']);
				$objPHPExcel->getActiveSheet()->getStyle('E' . ($i + $row_set))->getFont()->setSize(9);
			} elseif($kakuteiInfo['M01_Dest_Kbn'] ==2){
				$objPHPExcel->getActiveSheet()->SetCellValue('E' . ($i + $row_set), $participantInfo_p['R01_Sei_Eng'] . ' ' . $participantInfo_p['R01_Name_Eng']);
				$objPHPExcel->getActiveSheet()->getStyle('E' . ($i + $row_set))->getFont()->setSize(9);
			}
           
            // 性別
            if ($participantInfo_p['R01_Sex'] == 1) {
                $gender = "男";
            } elseif ($participantInfo_p['R01_Sex'] == 2) {
                $gender = "女";
            } else {
                $gender = "";
            }
            $objPHPExcel->getActiveSheet()->SetCellValue('H' . ($i + $row_set), $gender);
            // 年齢
            $old = floor((date('Ymd', strtotime($kakuteiInfo['M01_Dep_Date'])) - date('Ymd', strtotime($participantInfo_p['R01_Birthday']))) / 10000);
            $objPHPExcel->getActiveSheet()->SetCellValue('I' . ($i + $row_set), $old);
            // 旅行起点
            $objPHPExcel->getActiveSheet()->SetCellValue('J' . ($i + $row_set), $participantInfo_p['R01_Kiten']);
            // 追加旅行代金
            setlocale(LC_MONETARY, 'ja_JP.utf8');
            $sum_cost = 0;
            for($k = 2; $k <= 3; $k ++) {
                $R01_Cost = 'R01_Cost' . $k;
                if (! empty($participantInfo_p[$R01_Cost])) {
                    $sum_cost += $participantInfo_p[$R01_Cost];
                }
            }
            $total_cost += $sum_cost;
            $room_cost += $participantInfo_p['R01_Cost4'];
            $objPHPExcel->getActiveSheet()->SetCellValue('L' . ($i + $row_set), money_format("%n", $sum_cost));
            $objPHPExcel->getActiveSheet()->getStyle('L' . ($i + $row_set))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
            
            $lineno += 1;
            /**
             * ******●国内交通・推奨便**********
             */
            // 往路]
            if ($DeptInfo != null || $DeptInfo != '') {
                $deptInfo = $DeptInfo[$p_index];
                $row_dept = 23;
                $dep_set = $row_dept + $lineno1;
                // 該当者
                $objPHPExcel->getActiveSheet()->SetCellValue('A' . ($i + $dep_set), $deptInfo['R01_Sei'] . ' ' . $deptInfo['R01_Name']);
                $result1 = $CI->transport_ptn_mo->getTranportlDataDeptByUserId($deptInfo);
                foreach ( $result1 as $result1_no => $deptResult ) {
                    $dep_con_set = $dep_set + $result1_no;
                    // 日付
                    $objPHPExcel->getActiveSheet()->SetCellValue('C' . ($i + $dep_con_set), $CI->convert_format->ChangeJpDay_NoYear($deptResult['R07_Transport_Date']));
                    // 便名
                    $objPHPExcel->getActiveSheet()->SetCellValue('E' . ($i + $dep_con_set), $deptResult['R07_Transport_Name']);
                    
                    // 出発地
                    $objPHPExcel->getActiveSheet()->SetCellValue('G' . ($i + $dep_con_set), $deptResult['R07_Transport_Place']);
                    // 時刻(出発時刻)
                    $objPHPExcel->getActiveSheet()->SetCellValue('I' . ($i + $dep_con_set), $deptResult['R07_Transport_Dep_Time']);
                    // 到着地
                    $objPHPExcel->getActiveSheet()->SetCellValue('J' . ($i + $dep_con_set), $deptResult['R07_Transport_Arr_Place']);
                    // 到着時刻
                    $objPHPExcel->getActiveSheet()->SetCellValue('L' . ($i + $dep_con_set), $deptResult['R07_Transport_Arr_Time']);
                    // 備考
                    $objPHPExcel->getActiveSheet()->SetCellValue('M' . ($i + $dep_con_set), $deptResult['R07_Note']);
                }
                $lineno1 += 3;
            }
            // 復路
            
            if ($ArrInfo != null || $ArrInfo != '') {
                $arrInfo = $ArrInfo[$p_index];
                $row_arr = 38;
                $arr_set = $row_arr + $lineno2;
                // 該当者
                $objPHPExcel->getActiveSheet()->SetCellValue('A' . ($i + $arr_set), $arrInfo['R01_Sei'] . ' ' . $arrInfo['R01_Name']);
                $result2 = $CI->transport_ptn_mo->getTranportlDataArrByUserId($arrInfo);
                foreach ( $result2 as $result2_no => $arrResult ) {
                    $arr_con_set = $arr_set + $result2_no;
                    // 日付
                    $objPHPExcel->getActiveSheet()->SetCellValue('C' . ($i + $arr_con_set), $CI->convert_format->ChangeJpDay_NoYear($arrResult['R07_Transport_Date']));
                    // 便名
                    $objPHPExcel->getActiveSheet()->SetCellValue('E' . ($i + $arr_con_set), $arrResult['R07_Transport_Name']);
                    
                    // 出発地
                    $objPHPExcel->getActiveSheet()->SetCellValue('G' . ($i + $arr_con_set), $arrResult['R07_Transport_Place']);
                    // 時刻(出発時刻)
                    $objPHPExcel->getActiveSheet()->SetCellValue('I' . ($i + $arr_con_set), $arrResult['R07_Transport_Dep_Time']);
                    // 到着地
                    $objPHPExcel->getActiveSheet()->SetCellValue('J' . ($i + $arr_con_set), $arrResult['R07_Transport_Arr_Place']);
                    // 到着時刻
                    $objPHPExcel->getActiveSheet()->SetCellValue('L' . ($i + $arr_con_set), $arrResult['R07_Transport_Arr_Time']);
                    // 備考
                    $objPHPExcel->getActiveSheet()->SetCellValue('M' . ($i + $arr_con_set), $arrResult['R07_Note']);
                }
                $lineno2 += 3;
            }
        }
        
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . ($i + 16), money_format("%n", $total_cost));
        $objPHPExcel->getActiveSheet()->getStyle('L' . ($i + 16))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
        // 一人部屋希望
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . ($i + 51), $staff['R00_1Room_wish']);
        $objPHPExcel->getActiveSheet()->getStyle('E' . ($i + 51))->getFont()->setSize(9);
        $objPHPExcel->getActiveSheet()->getStyle('E' . ($i + 51))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        // 一人部屋希望
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . ($i + 51), money_format("%n", $room_cost));
        $objPHPExcel->getActiveSheet()->getStyle('L' . ($i + 51))->getFont()->setSize(9);
        $objPHPExcel->getActiveSheet()->getStyle('L' . ($i + 51))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
        
        if (count($participantInfo_arr) <= 4)
            for($n = 60; $n <= 118; $n ++) {
                $objPHPExcel->getActiveSheet()->getRowDimension($n)->setVisible(FALSE);
            }
        
        $filename = 'Entry_' . $staff['R00_Id'] . '_' . date("Ymdhis") . '.xlsx';
        // header('Content-Type: application/vnd.ms-excel');
        // header('Content-Disposition: attachment;filename="' . $filename . '"');
        // header('Cache-Control: max-age=0');
        // $objPHPExcel = PHPExcel_IOFactory::load("./forms/english/cash.xlsx");
        // $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
        // $count = $objPHPExcel->getSheetCount();
        
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        // ob_clean();
        // $objWriter->save($filename);
        $objWriter->save(APPPATH . 'excel_data/' . $filename);
        // $objWriter->save('/var/www/nssproduct/html10/excel_data/'.$filename);
        return $filename;
    }
}