<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 * ESTAエクセルファイル作成クラス
 * @author VienCQ
 */
class ExcelESTA extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }

    public function excel_esta_info($estaData , $plan) {
        // 初期化
        $CI = & get_instance();
        $CI->load->model('menu_mo');
        $CI->load->library('convert_format');
        // エックセルテンプレートオブジェクト作成
        $tempObjPHPExcel =  PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/ESTA_info.xlsx");

        //+++++++++++++++++++++++++++++++ Sheet 1 +++++++++++++++++++++++++++++++++++++
        // 0番目のシートをアクティブにします(シートは0から数えます)
        // (エクセルを新規作成した時点で0番目の空のシートが作成されています)
        $tempObjPHPExcel->setActiveSheetIndex(0);
        // アクティブにしたシートの情報を取得(現在のシートを指定します)
        $objSheet1 = $tempObjPHPExcel->getActiveSheet();
        // シートに名前を付けます
        $objSheet1->setTitle("ESTA取得の為の質問書（2016年11月29日改訂）");
        // セルに値をセットする
        $this->createContentSheet1($estaData, $objSheet1);

        //++++++++++++++++++++++++++++++++ Sheet2 +++++++++++++++++++++++++++++++++++++
        // (エクセルを新規作成した時点で0番目の空のシートが作成されています)
        $tempObjPHPExcel->setActiveSheetIndex(1);
        // アクティブにしたシートの情報を取得(現在のシートを指定します)
        $objSheet2 = $tempObjPHPExcel->getActiveSheet();
        // シートに名前を付けます
        $objSheet2->setTitle("追加質問書（2016年6月20日改訂）");
        // セルに値をセットする
        $this->createContentSheet2($estaData, $objSheet2);

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if ($plan == 0) {
            $personType = 1;
        } else {
            $personType = $plan + 1;
        }
        $personTypeName = mb_convert_encoding($personType, 'sjis-win', 'UTF-8');
        $filename = 'ESTA_' . $estaData['R01_Id'] . '_' . $personTypeName . '_' . date("Ymdhis") . '.xlsx';
        $objWriter = PHPExcel_IOFactory::createWriter($tempObjPHPExcel, 'Excel2007');
        // ob_clean();
        // $objWriter->save($filename);
        $objWriter->save(APPPATH . 'excel_data/' . $filename);
        // $objWriter->save('/var/www/nssproduct/html10/excel_data/'.$filename);
        return $filename;
    }

    private function createContentSheet1($estaData ,PHPExcel_Worksheet $objSheet) {
        if (isset($estaData['R06_Anq'])) {
            if ($estaData['R06_Anq'] == 1) {
                $objSheet->setCellValue('I13', '■');
            } elseif ($estaData['R06_Anq'] == 0) {
                $objSheet->setCellValue('L13', '■');
            }
        }

        if (isset($estaData['R06_Anq_A'])) {
            if ($estaData['R06_Anq_A'] == 1) {
                $objSheet->setCellValue('I17', '■');
            } elseif ($estaData['R06_Anq_A'] == 0) {
                $objSheet->setCellValue('L17', '■');
            }
        }

        if (isset($estaData['R06_Anq_B'])) {
            if ($estaData['R06_Anq_B'] == 1) {
                $objSheet->setCellValue('I19', '■');
            } elseif ($estaData['R06_Anq_B'] == 0) {
                $objSheet->setCellValue('L19', '■');
            }
        }

        if (isset($estaData['R06_Anq_C'])) {
            if ($estaData['R06_Anq_C'] == 1) {
                $objSheet->setCellValue('I20', '■');
            } elseif ($estaData['R06_Anq_C'] == 0) {
                $objSheet->setCellValue('L20', '■');
            }
        }

        if (isset($estaData['R06_Anq_D'])) {
            if ($estaData['R06_Anq_D'] == 1) {
                $objSheet->setCellValue('I21', '■');
            } elseif ($estaData['R06_Anq_D'] == 0) {
                $objSheet->setCellValue('L21', '■');
            }
        }

        if (isset($estaData['R06_Anq_E'])) {
            if ($estaData['R06_Anq_E'] == 1) {
                $objSheet->setCellValue('I22', '■');
            } elseif ($estaData['R06_Anq_E'] == 0) {
                $objSheet->setCellValue('L22', '■');
            }
        }

        if (isset($estaData['R06_Anq_F'])) {
            if ($estaData['R06_Anq_F'] == 1) {
                $objSheet->setCellValue('I23', '■');
            } elseif ($estaData['R06_Anq_F'] == 0) {
                $objSheet->setCellValue('L23', '■');
            }
        }

        if (isset($estaData['R06_Anq_G'])) {
            if ($estaData['R06_Anq_G'] == 1) {
                $objSheet->setCellValue('I24', '■');
                // 「はい」の場合　　いつ？ 　　　　　　　年　　　　　　月頃　どこで？　
                $r06_anq_g_str  = "「はい」の場合　　いつ？ ";
                $r06_anq_g_str .= (isset($estaData['R06_Anq_G_Year']) ? $estaData['R06_Anq_G_Year'] : '　　　　　　　') . '年';
                $r06_anq_g_str .= (isset($estaData['R06_Anq_G_Month']) ? $estaData['R06_Anq_G_Month'] : '　　　　　　') . '月頃　どこで？';
                $r06_anq_g_str .= (isset($estaData['R06_Anq_G_Area']) ? $estaData['R06_Anq_G_Area'] : '　');
                $objSheet->setCellValue('C25', $r06_anq_g_str);
            } elseif ($estaData['R06_Anq_G'] == 0) {
                $objSheet->setCellValue('L24', '■');
            }
        }

        if (isset($estaData['R06_Anq_H'])) {
            if ($estaData['R06_Anq_H'] == 1) {
                $objSheet->setCellValue('I26', '■');
            } elseif ($estaData['R06_Anq_H'] == 0) {
                $objSheet->setCellValue('L26', '■');
            }
        }
        // 本人
        $objSheet->mergeCells('D35:E35');
        $objSheet->setCellValue('D35', $this->getFullFurigana($estaData));
        $objSheet->getStyle('D35')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $objSheet->setCellValue('D36', $this->getFullNameKanji($estaData));
        $objSheet->getStyle('D36')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        $objSheet->getStyle('D36')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objSheet->getStyle('D36')->getFont()->setSize(14);
        // 日付
        /*
        $objSheet->setCellValue('F36', $this->getCurrentDate());
        $objSheet->getStyle('F36')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        $objSheet->getStyle('F36')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objSheet->getStyle('F36')->getFont()->setSize(12);
        */
    }

    private function createContentSheet2($estaData ,PHPExcel_Worksheet $objSheet) {
		$CI = & get_instance();
    	$CI->load->model('menu_mo');
    	$CI->load->library('convert_format');
        // 氏名
        $objSheet->setCellValue('H3', $this->getFullNameKanji($estaData));

        // 確認欄
        if (isset($estaData['R06_Travel_History'])) {
            if ($estaData['R06_Travel_History'] == 0) { // なし
                $objSheet->setCellValue('N10', '■');
            } elseif ($estaData['R06_Travel_History'] == 1) { // あり
                $objSheet->setCellValue('P10', '■');
            }
        }
        // Q1
        if (isset($estaData['R06_Travel_History_Flg_1'])) {
            if ($estaData['R06_Travel_History_Flg_1'] == 1) {
                $objSheet->setCellValue('B15', '■');
                if (isset($estaData['R06_Betsumei_Sei'])) {
                    $objSheet->setCellValue('E18', $estaData['R06_Betsumei_Sei']);
                }
                if (isset($estaData['R06_Betsumei_Mei'])) {
                    $objSheet->setCellValue('N18', $estaData['R06_Betsumei_Mei']);
                }
            } else {
                $objSheet->setCellValue('E15', '■');
            }
        }
        // Q2
        $birthAddressFurigana = '';
        $birthAddressFurigana .= (isset($estaData['R06_City_Kana'])?$estaData['R06_City_Kana']:'');
        $objSheet->setCellValue('D23', $birthAddressFurigana);
        $birthAddress  = '';
        $birthAddress .= (isset($estaData['R06_City_Birth1'])?$estaData['R06_City_Birth1']:'');
        $birthAddress .= (isset($estaData['R06_City_Birth2'])?$estaData['R06_City_Birth2']:'');
        $birthAddress .= (isset($estaData['R06_City_Birth3'])?$estaData['R06_City_Birth3']:'');
        $objSheet->setCellValue('D24', $birthAddress);
        // Q3
        $father_sei = (isset($estaData['R06_Father_Sei']) ? $estaData['R06_Father_Sei'] : '不明');
        $objSheet->setCellValue('F30', $father_sei);
        $father_mei = (isset($estaData['R06_Father_Mei']) ? $estaData['R06_Father_Mei'] : '不明');
        $objSheet->setCellValue('N30', $father_mei);
        $mother_sei = (isset($estaData['R06_Mother_Sei']) ? $estaData['R06_Mother_Sei'] : '不明');
        $objSheet->setCellValue('F32', $mother_sei);
        $mother_mei = (isset($estaData['R06_Mother_Mei']) ? $estaData['R06_Mother_Mei'] : '不明');
        $objSheet->setCellValue('N32', $mother_mei);
        // Q4
        if (isset($estaData['R06_Travel_History_Flg_4'])) {
            if ($estaData['R06_Travel_History_Flg_4'] == 1) {//はいR06_Travel_History_Flg_4
                $objSheet->setCellValue('B37', '■');
                if (isset($estaData['R06_CitizenElse_Country'])) {
                    $objSheet->setCellValue('E39', $estaData['R06_CitizenElse_Country']);
                }
                if (isset($estaData['R06_CitizenElse_Type'])) {
                    if ($estaData['R06_CitizenElse_Type'] == 1) {
                        $objSheet->setCellValue('N39', '■');
                    } elseif ($estaData['R06_CitizenElse_Type'] == 2) {
                        $objSheet->setCellValue('P39', '■');
                        if (isset($estaData['R06_CitizenElse_Other'])) {
                            $objSheet->setCellValue('R39', $estaData['R06_CitizenElse_Other']);
                        }
                    }
                }
                if (isset($estaData['R06_CitizenElse_No'])) {
                    $objSheet->setCellValue('E41', $estaData['R06_CitizenElse_No']);
                }
               	if (isset($estaData['R06_CitizenElse_Expire'])) {                    
                    $objSheet->setCellValue('N41', $CI->convert_format->ChangeJpDay_NoDayOfWeek($estaData['R06_CitizenElse_Expire'] ));
                }
            } elseif ($estaData['R06_Travel_History_Flg_4'] == 0) {//いいえ
                $objSheet->setCellValue('E37', '■');
            }
        }
        // Q5
        if (isset($estaData['R06_Travel_History_Flg_5'])) {
            if ($estaData['R06_Travel_History_Flg_5'] == 1) {
                $objSheet->setCellValue('B46', '■');
                if (isset($estaData['R06_Dual_Nationality_Country'])) {
                    $objSheet->setCellValue('E49', $estaData['R06_Dual_Nationality_Country']);
                }
                if (isset($estaData['R06_Dual_Nationality_Acquisition'])) {
                    if ($estaData['R06_Dual_Nationality_Acquisition'] == 1) {
                        $objSheet->setCellValue('N49', '■'); // 出生による
                    } elseif ($estaData['R06_Dual_Nationality_Acquisition'] == 4) {
                        $objSheet->setCellValue('P49', '■'); // その他
                        // その他場合は「」入力する
                    }
                }
            } elseif ($estaData['R06_Travel_History_Flg_5'] == 0) {
                $objSheet->setCellValue('E46', '■');
            }
        }
        // Q6
        if (isset($estaData['R06_Travel_History_Flg_6'])) {
            if ($estaData['R06_Travel_History_Flg_5'] == 1) {
                $objSheet->setCellValue('B54', '■');
                if (isset($estaData['R06_Anq6_Country_Name'])) {
                    $objSheet->setCellValue('P54', $estaData['R06_Anq6_Country_Name']);
                }
            } elseif ($estaData['R06_Travel_History_Flg_5'] == 0) {
                $objSheet->setCellValue('E54', '■');
            }
        }
        // Q7
        if (isset($estaData['R06_Travel_History_Flg_7'])) {//R06_Travel_History_Flg_7
            if ($estaData['R06_Travel_History_Flg_7'] == 1) {//はい
                $objSheet->setCellValue('B60', '■');
                if (isset($estaData['R06_CBP_Number'])) {
                    $objSheet->setCellValue('P60', $estaData['R06_CBP_Number']);
                }
            } elseif ($estaData['R06_Travel_History_Flg_7'] == 0) {
                $objSheet->setCellValue('E60', '■');
            }
        }
        // Q8
        if (isset($estaData['R06_Emmergency_Sei'])) {
            $objSheet->setCellValue('D65', $estaData['R06_Emmergency_Sei']);
        }
        if (isset($estaData['R06_Emmergency_Mei'])) {
            $objSheet->setCellValue('K65', $estaData['R06_Emmergency_Mei']);
        }
        if (isset($estaData['R06_Emmergency_Tel'])) {
            $objSheet->setCellValue('P65', $estaData['R06_Emmergency_Tel']);
        }
        // Q10
        if (isset($estaData['R06_Working_Type'])) {
            if ($estaData['R06_Working_Type'] == 5) {
                $objSheet->setCellValue('E71', '■');
            } elseif ($estaData['R06_Working_Type'] == 4) {
                $objSheet->setCellValue('K71', '■');
            } elseif ($estaData['R06_Working_Type'] == 6) {
                $objSheet->setCellValue('N71', '■');
            } elseif ($estaData['R06_Working_Type'] == 3) {
                $objSheet->setCellValue('E72', '■');
            } elseif ($estaData['R06_Working_Type'] == 2) {
                $objSheet->setCellValue('G72', '■');
            } elseif ($estaData['R06_Working_Type'] == 1) {
                $objSheet->setCellValue('I72', '■');
            } elseif ($estaData['R06_Working_Type'] == 0) {
                $objSheet->setCellValue('K72', '■');
                if (isset($estaData['R06_Working_Other_Type'])) {
                    $objSheet->setCellValue('M72', $estaData['R06_Working_Other_Type']);
                }
            }
        }
        if (isset($estaData['R06_Working_Name'])) {
            $objSheet->setCellValue('E79', $estaData['R06_Working_Name']);
        }
        if (isset($estaData['R06_Working_Place_Kana'])) {
            $objSheet->setCellValue('G81', $estaData['R06_Working_Place_Kana']);
        }
        if (isset($estaData['R06_Working_Post1']) && isset($estaData['R06_Working_Post2'])) {
            $working_post = $estaData['R06_Working_Post1'] . ' － ' . $estaData['R06_Working_Post2'];
            $objSheet->setCellValue('G82', $working_post);
        }
        $working_address  = '';
        $working_address .= (isset($estaData['R06_Working_Pref']) ? $estaData['R06_Working_Pref'] : '');
        $working_address .= (isset($estaData['R06_Working_Addr1']) ? $estaData['R06_Working_Addr1'] : '');
        $working_address .= (isset($estaData['R06_Working_Addr2']) ? $estaData['R06_Working_Addr2'] : '');
        $objSheet->setCellValue('G83', $working_address);
    }

    private function getFullFurigana($estaData) {
        $fullName = '';
        if (isset($estaData['R00_Sei_Kana']) && isset($estaData['R00_Name_Kana'])) {
            $fullName .= $estaData['R00_Sei_Kana'];
            $fullName .= $estaData['R00_Name_Kana'];
        } else {
            if (isset($estaData['R01_Sei_Kana']) && isset($estaData['R01_Name_Kana'])) {
                $fullName .= $estaData['R01_Sei_Kana'];
                $fullName .= $estaData['R01_Name_Kana'];
            }
        }
        $fullNameConvert = $str = mb_convert_kana($fullName ,"cH","UTF-8");
        return $fullNameConvert;
    }

    private function getFullNameKanji($estaData) {
        $fullName = '';
        if (isset($estaData['R00_Sei']) && isset($estaData['R00_Name'])) {
            $fullName .= $estaData['R00_Sei'];
            $fullName .= $estaData['R00_Name'];
        } else {
            if (isset($estaData['R01_Sei']) && isset($estaData['R01_Name'])) {
                $fullName .= $estaData['R01_Sei'];
                $fullName .= $estaData['R01_Name'];
            }
        }
        return $fullName;
    }

    private function getCurrentDate() {
        $today = date('Y年m月d日');
        return $today;
    }

}