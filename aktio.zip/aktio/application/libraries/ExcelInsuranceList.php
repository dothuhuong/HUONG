<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 */
class ExcelInsuranceList extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    /*
     *
     * air line name list
     */
    public function InsuranceList($param) {
        date_default_timezone_set("Asia/Tokyo");
        $objPHPExcel = PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/InsuranceList.xlsx");
        $objPHPExcel->setActiveSheetIndex(0);
        $objSheet = $objPHPExcel->getActiveSheet();
        $objSheet->setTitle("InsuranceList");
        $this->createContentSheet($param, $objSheet);
        $filename = 'insurance_list.xlsx';
        header("Content-Type: application/octet-stream"); // ダウンロードの指示
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0'); // no cache
        ob_end_clean(); // ファイル破損エラー防止
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
    private function createContentSheet($param, PHPExcel_Worksheet $objSheet) {
        $CI = & get_instance();
        $CI->load->library('convert_format');
        $Course = $param['CourseDataMaster'];
        $Travelers = $param['SearchResult'];		
        // コース名
        $objSheet->setCellValue('B2', $Course['M01_Course_Name']);
        $objSheet->getStyle('B2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        //
        $M01_Dep_Date = $CI->convert_format->ChangeJpDay($Course['M01_Dep_Date']);
        $M01_Arr_Date = $CI->convert_format->ChangeJpDay($Course['M01_Arr_Date']);
        $objSheet->setCellValue('B3', $M01_Dep_Date . '～' . $M01_Arr_Date);
		//往路,復路
		if(count($param['Flight_Ptn'])>0){
			$dep_flight = '往路フライト：'.' '.$param['Flight_Ptn']['M011_Go_Air'];
			$arr_flight = '往路フライト：'.' '.$param['Flight_Ptn']['M011_Rtn_Air'];
			$objSheet->setCellValue('B4', $dep_flight.'　　'.$arr_flight);			
		}
        $i = 7;
		$j = 1;
        foreach ( $Travelers as $Traveler ) {
			
            $distination = substr($param['Tour_Name']['M00_Tour_Name'], 0, -9);
			$objSheet->setCellValue('B' . $i, $j);
            $objSheet->setCellValue('C' . $i, $distination);
			$objSheet->setCellValue('D' . $i, $this->getMonthDayFormat($Course['M01_Dep_Date']));
			$objSheet->setCellValue('E' . $i, $this->getMonthDayFormat($Course['M01_Arr_Date']));
			
			$user_id = $Traveler['R01_Id'] . '-' . ($Traveler['R01_Plan'] + 1);
            $objSheet->setCellValue('F' . $i, $user_id);
			if ($Traveler['R01_Plan'] == 0) {							
				$objSheet->setCellValue('G' . $i, $Traveler['R00_Company']);
				$objSheet->setCellValue('H' . $i, $Traveler['R00_Division']);
			}else{				
				$objSheet->setCellValue('G' . $i, "");
				$objSheet->setCellValue('H' . $i, "");
			} 
			$objSheet->setCellValue('I' . $i, $Traveler['R01_Sei']);
            $objSheet->getStyle('I' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			
            $objSheet->setCellValue('J' . $i, $Traveler['R01_Name']);
            $objSheet->getStyle('J' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);			
						
			if($Traveler['R00_Dest_Kbn']==1){			
				$objSheet->setCellValue('K' . $i, $Traveler['R01_Passport_Sei']);
				$objSheet->getStyle('K' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);				
				$objSheet->setCellValue('L' . $i, $Traveler['R01_Passport_Name']);
				$objSheet->getStyle('L' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			}else{
				$objSheet->setCellValue('K' . $i, $Traveler['R01_Sei_Eng']);
				$objSheet->getStyle('K' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);				
				$objSheet->setCellValue('L' . $i, $Traveler['R01_Name_Eng']);
				$objSheet->getStyle('L' . $i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			}
           
			if ($Traveler['R01_Sex'] == "1") {
                $Sex = "男";
            } else {
                $Sex = "女";
            }
			$objSheet->setCellValue('M' . $i, $Sex);
			// 日付フォマット変化
            $R01_Birthday = str_replace("-", "/", $Traveler['R01_Birthday']);
            $objSheet->setCellValue('N' . $i, $R01_Birthday);           
            $i ++;
			$j ++;
        }
    }
	public function getMonthDayFormat($param){
		date_default_timezone_set('Asia/Tokyo');              
        // 日付を指定        
        $month = date('m', strtotime($param));
        $day = date('d', strtotime($param));               
        if (($param != NULL || $param != '') && ($param != '0000-00-00')) {
            // 指定日の日本語曜日を出力
            return $month . '月' . $day . '日';
        } else {
            return NULL;
        }
	}
}