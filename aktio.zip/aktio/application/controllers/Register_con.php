<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Register_con extends CI_Controller {
    public function Register_con() {
        parent::__construct ();
		// ヘプル
        $this->load->helper('url');
        // ライプラリ
        $this->load->library('session');
        $this->load->library('validation');
		$this->load->library('convert_format');
        // モデル   
		$this->load->model('course_mo');
		$this->load->model('common_mo');
		$this->load->model('user_top_mo');
		$this->load->model('register_mo');
       
    }
	/*
	*
	*代表者新規登録
	*/
	public function index(){
		// Check session
        $admin_id = $this->session->userdata('admin_id_session');
		if (isset($admin_id)) {
			$data['title'] = "代表者新規登録"; 
			$data['M01_Courses'] = $this->course_mo->getM01_Course();
			$data['PrefectureArr'] = $this->common_mo->getPrefectureValue();
			$this->load->view("representative_register_vi", $data);
		}else{
			redirect(base_url("admin_con"));
		}
	}
	/*
	*
	*確認画面
	*/
	public function confirm(){
		$admin_id = $this->session->userdata('admin_id_session');
		if (isset($admin_id)) {
				$data['title'] = "代表者新規登録"; 
				$data['M01_Courses'] = $this->course_mo->getM01_Course();
				$data['PrefectureArr'] = $this->common_mo->getPrefectureValue();
			if(empty($_POST)){
				$this->load->view("representative_register_vi", $data);
			}else{
				$data['title'] = "代表者新規登録(確認)"; 				
				$_POST['M01_Course'] = '';
				//$CourseArr = $this->getCourseArr($_POST);
				//if($CourseArr !=''){
					//$M01_Course = $this->user_top_mo->getKakuteCourseById($CourseArr);
					//$_POST['M01_Course']= '【'.$M01_Course['M01_Dest_Kbn'].$M01_Course['M01_Dest_Code'].$M01_Course['M01_Han'].$M01_Course['M01_Dep_Id'].$M01_Course['M01_Air_Program'].'】'.$M01_Course['M01_Course_Name'];
				//}
				$data['DaihyoData'] = $_POST;				
				$this->load->view("representative_register_confirm_vi", $data);
			}
		}else{
			redirect(base_url("admin_con"));
		}
	}
	/*
	*新規登録
	*
	*/
	public function save(){
		$admin_id = $this->session->userdata('admin_id_session');
		if (isset($admin_id)) {			
			$params = $_POST;
			$DaihyoData = $this->getDaihyoData($params);
			$R00_Reserve = $this->getReserveArr($DaihyoData);
			$R01_Traveler =  $this->getTravelerData($DaihyoData);
			
			$R00_Reserve_Result = $this->register_mo->addReserve($R00_Reserve);
			$R01_Traveler_Result =  $this->register_mo->addTraveler($R01_Traveler);	
			if($R00_Reserve_Result == 1 && $R01_Traveler_Result ==1){
				$data['title'] = "代表者新規登録(完了)"; 
				$data['message'] = "登録完了しました。";
				$data['sub_message'] = "※引き続き確定コースを設定してください。";
			}else{
				$data['title'] = "代表者新規登録(エーラ)"; 
				$data['message'] = "大変申し訳ございません。登録失敗しました。";
				$data['sub_message'] = "";
			}
			$this->load->view("register_complete_vi", $data);
		}else{
			redirect(base_url("admin_con"));
		}
	}
	/*
	*
	*代表者データ作成
	*/
	public function getDaihyoData($param){
		//データ初期化
		/*$param['R00_Dest_Kbn']	  = '';
		$param['R00_Dest_Code']	  = '';
		$param['R00_Han']		  = '';
		$param['R00_Dep_Id']	  = '';
		$param['R00_Air_Program'] = '';*/
		$param['R01_Birthday']    = '';
		$param['R00_Nyusha_Date'] = '';
		$param['R00_Saiyo_Date']  = '';
		$param['R00_Sinyukai_Pay_Start'] = '';
		//コースデータ作成		
		//$param = $this->getCourseArr($param);
		//生年月日
		if($param['Birthday_Yr']!="" && $param['Birthday_M']!="" && $param['Birthday_D']!=""){
			$param['R01_Birthday'] = $param['Birthday_Yr'].'-'.$param['Birthday_M'].'-'.$param['Birthday_D'];
		}
		//入社年月日
		if($param['Nyusha_Date_Yr']!="" && $param['Nyusha_Date_M']!="" && $param['Nyusha_Date_D']!=""){
			$param['R00_Nyusha_Date'] = $param['Nyusha_Date_Yr'].'-'.$param['Nyusha_Date_M'].'-'.$param['Nyusha_Date_D'];
		}else{
			$param['R00_Nyusha_Date'] = "";
		}
		//採用発令日
		if($param['Saiyo_Date_Yr']!="" && $param['Saiyo_Date_M']!="" && $param['Saiyo_Date_D']!=""){
			$param['R00_Saiyo_Date'] = $param['Saiyo_Date_Yr'].'/'.$param['Saiyo_Date_M'].'/'.$param['Saiyo_Date_D'];
		}else{
			$param['R00_Saiyo_Date'] = "";
		}
		//新友会支払開始年月
		if($param['Sinyukai_Pay_Start_Yr']!="" && $param['Sinyukai_Pay_Start_M']!=""){
			$param['R00_Sinyukai_Pay_Start'] = $param['Sinyukai_Pay_Start_Yr'].'年'.$param['Sinyukai_Pay_Start_M'].'月';
		}else{
			$param['R00_Sinyukai_Pay_Start'] = '';
		}		
		return $param;
	}
	/*
	*
	*traveler データ作成
	*/
	public function getTravelerData($params){
		$result = array(
			'R01_Id' => $params['R00_Id'],
			'R01_Plan' => 0,
			'R01_Sei' => $params['R00_Sei'],
			'R01_Name' => $params['R00_Name'],
			'R01_Sei_Kana' => $params['R00_Sei_Kana'],
			'R01_Name_Kana' => $params['R00_Name_Kana'],
			'R01_Sei_Eng' => $params['R00_Sei_Eng'],
			'R01_Name_Eng' => $params['R00_Name_Eng'],
			'R01_Birthday' => $params['R01_Birthday'],
			'R01_Sex' => $params['R01_Sex'],
			'R01_Post1' => $params['R01_Post1'],
			'R01_Post2' => $params['R01_Post2'],
			'R01_Address_Pref' => $params['R01_Address_Pref'],
			'R01_Address1' => $params['R01_Address1'],
			'R01_Address2' => $params['R01_Address2'],
			'R01_Tel' => $params['R01_Tel'],
			'R01_Mobile' => $params['R01_Mobile'],
			'R01_Adress_Area' => $params['R01_Adress_Area'],
			'R01_Adress_Airport' => $params['R01_Adress_Airport'],
			'R01_Adress_Sta' => $params['R01_Adress_Sta'],
			'R01_Kiten' => $params['R01_Kiten'],
			'R01_Note' => $params['R01_Note']
		);
		return $result;
	}	
	/*
	*
	*入力画面へ戻る
	*/
	public function back(){
		$admin_id = $this->session->userdata('admin_id_session');
		if (isset($admin_id)) {
			$data['title'] = "代表者新規登録"; 
			$data['M01_Courses'] = $this->course_mo->getM01_Course();
			$data['PrefectureArr'] = $this->common_mo->getPrefectureValue();
			$data['DaihyoData'] = $_POST;
			$this->load->view("representative_register_vi", $data);
		}else{
			redirect(base_url("admin_con"));
		}
	}
	/*
	*
	*R00_Reserve にデータ追加するため配列を作成する
	*/
	public function getReserveArr($DaihyoData){
		foreach($DaihyoData as $key=>$val){
			if (strpos($key, 'R00') !== false) {
				$result[$key] = $val;
			}			
		}	
		return $result;
	}
	/*
	*
	*コース配列データ作成
	*/
	public function getCourseArr($params){		
		if($params['M01_Courses'] !=''){
			$CoursesArr=explode('_',$params['M01_Courses']);
			$params['R00_Dest_Kbn']=$CoursesArr[0];
			$params['R00_Dest_Code']=$CoursesArr[1];
			$params['R00_Han']=$CoursesArr[2];
			$params['R00_Dep_Id']=$CoursesArr[3];
			$params['R00_Air_Program']=$CoursesArr[4];
		}		
		return $params;
	}
	/*
	*
	*代表者確認画面
	*/
	public function check_daihyo(){
		$R00_Id = $this->input->post('R00_Id');
		$DaihyoFlg = $this->register_mo->isExistDaihyo($R00_Id);
		if($DaihyoFlg){
			echo "exist";
		}else{
			echo 'non-exist';
		}
	}
	
}
