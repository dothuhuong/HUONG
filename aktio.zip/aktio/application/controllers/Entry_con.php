<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL ^ E_WARNING);
class Entry_con extends CI_Controller {

    function Entry_con() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('user_top_mo');
        $this->load->model('entry_mo');
    }
    function index(){
        $R00_Id = $this->session->userdata('R00_Id');
        if($R00_Id == '' || $R00_Id ==NULL) {
            $this->load->view('login_vi');
            return;
        } else {
            $data['user_info'] = $this->user_top_mo->getStaffInfo($R00_Id);
            $data['course_data'] = $this->user_top_mo->getCourseData();
            $data['kibouCourse'] = $this->session->userdata('kibouCourse');
            //海外-国内データをセクションから取得
            $kibouStatus1['M01_Status'] =$this->session->userdata('kibouStatus1');
            $kibouStatus2['M01_Status'] =$this->session->userdata('kibouStatus2');
            $kibouStatus3['M01_Status'] =$this->session->userdata('kibouStatus3');
            $data['kibouStatus1'] = $kibouStatus1['M01_Status'];
            $data['kibouStatus2'] = $kibouStatus2['M01_Status'];
            $data['kibouStatus3'] = $kibouStatus3['M01_Status'];
            //var_dump($data['course_data']);
            $this->load->view('head_vi');
            $this->load->view('entry_vi',$data);
            $this->load->view('footer_vi');
            return;
        }
    }
    /*
    *
    *申し込み画面
    */
    public function register(){
        $R00_Id = $this->session->userdata('R00_Id');
        if($R00_Id == '' || $R00_Id ==NULL) {
            $this->load->view('login_vi');
            return;
        } else {
        if($_POST == NULL) {
            $kibou_course = $this->session->userdata('kibouCourse');
            //R00_kibou　IDでデータ取得
            $data['kibou_course1']= $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou1']);
            $data['kibou_course2'] = $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou2']);
            $data['kibou_course3'] = $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou3']);
            //
            $staffInfo = $this->user_top_mo->getStaffInfo($R00_Id);
            unset($staffInfo['R00_emargency_mei'],$staffInfo['R00_emargency_zoku'],$staffInfo['R00_emargency_tel'],$staffInfo['R00_Customer_Note']);
            $entryData = $this->session->userdata('entryData');
            $staffInfo = $staffInfo + array(
            'R00_emargency_mei'=> $entryData['R00_emargency_mei'],
            'R00_emargency_zoku'=> $entryData['R00_emargency_zoku'],
            'R00_emargency_tel'=> $entryData['R00_emargency_tel'],
            'R00_Customer_Note'=> $entryData['R00_Customer_Note'],
            );
            $data['staffInfo'] = $staffInfo;
        } else {
            $kibou_course = array(
            "R00_kibou1"=>$this->input->post('R00_kibou1'),
            "R00_kibou2"=>$this->input->post('R00_kibou2'),
            "R00_kibou3"=>$this->input->post('R00_kibou3'),
            );
            $kibouStatus1 =$this->input->post('course1');
            $this->session->set_userdata('kibouStatus1',$kibouStatus1);
            $kibouStatus2 =$this->input->post('course2');
            $this->session->set_userdata('kibouStatus2',$kibouStatus2);
            $kibouStatus3 =$this->input->post('course3');
            $this->session->set_userdata('kibouStatus3',$kibouStatus3);
            //希望コースをセクションに保存する
            $this->session->set_userdata('kibouCourse',$kibou_course);
            $data['kibou_course1']= $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou1']);
            $data['kibou_course2'] = $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou2']);
            $data['kibou_course3'] = $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou3']);
            $data['staffInfo'] = $this->user_top_mo->getStaffInfo($R00_Id);
        }
            $data['traveler'] = $this->user_top_mo->getUserInfo($R00_Id);
            $data['Depature'] = $this->user_top_mo->getDepature();
            $this->load->view('head_vi');
            $this->load->view('register_vi',$data);
            $this->load->view('footer_vi');
            return;
        }
    }
    /*
    *
    *確認画面処理
    */
    public function confirm(){
        $R00_Id = $this->session->userdata('R00_Id');
        if($R00_Id == '' || $R00_Id ==NULL) {
            $this->load->view('login_vi');
            return;
        } else {
            $R01_Sequence = $this->input->post('R01_Sequence');
            //POST データ
            $param = array(
            "R00_emargency_mei"=>$this->input->post('R00_emargency_mei'),
            "R00_emargency_zoku"=>$this->input->post('R00_emargency_zoku'),
            "R00_emargency_tel"=>$this->input->post('R00_emargency_tel'),
            "R00_Customer_Note"=>$this->input->post('R00_Customer_Note'),
            );
            //追加参加者１
            $extFlag1 =0;
            $extFlag1 = $this->input->post('exTravler1');
            $extraveler1 = null;
            if($extFlag1 == 1)
            {
                $extraveler1 = array(
                "R01_Id"=>$R00_Id,
                "R01_Sei"=>$this->input->post('R01_Sei-1'),
                "R01_Name"=>$this->input->post('R01_Name-1'),
                "R01_Sequence"=>'-1',
                "R01_Plan"=>$this->input->post('R01_Plan-1'),
                "R01_Birthday"=>$this->input->post('R01_Birthday-1'),
                "R01_Sex"=>$this->input->post('R01_Sex-1'),
                "R01_DepertureAirport"=>$this->input->post('R01_DepertureAirport-1'),
                "R01_Participation"=>$this->input->post('R01_Participation-1'),
                );
            }
            //追加参加者2
            $extFlag2 =0;
            $extFlag2 = $this->input->post('exTravler2');
            $extraveler2 = null;
            if($extFlag2 == 1)
            {
                $extraveler2 = array(
                "R01_Id"=>$R00_Id,
                "R01_Sei"=>$this->input->post('R01_Sei-2'),
                "R01_Name"=>$this->input->post('R01_Name-2'),
                "R01_Sequence"=>'-2',
                "R01_Plan"=>$this->input->post('R01_Plan-2'),
                "R01_Birthday"=>$this->input->post('R01_Birthday-2'),
                "R01_Sex"=>$this->input->post('R01_Sex-2'),
                "R01_DepertureAirport"=>$this->input->post('R01_DepertureAirport-2'),
                "R01_Participation"=>$this->input->post('R01_Participation-2'),
                );
            }
            //家族post データ取得
            //$R01_DepertureAirport=$this->input->post('R01_DepertureAirport');
            $R01_DepertureAirport = null;
            foreach ($R01_Sequence as $key => $value){
                $R01_DepertureAirport[$value]=$this->input->post('R01_DepertureAirport'.$value);
                //$R01_Participation[$value]=$this->input->post('R01_Participation'.$value);
            }
            //var_dump($R01_Participation);
            //国内緊急連絡先と通信欄をセクションに格納
            $this->session->set_userdata('entryData',$param);
            //本人情報取
            $data['staffInfo'] = $this->user_top_mo->getStaffInfo($R00_Id);
            //希望コースをセクションから取得
            $kibou_course = $this->session->userdata('kibouCourse');
            //R00_kibou　IDでデータ取得
            $data['kibou_course1']= $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou1']);
            $data['kibou_course2'] = $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou2']);
            $data['kibou_course3'] = $this->user_top_mo->getKibouCourseById($kibou_course['R00_kibou3']);
            //本人データ取得　from traveler table
            $data['traveler'] = $this->user_top_mo->getUserInfo($R00_Id);
            //参加者情報取得
            $participateData = $this->entry_mo->getTravelerInfoByseq($R00_Id,$R01_Sequence);
            //出発地取得
            $data['departure'] = $this->user_top_mo->getDepature($R00_Id);
            $i=0;
            foreach($participateData as $row){
                foreach($R01_DepertureAirport as $key => $value){
                    if($row['R01_Sequence']== $key){
                        $participateData[$i]['R01_DepertureAirport']= $value;
                        $i++;
                    }
                }
            }
            $data['parData'] = $participateData;
            //追加参加者データと家族参加者データをまとめる
            if($extraveler1 !=null){
                $data['parData'][]= $extraveler1;
            }
            if($extraveler2 !=null)	{
                $data['parData'][] = $extraveler2;
            }
            $data['entryData'] = $param;
            //更新データをセクションに保存します
            $UpdData = array_merge($data['parData'], $data['entryData']);
            $this->session->set_userdata('UpdData',$UpdData);
            $this->load->view('head_vi');
            $this->load->view('confirm_vi',$data);
            $this->load->view('footer_vi');
            return;
        }
    }
    /*
    *コース取得
    *
    */
    public function getCourse(){
        $course = $this->input->post('course');
        $result = $this->entry_mo->getCourseByDest($course);
        $data = array();
        foreach ($result as $row)
        {
            $data[] = $row;
        }
        echo json_encode($data);

    }
    /*
    *海外国内取得
    *
    */
    public function getTourType(){
        $course = $this->input->post('course');
        $result = $this->entry_mo->getTourByStatus($course);
        $data = array();
        foreach ($result as $row)
        {
            $data[] = $row;
        }
        echo json_encode($data);
    }

}
