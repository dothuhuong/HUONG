<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login_con extends CI_Controller {
    function Login_con() {
        parent:: __construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('login_mo');
    }

    public function index(){
        $this->load->view('login_vi');
    }


    /**
     * ログインチェックするメソッド
     */
    public function login(){
        $data = array();
        // get R00_Id and R00_Password from View
        $R00_Id = !isset($_POST['R00_Id'])?"":$_POST['R00_Id'];
        $R00_Password = !isset($_POST['R00_Password'])?"":$_POST['R00_Password'];

        // CHECK LOGIN
        if (!isset($R00_Id) || !isset($R00_Password)) { // IDとパスワード入力していない場合
            $data['messager'] = '認証に失敗しました。ログインIDとパスワードをお確かめください。';
            $this->load->view('login_vi', $data);
            return;
        } else {
            //demo20161111
            //$this->load->view('user_top_first_vi');
           // if ($this->login_mo->isIDforUser($R00_Id) == TRUE){
                // はじめてログインチェックするフラグ
                $first_flag = $this->login_mo->isFirstLogin($R00_Id);
                $user_data = $this->login_mo->isRightPassword($R00_Id, $R00_Password, $first_flag);
                if ($user_data[0]['id'] != null) {
                    if ($first_flag) {
                        //1回目ログイン
                        $this->session->set_userdata('R00_Id',$user_data[0]['id']); // セッションにユーザーIDを保存する
                        $this->load->view('user_top_first_vi');
                        return;
                    } else {
                        //2回目以降ログイン
                        $this->session->set_userdata('R00_Id',$user_data[0]['id']);
                        //2回目以降ログイン時間設定
                        date_default_timezone_set('Asia/Tokyo');
                        $R00_last_login_date = date('Y-m-d H:i:s');
                        $this->login_mo->update_second_login_time($user_data[0]['id'],$R00_last_login_date);
                        redirect(base_url("user_top_con"));
                        return;
                    }
                } else {
                    $data['messager'] = '認証に失敗しました。ログインIDとパスワードをお確かめください。';
                    $this->load->view('login_vi', $data);
                    return;
                }
            //} else {
           //         $data['messager'] = '認証に失敗しました。ログインIDとパスワードをお確かめください。';
            //        $this->load->view('login_vi', $data);
            //        return;
            //}
        }
    }

    /**
     * 初回のログインでパスワードをセットする
     */
    public function psset(){
        $now_ps = $this->input->post('now_ps');
        $new_ps1 = $this->input->post('new_ps1');
        $new_ps2 = $this->input->post('new_ps2');
        if($new_ps1 == '' || $new_ps2 == '') {
            $data['messager'] = 'パスワードまたは確認パスワードを入力してください。';
            $this->load->view('user_top_first_vi', $data);
            return;
        } elseif ($new_ps1 != $new_ps2) {
            $data['messager'] = '新パスワードと確認パスワードは異なります。';
            $this->load->view('user_top_first_vi' , $data);
            return;
        } 
		elseif ($new_ps1 == $new_ps2 && $new_ps1 == $now_ps ) {
            $data['messager'] = '新パスワードは生年月日への変更はできません。';
            $this->load->view('user_top_first_vi' , $data);
            return;
        } 
		elseif ($now_ps == '') {
            $data['messager'] = '現在のパスワードを入力してください。';
            $this->load->view('user_top_first_vi' , $data);
            return;
        }
		else {
            $R00_Id = $this->session->userdata('R00_Id'); // get R00_Id session
            $update_success = $this->login_mo->setPassword($now_ps,$new_ps1,$R00_Id); // 新しいパスワードを保存する
            if($update_success){
                redirect(base_url("user_top_con"));
                return;
            } else {
                $data['messager'] = '現在のパスワードが違います。';
                $this->load->view('user_top_first_vi' , $data);
                return;
            }
        }
    }
    /*
    *
    *user logout and delete session
    */
    public function logout(){
        //$this->session->sess_destroy();
        $this->session->unset_userdata("R00_Id");		
        $this->load->view('login_vi');
        return;
    }
    /*
    *
    *パスワード忘れ
    */
    public function forgetpass(){
        $this->load->view('forgetpass_vi');
        return;
    }


    /**
     * パスワード初期化
     */
    public function passwordReset(){
        $Email = $this->input->post('email');
        $birthday = $this->input->post('birthday');
        if($Email != "" && $birthday != "")
        {
            $data = $this->login_mo->getPassdata($Email,$birthday);
            if($data){
                $this->load->view('login_vi');
                return;
            } else {
                $data['errorMsg']= "※メールアドレスと生年月日が一致しません。";
                $this->load->view('forgetpass_vi' ,$data);
                return;
            }
        }
    }
}
?>
