<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Total_con extends CI_Controller {

    public function Total_con() {
        parent::__construct ();
        // ライブラリ
        $this->load->helper('url');
        $this->load->library('session');
        // モデル
        $this->load->model('total_mo');
    }

    public function index() {
        // Get admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) { // Check admin session
            $data = array();
            $data['title'] = '参加者集計';
            if (isset($_POST['total'])) {
                $charger_entitle = $this->total_mo->getChargerEntitle($admin_Id , $charger_type);
                $tour_type = $this->input->post('tour_type');
                $tour = $this->input->post('tour');
                $han = $this->input->post('han');
                $result = array();
                // コースマスタ取得
                $M01_Course = $this->total_mo->getCoursesById($tour);
				//var_dump($M01_Course);
                if (count($M01_Course) > 0) {
                    foreach ( $M01_Course as $key => $val ) {
                        $M01_Course_Id = $val['M01_Dest_Code'] . $val['M01_Han'] . $val['M01_Dep_Id'] . $val['M01_Air_Program'];
                        $results_tmp[$M01_Course_Id] = $this->total_mo->getSearchTotalByCourseMaster($val , '' , $tour, $charger_entitle , $admin_Id);
                    }
                } else {
                    $results_tmp = null;
                }
				//
                $results = $this->convertResult($results_tmp , $han);
            } else {
                // 元々、コースは海外コース一覧
                $tour = '';
                $han = '0';
                $tour_type = 1;
                $results = null;
            }
            $courses = $this->getCourseByTourType($tour_type);
            $courseHans = $this->getCourseHansByCourse($tour);
            $data['tour'] = $tour;
            $data['han'] = $han;
            $data['courses'] = $courses;
            $data['courseHans'] = $courseHans;
            $data['tour_type'] = $tour_type;
            $data['results'] = $results;
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('admin_participant_total_vi' , $data);
            $this->load->view('footer_vi');
        } else {
            redirect(base_url("admin_con"));
        }
    }

    private function createM01CourseArray($val) {
        $M01_CourseArr = array (
                "M01_Dest_Kbn" => $val['M01_Dest_Kbn'],
                "M01_Dest_Code" => $val['M01_Dest_Code'],
                "M01_Han" => $val['M01_Han'],
                "M01_Dep_Id" => $val['M01_Dep_Id'],
                "M01_Air_Program" => $val['M01_Air_Program']
        );
        return $M01_CourseArr;
    }

    /**
     * 検索共有メソッド
     * コースの人数の計算する
     * @param unknown $data
     */
    private function convertResult($data , $han) {
        if (count($data) > 0) {
            // 同行者取得
            $results = NULL;
			
            foreach ( $data as $keys => $vals ) {
                if ($vals != NULL || $vals != '') {
                    $i = 0;
                    $doko_count = 0;
                    $otona_count = 0;
                    $kodomo_count = 0;
                    $y_count = 0;
                    $c_count = 0;
                    foreach ( $vals as $key => $val ) {
                        $data[$keys][$i]['doko_cnt'] = $this->total_mo->getCountDokoshaById($val['R00_Id']);

                        $personType = $this->total_mo->getCountPersonTypeById($val['R00_Id']);
                        $data[$keys][$i]['otona'] = $personType['otona'];
                        $data[$keys][$i]['kodomo'] = $personType['kodomo'];

                        $airClass = $this->total_mo->getCountAirClassById($val['R00_Id']);
                        $data[$keys][$i]['y_class'] = $airClass['y_class'];
                        $data[$keys][$i]['c_class'] = $airClass['c_class'];
                        // 同行者人数足す
                        $doko_count += $data[$keys][$i]['doko_cnt'];
                        $otona_count += $data[$keys][$i]['otona'];
                        $kodomo_count += $data[$keys][$i]['kodomo'];

                        $y_count += $data[$keys][$i]['y_class'];
                        $c_count += $data[$keys][$i]['c_class'];

                        $data[$keys][0]['doko_cnt'] = $doko_count;
                        $data[$keys][0]['otona'] = $otona_count;
                        $data[$keys][0]['kodomo'] = $kodomo_count;
                        $data[$keys][0]['y_class'] = $y_count;
                        $data[$keys][0]['c_class'] = $c_count;
                        $i ++;
                    }
                }
            }
            $i = 0;
			//
            foreach ( $data as $key => $val ) {
                if ($val != NULL || $val != '') {
                    $results[$i] = $val[0];
                    $results[$i]['shainn'] = count($val);
                    unset($results[$i]['R00_Id']);
                }
                $i ++;
            }
            if (count($results) > 0) {
				//var_dump($results);
                foreach ( $results as $result ) {
                    if ($han == 0) {
                        $newArray[$result['R00_Han']][] = $result;
                        $newArray[$result['R00_Han']]['course_name'] = $result['M01_Course_Name-R'];
                    }

                    if ($han != 0 && $result['R00_Han'] == $han) {
                        $newArray[$result['R00_Han']][] = $result;
                        $newArray[$result['R00_Han']]['course_name'] = $result['M01_Course_Name-R'];
                    } else {
                        continue;
                    }
                }
                return $newArray;
            }
        }
        return null;
    }

    private function getCourseByTourType($tour_type) {
        if ($tour_type == 1) {
            $courses = $this->total_mo->getCourseForeignData();
        } elseif ($tour_type == 2) {
            $courses = $this->total_mo->getCourseDomesticData();
        }
        return $courses;
    }

    private function getCourseHansByCourse($tour) {
        $M01_Course = $this->total_mo->getCoursesById($tour);
        if ($M01_Course != null) {
            $courseHans = array();
            foreach ($M01_Course as $course) {
                if ($course['M01_Course_Name-R'] != '' && $course['M01_Course_Name-R'] != null) {
                    $courseHans[$course['M01_Han']] = $course['M01_Course_Name-R'];
                }
            }
            return $courseHans;
        }
        return null;
    }

    public function getCourses() {
        $tour_type = $this->input->post('tour_type');
        $coursesStr = '<option value="">選択してください</option>';
        if ($tour_type == 1) {
            $courses = $this->total_mo->getCourseForeignData();
            if ($courses != null) {
                foreach ($courses as $course) {
                    $coursesStr .= '<option value="' . $course['M00_Course_Id_Pre'] . '">' . $course['M00_Tour_Name'] . '</option>';
                }
            }
        } elseif ($tour_type == 2) {
            $courses = $this->total_mo->getCourseDomesticData();
            foreach ($courses as $course) {
                $coursesStr .= '<option value="' . $course['M00_Course_Id_Pre'] . '">' . $course['M00_Tour_Name'] . '</option>';
            }
        }
        echo $coursesStr;
    }

    public function getHans() {
        $tour = $this->input->post('tour');
        $hanStr = '<option value="0">すべて</option>';
        $M01_Course = $this->total_mo->getCoursesById($tour);
        if ($M01_Course != null) {
            $hans = array();
            foreach ($M01_Course as $course) {
                if ($course['M01_Course_Name-R'] != '' && $course['M01_Course_Name-R'] != null) {
                    $hans[$course['M01_Han']] = $course['M01_Course_Name-R'];
                }
            }
            foreach ($hans as $key => $han) {
                $hanStr .= '<option value="' . $key . '">' . $han . '</option>';
            }
        }
        echo $hanStr;
    }
}