<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mypage_con extends CI_Controller {
    function Mypage_con() {
        parent:: __construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('mypage_mo');
    }

    public function index(){
        $userId = $this->session->userdata('R00_Id');
        //if ($userId != "" && $userId != NULL) {
        $data = array();
        $data = $this->mypage_mo->getUserDataById($userId);
        $data['kibou1'] = $this->mypage_mo->getKibouCourseById($data['R00_kibou1']);
        $data['kibou2'] = $this->mypage_mo->getKibouCourseById($data['R00_kibou2']);
        $data['kibou3'] = $this->mypage_mo->getKibouCourseById($data['R00_kibou3']);
        $data['traveler'] = $this->mypage_mo->getSankaData($userId);

        $this->load->view('head_vi');
        $this->load->view('mypage_vi' , $data);
        $this->load->view('footer_vi');
        return;
        //} else {
            //redirect("login_con/logout");
        //}
    }
}
?>
