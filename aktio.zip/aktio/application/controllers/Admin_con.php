<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );

class Admin_con extends CI_Controller {

    public function Admin_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('admin_mo');
    }

    public function index() {
        $data = array();
        $data['title'] = "管理画面ページ";
        $this->load->view('admin_login_vi' , $data);
    }


    public function admin_login() {
        // ＡｄｍｉｎのＩＤとパスワードをＰＯＳＴメソッドで取得する
        $admin_id = !isset($_POST['admin_Id'])?"":$_POST['admin_Id'];
        $admin_pass = !isset($_POST['admin_Password'])?"":$_POST['admin_Password'];

        $data = array();
        $data['admin_Id'] = $admin_id;
        $data['admin_Password'] = $admin_pass;
        $data['title'] = "ログイン";
        // ＩＤとパスワードをチェックする
        if (empty($admin_id) || empty($admin_pass)) { // IDとパスワード入力していない場合
            if (empty($admin_id) && empty($admin_pass)) {
                $data['messager'] = 'ご登録IDとパスワードを入力してください。';
            } else {
                $data['messager'] = 'ご登録IDまたはパスワードが違います。';
            }
            $this->load->view('admin_login_vi' , $data);
            return;
        } else {
            $adminData = $this->admin_mo->isExistIdAndPassword($admin_id , $admin_pass);
            $charger_type = $adminData['Charger_Type'];
            if ($adminData !=null || $adminData !="" ) {
                // Adminセッションを保存する
                $this->session->set_userdata('admin_id_session' ,$admin_id);
                $this->session->set_userdata('charger_type' , $charger_type);
                redirect(base_url('menu_con'));
            } else {
                $data['messager'] = 'ご登録IDまたはパスワードが違います。';
                $data['title'] = 'ログイン';
                $this->load->view('admin_login_vi' , $data);
                return;
            }
        }
    }

}
