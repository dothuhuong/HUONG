<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Admin_edit_con extends CI_Controller {
    public function Admin_edit_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('admin_edit_mo');
        $this->load->model('common_mo');
        $this->load->model('user_top_mo');
        $this->load->model('mypage_mo');
        $this->load->model('menu_mo');
        $this->load->model('course_mo');
        $this->load->model('transport_ptn_mo');
        $this->load->model('optional_mo');
        $this->load->model('anni_event_mo');
		$this->load->model('hotel_mo');
		$this->load->model('operating_mo');
        $this->load->library('convert_format');
        date_default_timezone_set('Asia/Tokyo');
    }
    public function index() {
        //セクションチェック
        $admin_id     = $this->session->userdata('admin_id_session');
        if(isset($_POST['user_id'])){
            $staff_id  = $this->input->post('user_id');
        }else{
            redirect('menu_con/detail_participant');
        }
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_id)) {
            $data['Charger_Type'] = $charger_type;
            $data['admin_id'] = $admin_id;
            $staff_id  = $staff_id;
            $BeforeStay1Name = "";
            $BeforeStay2Name = "";
            $BeforeStay3Name = "";
            $AfterStay1Name = "";
            $AfterStay2Name = "";
            $AfterStay3Name = "";
             // 代表者情報
            $StaffInfo = $this->admin_edit_mo->getStaffInfo($staff_id);
            $data['SameGroupNo'] = $this->admin_edit_mo->getSameGroup($StaffInfo['R00_Group_No'],$staff_id);
            $data['participantInfo'] = $this->admin_edit_mo->getUserInfo($staff_id);
            $data['traveler_info'] = $this->admin_edit_mo->getAdress_Jitaku($staff_id);
            $data['staffInfo'] = $StaffInfo;
            $R04_data_arr = array(
                "R04_Dest_Kbn"   => $StaffInfo['R00_Dest_Kbn'],
                "R04_Dest_Code"  => $StaffInfo['R00_Dest_Code'],
                "R04_Han"        => $StaffInfo['R00_Han'],
                "R04_Dep_Id"     => $StaffInfo['R00_Dep_Id'],
                "R04_Air_Program"=> $StaffInfo['R00_Air_Program']
            );
            // お知らせを取得する
            $data['notices'] = $this->admin_edit_mo->getNoticeByCondition($R04_data_arr);
            // 確定コースに情報を取得する
            $CourseArr = $this->admin_edit_mo->getKakuteiCourseId($staff_id);
            $kakuteiInfo = $this->admin_edit_mo->getKakuteCourseById($CourseArr);
            $data['kakuteiInfo'] = $kakuteiInfo ;
            $data['rate']=$this->admin_edit_mo->getRateId($kakuteiInfo);
            $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
            $data['visainfo'] = $this->admin_edit_mo->getVisaInfobyDestCode($dest_code);

            //参加者の情報を取得
            $data['esta_sts'] = $this->user_top_mo->getEstaSts();
            $data['etas_sts'] = $this->user_top_mo->getEstaSts();
            $data['cnmi_sts'] = $this->admin_edit_mo->getCNMISts();
            // オプショナルツアー
			$optionals=$this->getOptTourDataArr($staff_id);
            //$data['optionals'] = $this->getOptTourDataArr($staff_id);
			if ($optionals != null) {
                foreach ($optionals as $optional_key => $optional) {
                    $tmp = $optional;
                    /*for ($i = 0 ; $i <=8  ; $i++) {
                        $R04_Tour_ParticipationPlan = 'R04_Tour_ParticipationPlan' . $i;
                        if ($optional[$R04_Tour_ParticipationPlan] != 0) {
                            $participant = $this->user_top_mo->getParticipantOptionalsByPlanAndUserId($staff_id , $i);
                            if ($participant != null) {
                                $tmp['participantOptionals'][] = $participant;
                            }
                        }
                    }*/
					//20170430 add by HT		
					$tmp['opt_select'] = $this->optional_mo->optional_reserve_opt($optional['R04_Pkey']);					
                    $data['optionals'][] = $tmp;
                }			
            }			
            //国内交通　マスタ取得
            $M011_TransArr = array(
                "M011_Dest_Kbn"=>$StaffInfo['R00_Dest_Kbn'],
                "M011_Dest_Code"=>$StaffInfo['R00_Dest_Code'],
                "M011_Han"=>$StaffInfo['R00_Han'],
                "M011_Dep_Id"=>$StaffInfo['R00_Dep_Id'],
                "M011_Air_Program"=>$StaffInfo['R00_Air_Program']
            );
            $data['transport_master'] = $this->common_mo->getTransportPtn($M011_TransArr);
            foreach($data['transport_master'] as $key => $val){
                $data['transport_master'][$key]->Transport_Date = $this->convert_format->ChangeJpDay($val->Transport_Date);
            }
            //ホテル前泊取得
            $data['Hotel_Reserve_Before'] = $this->admin_edit_mo->getR09_Hotel_Reserve($staff_id, 1);
			$data['Hotel_Reserve_After'] = $this->admin_edit_mo->getR09_Hotel_Reserve($staff_id, 2);
			$BeforeArr['R09_ReserveId'] = $staff_id; 
			$BeforeArr['R09_Type'] = 1; 
			$AfterArr['R09_ReserveId'] = $staff_id;
			$AfterArr['R09_Type'] = 2;
			$data['BeforeTotal'] = $this->operating_mo->getHotelTotal($BeforeArr);
			$data['AfterTotal']  = $this->operating_mo->getHotelTotal($AfterArr);			
            //前泊者名取得

            if(count($data['participantInfo'])>0){
                foreach($data['participantInfo'] as $key=>$val){
                    if($val['R01_Before_Stay_Hotel']==1){
                        $BeforeStay1Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                    } elseif ($val['R01_Before_Stay_Hotel']==2){
                        $BeforeStay2Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                    } elseif ($val['R01_Before_Stay_Hotel']==3){
                        $BeforeStay3Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                    }
                }
                //後泊者名取得
                foreach($data['participantInfo'] as $key=>$val){
                    if ($val['R01_After_Stay_Hotel']==1){
                        $AfterStay1Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                    } elseif ($val['R01_After_Stay_Hotel']==2){
                        $AfterStay2Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                    } elseif ($val['R01_After_Stay_Hotel']==3){
                        $AfterStay3Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                    }
                }
            }
            $data['BeforeStay1Name']=$BeforeStay1Name;
            $data['BeforeStay2Name']=$BeforeStay2Name;
            $data['BeforeStay3Name']=$BeforeStay3Name;
            $data['AfterStay1Name']=$AfterStay1Name;
            $data['AfterStay2Name']=$AfterStay2Name;
            $data['AfterStay3Name']=$AfterStay3Name;
            //別便で手配往路
            $data['R07_Transport'] = $this->admin_edit_mo->getTransportDep($StaffInfo['R00_Id']);
            //M20マスタを取得ための配列キー変更
            $M20Arr = $this->convert_format->ChangeArrKey($R04_data_arr, 'R04', 'M20');
            $data['M20_Course_Event'] = $this->admin_edit_mo->getMCourseEvent($M20Arr,$staff_id);

            // 2017/04/02 add payment start
            $paymentData = $this->admin_edit_mo->getPaymentDataByStaffId($staff_id);
            $data['payment'] = $paymentData;
            // 20170402 add payment end

            // 20170406 add by Vien start
            $courseTodoPrimary = $this->convertPrimaryCourseTodo($CourseArr , 'M02');
            if ($courseTodoPrimary != null) {
                $optHayaDate = $this->user_top_mo->getOPHayaByPrimary($courseTodoPrimary);
            } else {
                $optHayaDate = null;
            }
            $data['optHayaDate'] = $optHayaDate;
            // 20170406 add by Vien end

            $data['title'] = "管理者編集画面";
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('admin_edit_mypage_vi', $data);
            return;

        }else{
            redirect(base_url("admin_con"));
        }
    }
    private function convertPrimaryCourseTodo($CourseArr , $newStr) {
        $newPrimary = array();
        if ($CourseArr != null) {
            foreach ($CourseArr as $key => $course) {
                if ($key == 'R00_Dest_Kbn') {
                    $newKey = 'R00_Dest_kbn';
                } else {
                    $newKey = $key;
                }
                $changeKey = str_replace('R00', 'M02', $newKey);
                $newPrimary[$changeKey] = $course;
            }
            return $newPrimary;
        } else {
            return null;
        }
    }
    /**
     * 編集操作
     * 代表者情報変更
     */
    function reserve_edit() {
        $staff_id = $this->input->post('user_id');
        //参加者の情報を取得

        $data['staffInfo'] = $this->user_top_mo->getStaffInfo($staff_id);
        $this->load->view('admin_reserve_edit_vi', $data);
        return;
    }
    //国内交通情報 overlay
    function edit_transport() {
        $staff_id = $this->input->post('user_id');
        $data = $this->TransportCommon($staff_id);
//2017/0605 Add by Ken
		$data['shain_cd'] = $staff_id;
//
        $this->load->view('admin_edit_transport_vi', $data);
        return;
    }
    /*
    * 国内交通共有
    *
    */
    public function TransportCommon($param){
        $data['traveler'] = $this->user_top_mo->getUserInfo($param);
        $StaffInfo = $this->user_top_mo->getStaffInfo($param);
        //国内交通　マスタ取得
        $M011_TransArr = array(
            "M011_Dest_Kbn"=>$StaffInfo['R00_Dest_Kbn'],
            "M011_Dest_Code"=>$StaffInfo['R00_Dest_Code'],
            "M011_Han"=>$StaffInfo['R00_Han'],
            "M011_Dep_Id"=>$StaffInfo['R00_Dep_Id'],
            "M011_Air_Program"=>$StaffInfo['R00_Air_Program']
        );
        $data['transport_master'] = $this->common_mo->getTransportPtn($M011_TransArr);
        $data['course_master']      = $this->getM01_CourseFunc($param);
        $data['R07_Transport']      = $this->admin_edit_mo->getTransportDep($param);
        return $data;
    }
    //前泊
    function edit_hotel_before() {
		$user_id  = $this->input->post('user_id');
        $data = $this->hotel_common(1);
		$data['process'] = 'admin';
		$data['user_id'] = $user_id;	
        $this->load->view('edit_hotel_before_vi', $data);
        return;
    }
	//後泊
    function edit_hotel_after() {
        //セクションからユーザID　取得
		$user_id  = $this->input->post('user_id');
        $data = $this->hotel_common(2);
		$data['process'] = 'admin';
		$data['user_id'] = $user_id;
        $this->load->view('edit_hotel_after_vi', $data);
        return;
    }
	/*
	*
	*/
	function upd_hotel_before() {
        $R00_Id  = $this->input->post('user_id');
        $today = date('Y-m-d H:i:s', time());              
        $Reserve       = $_POST['Reserve'];
        //R01_Reserve保存
        foreach($Reserve as $ReserveKey=>$ReserveVal){
            $ReserveVal['R01_Id'] = $R00_Id;
            $ReserveVal['R01_UpdateTime'] = $today;
            if(!isset($ReserveVal['R01_Before_Stay_Hotel'])){
                $ReserveVal['R01_Before_Stay_Hotel'] = NULL;
            }          
            $this->hotel_mo->setHotelDataInTraveler($ReserveVal);
        }
        $params["R00_Id"] = $R00_Id;
        $params["R00_Zenhaku_Flag"] =  1;
        $params["Update"] =  $today;
        $this->hotel_mo->setHotelDataInResever($params);
        $data = $this->upd_hotel_common($_POST, 1); 
		//ポストデータ消えないようにデータを送る
		$data['redirect']['user_id'] = $R00_Id;
		$this->load->view('redirect_vi', $data);
        return;
    }
	public function upd_hotel_After(){
        $R00_Id  = $this->input->post('user_id');      
        $today = date('Y-m-d H:i:s', time());
        $Reserve       = $_POST['Reserve'];
        //R01_Reserve保存
        foreach($Reserve as $ReserveKey=>$ReserveVal){
            $ReserveVal['R01_Id'] = $R00_Id;
            $ReserveVal['R01_UpdateTime'] = $today;
            if(!isset($ReserveVal['R01_After_Stay_Hotel'])){
                $ReserveVal['R01_After_Stay_Hotel'] = NULL;
            }
            $this->hotel_mo->setHotelDataInTraveler($ReserveVal);
        }
        $params["R00_Id"] = $R00_Id;
        $params["R00_Kouhaku_Flag"] =  1;
        $params["Update"] =  $today;
        $this->hotel_mo->setHotelDataInResever($params);
        $data = $this->upd_hotel_common($_POST, 2);
		$data['redirect']['user_id'] = $R00_Id;
		$this->load->view('redirect_vi', $data);
        return;
    }
    /**
     * パスポート変更画面
     */
    function edit_pass() {
        // 初期化
        $data        = array();
        $user_id   = !empty($_POST['user_id'])?$_POST['user_id']:0; // R01_Id
        $user_plan = !empty($_POST['user_plan'])?$_POST['user_plan']:0; // R01_Plan
        $data['participantInfo'] = $this->user_top_mo->getParticipantInfoByIdAndPlan( $user_id , $user_plan);
        $this->load->view('admin_edit_pass_vi', $data);
        return;
    }
      /*
     ESTA変更画面
     */
    function edit_esta() {
        $R00_Id = ! isset($_POST['user_id']) ? "" : $_POST['user_id'];
        $user_plan = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        $ESTA_result  = $this->user_top_mo->getEsta($R00_Id, $user_plan);
        $data['esta'] = $ESTA_result;
        $data['R00_Id'] = $R00_Id;
        $data['user_plan'] = $user_plan;
        $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
        $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
        //Visa 査証情報を取得
        $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
        $Visainfo = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
        $data['Visa_Arr'] = $this->user_top_mo->getVisaArrbyDestCode($Visainfo);
        $this->load->view('admin_edit_esta_vi', $data);
        return;
    }
    //連絡先等情報変更
    function mypage_edit() {
        //セクションからユーザID　取得
        $R00_Id = ! isset($_POST['user_id']) ? "" : $_POST['user_id'];
        $data['emergency_info'] = $this->mypage_mo->getEmergenctDataById($R00_Id);
        $data['sendplace_info'] = $this->user_top_mo->getSendPlace();
        $data['traveler_info'] = $this->user_top_mo->getAdress_Jitaku($R00_Id);
        $data['R00_Id'] =  $R00_Id;
        $this->load->view('admin_contact_edit_vi', $data);
        return;
    }
    
    /*
    *
    *50周年イベント参加
    */
    public function anni_event(){
        $user_id = $this->input->post('user_id');
        $StaffInfo = $this->user_top_mo->getStaffInfo($user_id);
        $M20Arr = array(
            "M20_Dest_Kbn"    => $StaffInfo['R00_Dest_Kbn'],
            "M20_Dest_Code"      => $StaffInfo['R00_Dest_Code'],
            "M20_Han"          => $StaffInfo['R00_Han'],
            "M20_Dep_Id"      => $StaffInfo['R00_Dep_Id'],
            "M20_Air_Program" => $StaffInfo['R00_Air_Program']
        );
        $M01Arr = array(
            "R00_Dest_Kbn"    => $StaffInfo['R00_Dest_Kbn'],
            "R00_Dest_Code"      => $StaffInfo['R00_Dest_Code'],
            "R00_Han"          => $StaffInfo['R00_Han'],
            "R00_Dep_Id"      => $StaffInfo['R00_Dep_Id'],
            "R00_Air_Program" => $StaffInfo['R00_Air_Program']
        );
        $M20_result = $this->admin_edit_mo->getMCourseEvent($M20Arr, $user_id);
        $data['StaffInfo'] = $StaffInfo;
        $data['M01_result'] = $this->user_top_mo->getKakuteCourseById($M01Arr);
        $data['M20_result'] = $M20_result;
        $this->load->view('admin_anni_event_vi', $data);
    }
    //参加者情報変更
    function traveler_edit() {
        $R00_Id = $this->input->post('user_id');
       //参加者の情報を取得
        $data['participantInfo'] = $this->user_top_mo->getUserInfo($R00_Id);
        $this->load->view('admin_traveler_edit_vi', $data);
        return;
    }
    /*
    *オーストラリアETA
    *
    */
    public function AustraliaForm(){
        $R00_Id = $this->input->post('user_id');
        $user_plan = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        if ($R00_Id != '' || $R00_Id != null) {
            $ETAS_result  = $this->user_top_mo->getEtas($R00_Id, $user_plan);
            $data['etas'] = $ETAS_result;
            $data['R00_Id'] = $R00_Id;
            $data['user_plan'] = $user_plan;
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
            //Visa 査証情報を取得
            $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
            $Visainfo = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
            $data['Visa_Arr'] = $this->user_top_mo->getVisaArrbyDestCode($Visainfo);
            $this->load->view('admin_australia_eta_entry_vi', $data);
            return;
        } else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *カナダETA
    *
    */
    public function CanadaForm(){
        $R00_Id = ! isset($_POST['user_id']) ? "" : $_POST['user_id'];
        $this->load->view('admin_canada_eta_entry_vi');
    }
    /*
    *グアムETA
    *
    */
    public function GuamForm(){
        $R00_Id = ! isset($_POST['user_id']) ? "" : $_POST['user_id'];
        $user_plan = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        $CNMI_result  = $this->user_top_mo->getCNMI($R00_Id, $user_plan);
        $data['cnmi'] = $CNMI_result;
        $data['R00_Id'] = $R00_Id;
        $data['user_plan'] = $user_plan;
        $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
        $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
        //Visa 査証情報を取得
        $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
        $Visainfo = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
        $data['Visa_Arr'] = $this->user_top_mo->getVisaArrbyDestCode($Visainfo);
        $this->load->view('admin_guam_eta_entry_vi', $data);
        return;
    }
    public function confirmed_course(){
        $user_id = $this->input->post('user_id');
        $data['M01_Courses'] = $this->course_mo->getM01_Course();
        $StaffInfo = $this->user_top_mo->getStaffInfo($user_id);
        $data['SameGroupNo'] = $this->admin_edit_mo->getSameGroup($StaffInfo['R00_Group_No'],$user_id);
        $data['StaffInfo']   = $this->user_top_mo->getStaffInfo($user_id);
        $data['All_User'] = $this->admin_edit_mo->getUserIdForGroup();
        $this->load->view('admin_confirmed_course_vi',$data);
        return;
    }
    /*
    *
    *変更のグルプ代表者表示
    */
    public function getGroupName(){
        $user_id = $this->input->post('R00_Id');
        $StaffInfo = $this->user_top_mo->getStaffInfo($user_id);
        if(count($StaffInfo)>0){
            echo $StaffInfo['R00_Sei'].$StaffInfo['R00_Name'];
        }else{
            echo '';
        }
    }
    /*
    *オプションナルツーア編集
    *
    */
    public function Optional_edit(){
        $user_id = $this->input->post('user_id');
        // 確定コースに情報を取得する
        $CourseArr = $this->admin_edit_mo->getKakuteiCourseId($user_id);
        $kakuteiInfo = $this->admin_edit_mo->getKakuteCourseById($CourseArr);
        $data['kakuteiInfo'] = $kakuteiInfo ;
        $data['optionals']   = $this->getOptTourDataArr($user_id);
        $data['M10_Masters'] = $this->optional_mo->getAllStatus();
        $this->load->view('admin_optional_edit_vi',$data);
        return;
    }
    /*
    *
    *支払編集
    */
    public function Payment_edit(){
        $user_id  = $this->input->post('user_id');
        $data['R01_Traveler'] = $this->admin_edit_mo->getTravelerInfo($user_id);
        $this->load->view('admin_edit_payment_vi',$data);
    }
    /*
    *
    *管理者備考編集画面
    */
    public function Admin_note_edit(){
        $user_id              = $this->input->post('user_id');
        $data['R00_Reserve'] = $this->admin_edit_mo->getStaffInfo($user_id);
        $this->load->view('admin_edit_admin_note_vi',$data);
    }
    /*
    *
    *管理者備考（ＫＮＴ内部）編集画面
    */
    public function KNT_note_edit(){
        $user_id              = $this->input->post('user_id');
        $data['R00_Reserve'] = $this->admin_edit_mo->getStaffInfo($user_id);
        $this->load->view('admin_edit_knt_note_vi',$data);
    }
    /*
    *
    * 予約キャンセル
    */
    public function Cancellation_reserve(){
        $R01_Id   = $this->input->post('user_id');
        $R01_Plan = $this->input->post('user_plan');
        $data['Traveler'] = $this->admin_edit_mo->getTravelerInfo($R01_Id);
        $data['R01_Id'] = $R01_Id;
        $data['R01_Plan'] = $R01_Plan;
        $this->load->view('admin_edit_cancel_vi',$data);
    }
    /*
    *
    *新規追加
    */
    public function Add_member(){
        $R01_Id   = $this->input->post('user_id');
        $Traveler = $this->admin_edit_mo->getTravelerInfo($R01_Id);
        $Traveler_cnt = count($Traveler);
        $data['R01_Id'] = $R01_Id;
        $data['Traveler_cnt'] = $Traveler_cnt;
        $this->load->view('admin_add_new_member_vi',$data);
    }
    //更新操作
    /*
    *代表者情報更新
    *
    */

    function updateReserveInfo(){
        $today = date('Y-m-d H:i:s', time());
        $params = array(
                "R00_Id"                     => $this->input->post('user_id') ,
                "R00_Company"                 => $this->input->post('R00_Company'),
                "R00_Division_Code"         => $this->input->post('R00_Division_Code'),
                "R00_Division"                 => $this->input->post('R00_Division'),
                "R00_Company_Post1"         => $this->input->post('R00_Company_Post1'),
                "R00_Company_Post2"         => $this->input->post('R00_Company_Post2'),
                "R00_Company_Pref"             => $this->input->post('R00_Company_Pref'),
                "R00_Company_Address1"         => $this->input->post('R00_Company_Address1'),
                "R00_Company_Address2"         => $this->input->post('R00_Company_Address2'),
                "R00_Company_Tel"             => $this->input->post('R00_Company_Tel'),
                "R00_Division"                 => $this->input->post('R00_Division'),
                "R00_Company_Fax"             => $this->input->post('R00_Company_Fax'),
                "R00_Mailaddress"             => $this->input->post('R00_Mailaddress'),
                "R00_1Room_wish"             => $this->input->post('R00_1Room_wish'),
                "Update"                    => $today
            );
            $result = $this->user_top_mo->updateEmergency($params);
        //(一人部屋追加料金)
        //1人部屋費用
        $R01_Traveler['R01_Id']            = $this->input->post('user_id');
        $R01_Traveler['R01_Plan']        = 0;
        $R01_Traveler['R01_Cost4']        = 0;
        $R01_Traveler['R01_Cost_Name4']    = '';
        if($params['R00_1Room_wish'] == "希望する"){
            $Course = array(
                'M01_Dest_Kbn' => $this->input->post('R00_Dest_Kbn'),
                'M01_Dest_Code' => $this->input->post('R00_Dest_Code'),
                'M01_Han' => $this->input->post('R00_Han'),
                'M01_Dep_Id' => $this->input->post('R00_Dep_Id'),
                'M01_Air_Program' => $this->input->post('R00_Air_Program')
            );
            $R01_Traveler['R01_Id']            = $this->input->post('user_id');
            $R01_Traveler['R01_Plan']        = 0;
            $R01_Traveler['R01_Cost4']        = $this->admin_edit_mo->getRoomCostMaster($Course);
            $R01_Traveler['R01_Cost_Name4'] = "1人部屋料金";
        }
        $this->admin_edit_mo->upd_R01($R01_Traveler);
        $data['redirect']['user_id'] = $params['R00_Id'];
        $this->load->view('redirect_vi', $data);
        return;
    }
    /*
    *参加者情報更新
    *
    */
    function updateTravelInfo(){
        $R00_Id = $this->input->post('user_id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $Traveler = $_POST['Traveler'];
            //参加者の国内交通データの格納
            foreach($Traveler as $traKey => $traVal){
                $traVal['R01_Id'] = $R00_Id;
                $traVal['R01_Birthday'] = $traVal['R01_Birthday_Year'].'-'.$traVal['R01_Birthday_Month'].'-'.$traVal['R01_Birthday_Date'];
                $traVal['R01_UpdateTime'] = $today;
                unset( $traVal['R01_Birthday_Year'] );
                unset( $traVal['R01_Birthday_Month'] );
                unset( $traVal['R01_Birthday_Date'] );
                $result = $this->user_top_mo->setTravelinfo($traVal);
            }
            $this->CalTotalMoney($R00_Id);
            $data['redirect']['user_id'] = $R00_Id;
            $this->load->view('redirect_vi', $data);
            return;
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *    パスポート更新
    */
    public function updatePasspost(){
        $today = date('Y-m-d H:i:s', time());
        $params = array(
            "R01_Id"                     => $this->input->post('R01_Id'),
            "R01_Plan"                     => $this->input->post('R01_Plan'),
            "R01_Passport_No"             => $this->input->post('R01_Passport_No'),
            "R01_Passport_Sei"             => $this->input->post('R01_Passport_Sei'),
            "R01_Passport_Name"         => $this->input->post('R01_Passport_Name'),
            "R01_Passport_Middle"         => $this->input->post('R01_Passport_Middle'),
            "R01_Passport_Expire"       => $this->input->post('R01_Passport_Expire_Year').'-'.$this->input->post('R01_Passport_Expire_Month').'-'.$this->input->post('R01_Passport_Expire_Date'),
            "R01_UpdateTime"            => $today
        );
        $updateResult = $this->user_top_mo->updatePasspost($params);
        if($updateResult > 0){
            echo "success";
        }else{
            echo "error";
        }
    }
    public function CNMICreateWithAns(){
        $today = date('Y-m-d H:i:s', time());
        $result  = $this->user_top_mo->getCNMI($_POST['R11_Id'], $_POST['R11_Seq']);
        $data = array(
            "R01_Id"             => $this->input->post('R11_Id'),
            "R01_Plan"            => $this->input->post('R11_Seq'),
            "R01_Cost_Name1"    => $this->input->post('R01_Cost_Name'),
            "R01_Cost1"            => $this->input->post('R01_Cost'),
            "R01_UpdateTime" =>$today
        );
        $result_visa = $this->user_top_mo->updVisainfo($data);
        if(isset($_POST['R11_CNMI_Issue_Yr']) && isset($_POST['R11_CNMI_Issue_Month']) && isset($_POST['R11_CNMI_Issue_Day'])){
            $_POST['R11_CNMI_Issue'] = $_POST['R11_CNMI_Issue_Yr'].'-'.$_POST['R11_CNMI_Issue_Month'].'-'.$_POST['R11_CNMI_Issue_Day'];
            unset( $_POST['R11_CNMI_Issue_Yr'] );
            unset( $_POST['R11_CNMI_Issue_Month'] );
            unset( $_POST['R11_CNMI_Issue_Day'] );
        }
        unset( $_POST['R01_Cost_Name'] );
        unset( $_POST['R01_Cost'] );
        if($result == NULL){
            //insert
            $_POST['R11_Create_Date'] = $today;
            $result_cnt = $this->user_top_mo->setCNMI($_POST);
        }else{
            //update
            $_POST['R11_Update_Date'] = $today;
            $result_cnt = $this->user_top_mo->updCNMI($_POST);
        }
        $data['redirect']['user_id'] = $this->input->post('R11_Id');;
        $this->load->view('redirect_vi', $data);
        //redirect(base_url('admin_edit_con'));
        return;
    }
    /*
    *
    *ESTA データ作成
    */
    public function EstaCreate(){
        $R00_Id = $this->session->userdata('R00_Id');
        $data['R01_Plan'] = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $params = array(
                "R06_Id"               => $this->input->post('R06_Id'),
                "R06_Id_Seq"          => $this->input->post('R06_Id_Seq'),
                "R06_Esta_Have"           => $this->input->post('R06_Esta_Have'),
                "R06_Esta_Exp_Yr"      => $this->input->post('R06_Esta_Exp_Yr'),
                "R06_Esta_Exp_M"      => $this->input->post('R06_Esta_Exp_M'),
                "R06_Esta_Exp_Day"   => $this->input->post('R06_Esta_Exp_Day'),
                "R06_Esta_Register"  => $this->input->post('R06_Esta_Register')
            );
            $result  = $this->user_top_mo->getEsta($params['R06_Id'], $params['R06_Id_Seq']);
            if($params['R06_Esta_Have'] == "1"){

                $data = array(
                    "R01_Id"             => $this->input->post('R06_Id'),
                    "R01_Plan"            => $this->input->post('R06_Id_Seq'),
                    "R01_Cost_Name1"    => "",
                    "R01_Cost1"            => "0",
                    "R01_UpdateTime" =>$today
                );

                $result_visa = $this->user_top_mo->updVisainfo($data);

            }
            
            if($result == NULL){
                //insert
                $result_cnt = $this->user_top_mo->setEsta($params);
            }else{
                //update
                $result_cnt = $this->user_top_mo->updEsta($params);

            }
                echo 'success';
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *
    */				
    public function EstaCreateWithAns(){
        $today = date('Y-m-d H:i:s', time());
        unset( $_POST['register'] );
        $result  = $this->user_top_mo->getEsta($_POST['R06_Id'], $_POST['R06_Id_Seq']);
        if(isset($_POST['R06_CitizenElse_Expire_Yr']) && isset($_POST['R06_CitizenElse_Expire_Yr']) && isset($_POST['R06_CitizenElse_Expire_Yr'])){
            $_POST['R06_CitizenElse_Expire'] = $_POST['R06_CitizenElse_Expire_Yr'].'-'.$_POST['R06_CitizenElse_Expire_Month'].'-'.$_POST['R06_CitizenElse_Expire_Day'];
            unset( $_POST['R06_CitizenElse_Expire_Yr'] );
            unset( $_POST['R06_CitizenElse_Expire_Month'] );
            unset( $_POST['R06_CitizenElse_Expire_Day'] );
        }
        if(isset($_POST['kiyaku1'])){
            unset( $_POST['kiyaku1'] );
        }
        if(isset($_POST['kiyaku2'])){
            unset( $_POST['kiyaku2'] );
        }
        $_POST['Update'] = $today;
        if (isset($_POST['R06_Esta_Have']) && $_POST['R06_Esta_Have'] == '1' ) {
        	$data = array(
        			"R01_Id"         => $this->input->post('R06_Id'),
        			"R01_Plan"       => $this->input->post('R06_Id_Seq'),
        			"R01_Cost_Name1" => "",
        			"R01_Cost1"      => "0",
        			"R01_UpdateTime" => $today
        	);
        	$result_visa = $this->user_top_mo->updVisainfo($data);
        }
        if(isset($_POST['R06_Esta_Register'])){
            if($_POST['R06_Esta_Register'] == "2"){            	
                $data = array(
                    "R01_Id"             => $this->input->post('R06_Id'),
                    "R01_Plan"            => $this->input->post('R06_Id_Seq'),
                    "R01_Cost_Name1"    => $this->input->post('R01_Cost_Name'),
                    "R01_Cost1"            => $this->input->post('R01_Cost'),
                    "R01_UpdateTime" =>$today
                );
                $result_visa = $this->user_top_mo->updVisainfo($data);
            }elseif($_POST['R06_Esta_Register'] == "1"){
                $data = array(
                    "R01_Id"             => $this->input->post('R06_Id'),
                    "R01_Plan"            => $this->input->post('R06_Id_Seq'),
                    "R01_Cost_Name1"    => "",
                    "R01_Cost1"            => "0",
                    "R01_UpdateTime" =>$today
                );
                $result_visa = $this->user_top_mo->updVisainfo($data);
            }
        }
        
        unset( $_POST['R01_Cost_Name'] );
        unset( $_POST['R01_Cost'] );
       
        if($result == NULL){
            //insert
            $result_cnt = $this->user_top_mo->setEsta($_POST);
        }else{
            //update
        	$result_cnt = $this->user_top_mo->updEsta($_POST);
        }

        $data['redirect']['user_id'] = $this->input->post('R06_Id');

        $this->load->view('redirect_vi', $data);
        return;
        //redirect(base_url('admin_edit_con'));
    }
    /*
    *
    *ETASデータ作成
    */
    public function EtasCreate(){
        $today = date('Y-m-d H:i:s', time());
        $params = array(
            "R10_Id"               => $this->input->post('R10_Id'),
            "R10_Seq"          => $this->input->post('R10_Seq'),
            "R10_Etas_Have"           => $this->input->post('R10_Etas_Have'),
            "R10_Etas_Exp_Yr"      => $this->input->post('R10_Etas_Exp_Yr'),
            "R10_Etas_Exp_M"      => $this->input->post('R10_Etas_Exp_M'),
            "R10_Etas_Exp_Day"   => $this->input->post('R10_Etas_Exp_Day'),
            "R10_Etas_Register"  => $this->input->post('R10_Etas_Register'),
            "R10_Create_Date" =>$today
        );
        $result  = $this->user_top_mo->getEtas($params['R10_Id'], $params['R10_Seq']);
        if($params['R10_Etas_Have'] == "1"){
            $data = array(
                "R01_Id"             => $this->input->post('R10_Id'),
                "R01_Plan"            => $this->input->post('R10_Seq'),
                "R01_Cost_Name1"    => "",
                "R01_Cost1"            => "0",
                "R01_UpdateTime" =>$today
            );
            $result_visa = $this->user_top_mo->updVisainfo($data);
        }
        
        if($result == NULL){
            //insert
            $result_cnt = $this->user_top_mo->setEtas($params);
        }else{
            //update
            $result_cnt = $this->user_top_mo->updEtas($params);
        }
        if($result_cnt >0){
            echo 'success';
        }else{
            echo 'error';
        }
    }
    /*
    *
    *Esta 作成
    */
    public function EtasCreateWithAns(){
        $today = date('Y-m-d H:i:s', time());
        unset( $_POST['register'] );
        $result  = $this->user_top_mo->getEtas($_POST['R10_Id'], $_POST['R10_Seq']);
        if($_POST['R10_Etas_Have'] == "1"){
        	$data = array(
        			"R01_Id"             => $this->input->post('R10_Id'),
        			"R01_Plan"            => $this->input->post('R10_Seq'),
        			"R01_Cost_Name1"    => "",
        			"R01_Cost1"            => "0",
        			"R01_UpdateTime" =>$today
        	);
        	$result_visa = $this->user_top_mo->updVisainfo($data);
        }else{
	                $data = array(
	                    "R01_Id"             => $this->input->post('R10_Id'),
	                    "R01_Plan"            => $this->input->post('R10_Seq'),
	                    "R01_Cost_Name1"    => $this->input->post('R01_Cost_Name'),
	                    "R01_Cost1"            => $this->input->post('R01_Cost'),
	                    "R01_UpdateTime" =>$today
	                );
	                $result_visa = $this->user_top_mo->updVisainfo($data);
	            }
        unset( $_POST['R01_Cost_Name'] );
        unset( $_POST['R01_Cost'] );
        
        if($result == NULL){
            //insert
            $_POST['R10_Create_Date'] = $today;
            $result_cnt = $this->user_top_mo->setEtas($_POST);
        }else{
            //update
            $_POST['R10_Update_Date'] = $today;
            $result_cnt = $this->user_top_mo->updEtas($_POST);
        }
        $data['redirect']['user_id'] = $this->input->post('R10_Id');;
        $this->load->view('redirect_vi', $data);
        return;
    }
    /*
    *
    *    緊急連絡先更新
    */
    public function updateEmergencyInfo(){
        $today = date('Y-m-d H:i:s', time());
        $params = array(
            "R00_Id"              => $this->input->post('R00_Id'),
            "R00_emargency_mei"  => $this->input->post('R00_emargency_mei'),
            "R00_emargency_zoku" => $this->input->post('R00_emargency_zoku'),
            "R00_emargency_tel"  => $this->input->post('R00_emargency_tel'),
            "R00_allergy_Note"      => $this->input->post('R00_allergy_Note'),
            "R00_SendPlace"      => $this->input->post('R00_SendPlace'),
            "R00_Document_Atena"      => $this->input->post('R00_Document_Atena')

        );

        $updateResult = $this->user_top_mo->updateEmergency($params);
        //会社
        if($params['R00_SendPlace'] == 2){
            $data['R00_Id'] = $R00_Id;
            $data['R00_Company_Post1']  = $this->input->post('R00_Document_Post1');
            $data['R00_Company_Post2'] = $this->input->post('R00_Document_Post2');
            $data['R00_Company_Pref']  = $this->input->post('R00_Document_Pref');
            $data['R00_Company_Address1']      = $this->input->post('R00_Document_Addr1');
            $data['R00_Company_Address2']      = $this->input->post('R00_Document_Addr2');
            $updatePlace = $this->user_top_mo->updateAdressCompany($data);

        }

        //その他
        if($params['R00_SendPlace'] == 9){
            $data['R00_Id'] = $this->input->post('R00_Id');
            $data['R00_Document_Post1']  = $this->input->post('R00_Document_Post1');
            $data['R00_Document_Post2'] = $this->input->post('R00_Document_Post2');
            $data['R00_Document_Pref']  = $this->input->post('R00_Document_Pref');
            $data['R00_Document_Addr1']      = $this->input->post('R00_Document_Addr1');
            $data['R00_Document_Addr2']      = $this->input->post('R00_Document_Addr2');
            $updatePlace = $this->user_top_mo->updateAdressCompany($data);
        }
        //自宅
        if($params['R00_SendPlace'] == 1){
            $data['R01_Id'] = $this->input->post('R00_Id');
            $data['R01_Post1']  = $this->input->post('R00_Document_Post1');
            $data['R01_Post2'] = $this->input->post('R00_Document_Post2');
            $data['R01_Address_Pref']  = $this->input->post('R00_Document_Pref');
            $data['R01_Address1']      = $this->input->post('R00_Document_Addr1');
            $data['R01_Address2']      = $this->input->post('R00_Document_Addr2');
            $updatePlace = $this->user_top_mo->updateAdressCompany_Travel($data);
        }

        if($updateResult > 0){
            echo 'success';
        }else{
            echo 'error';
        }
    }
    /*
    *
    *確定コース更新
    */
    public function updateConfirmedCourse(){
        $confirmed_course =  $this->input->post('confirmed_course');
        $confirmed_course_arr = explode('_', $confirmed_course);
        $params= array(
            'R00_Id' => $this->input->post('R00_Id'),
            'R00_Group_Daihyo_Name' => $this->input->post('R00_Group_Daihyo_Name'),
            'R00_Dest_Kbn'            => $confirmed_course_arr[0],
            'R00_Dest_Code'            => $confirmed_course_arr[1],
            'R00_Han'                => $confirmed_course_arr[2],
            'R00_Dep_Id'            => $confirmed_course_arr[3],
            'R00_Air_Program'        => $confirmed_course_arr[4],
            'R00_Group_No'             => $this->input->post('R00_Group_No')
        );
        $R00_Id = $this->input->post('R00_Id');
        $result = $this->admin_edit_mo->upd_R00($params);
        $this->CalTotalMoney($R00_Id);
        if($result>0){
            echo 'success';
        }else{
            echo 'error';
        }
    }
    /*
    *
    *国内交通更新
    */
    function update_transport(){
        $R00_Id = $this->input->post('user_id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $data['course_master']  = $this->getM01_CourseFunc($R00_Id);
            $Traveler = $_POST['Traveler'];
            //参加者の国内交通データの格納
            foreach($Traveler as $traKey => $traVal){
                $traVal['R01_Id'] = $R00_Id;
                $result = $this->transport_ptn_mo->setTranportPtn($traVal);
                //if ($traVal['R01_Departure_Ptn'] != 1 && $traVal['R01_Departure_Ptn'] != 2){
                //}
            }
            for($i=0;$i<2;$i++){
                $j=$i+1;
                $departure = $_POST['departure'.$j];
                foreach($departure as $depKey => $depVal){
                    $depVal['R07_Transport_Sequence'] =$depKey+1;
                    $depVal['R07_Transport_No'] = $j;
                    $depVal['R07_Transport_Type'] =1;
                    $depVal['R07_ReserveId']      = $R00_Id;
                    $Tranport = $this->transport_ptn_mo->getTranportlDataInTraveler(1,$R00_Id,$j);
                    if($Tranport == null){
                        //$depVal['R07_Transport_Date']      = $data['course_master']['M01_Dep_Date'];
                        $depVal['R07_Transport_Place']      = "";
                        $depVal['R07_Transport_Dep_Time']      = "";
                        $depVal['R07_Transport_Name']      = "";
                        $depVal['R07_Transport_Arr_Place']      = "";
                        $depVal['R07_Transport_Arr_Time']      = "";
                        $depVal['R07_Note']      = "";
                    }
                    $this->transport_ptn_mo->setTranport($depVal);
                }

                $arrival = $_POST['arrival'.$j];

                foreach($arrival as $arrKey => $arrVal){
                    $arrVal['R07_Transport_Sequence'] =$arrKey+1;
                    $arrVal['R07_Transport_No'] = $j;
                    $arrVal['R07_Transport_Type'] =2;
                    $arrVal['R07_ReserveId']      = $R00_Id;
                    $Tranport = $this->transport_ptn_mo->getTranportlDataInTraveler(2,$R00_Id,$j);
                    if($Tranport == null){
                        //$arrVal['R07_Transport_Date']      = $data['course_master']['M01_Arr_Date'];
                        $arrVal['R07_Transport_Place']      = "";
                        $arrVal['R07_Transport_Dep_Time']      = "";
                        $arrVal['R07_Transport_Name']      = "";
                        $arrVal['R07_Transport_Arr_Place']      = "";
                        $arrVal['R07_Transport_Arr_Time']      = "";
                        $arrVal['R07_Note']      = "";
                    }
                    $this->transport_ptn_mo->setTranport($arrVal);

                }

            }

            //ポストデータ消えないようにデータを送る
            $data['redirect']['user_id'] = $R00_Id;
            $this->load->view('redirect_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *オプショナルツアー更新
    *
    */
    public function updateOptionalTour(){
        $params =  $this->input->post('Option');
        
        //オプショナルツアー更新
        foreach($params as $key => $val){
			if($val['R04_STS']== '3'){
        		$val['R04_Tour_Cost'] = 0;
        		$val['R04_Tour_Jpy'] = 0;
        	}        	
            $this->admin_edit_mo->upd_option_tour($val);
        }
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $params[0]['R04_Id'];
        $this->load->view('redirect_vi', $data);
        return;
    }
    /**
     * 50周年イベント参加更新
     */
    public function updateAnni(){
        $R08_Course_Event = $this->input->post('R08_Course_Event_Reserve');
        foreach ($R08_Course_Event as $key=>$val){
            $this->anni_event_mo->set_Course_Event_Reserve($val);
        }
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $R08_Course_Event[0]['R08_Id'];
        $this->load->view('redirect_vi', $data);
    }
    /**
     * 支払更新
     */
    public function updatePayment(){
        $Payment = $this->input->post('Payment');
        foreach($Payment as $key => $val){
            $this->admin_edit_mo->upd_R01($val);
        }
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $Payment[0]['R01_Id'];
        $this->load->view('redirect_vi', $data);
    }
    /*
    *
    *管理者備考更新
    */
    public function updateAdminNote(){
        $param = array(
            "R00_Id"          => $this->input->post('R00_Id'),
            "R00_Admin_Note" => $this->input->post('R00_Admin_Note')
        );
        $this->admin_edit_mo->upd_R00($param);
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $param['R00_Id'];
        $this->load->view('redirect_vi', $data);
    }
    /*
    *
    *管理者備考（ＫＮＴ内部）更新
    */
    public function updateKNTNote(){
        $param = array(
            "R00_Id"          => $this->input->post('R00_Id'),
            "R00_KNT_Note" => $this->input->post('R00_KNT_Note')
        );
        $this->admin_edit_mo->upd_R00($param);
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $param['R00_Id'];
        $this->load->view('redirect_vi', $data);
    }
    /**
     * キャンセル取り消し
     */
    public function cancel_cancellation(){
        $param = array(
            "R01_Id"  => $this->input->post('R01_Id'),
            "R01_Plan"  => $this->input->post('R01_Plan'),
            "R01_Cancel_Day"  => NULL,
            "R01_Cancel_Cost" => 0,
            "R01_Cancel_flag" => 0
        );
        $result = $this->admin_edit_mo->upd_R01($param);
        if($result ==1){
            echo 'success';
        }else{
            echo 'error';
        }
    }
    /**
     * キャンセル更新
     */
    public function updateCancellation(){
        $now = new DateTime();
        $now->setTimezone(new DateTimezone('Asia/Tokyo'));
        $Cancel_Day = $now->format('Y-m-d H:i:s');
        $Traveler = $this->input->post('Traveler');
        foreach($Traveler as $key=>$val){
            /*if($val['R01_Plan']==0){
                $CourseClear = array(
                    "R00_Id"           => $val['R01_Id'],
                    "R00_Dest_Kbn"    => NULL,
                    "R00_Dest_Code"   => NULL,
                    "R00_Han"          => NULL,
                    "R00_Dep_Id"      => NULL,
                    "R00_Air_Program" => NULL
                );
                $this->admin_edit_mo->upd_R00($CourseClear);
            }*/
            $val['R01_Cancel_Day']  = $Cancel_Day;
            $val['R01_Cancel_flag'] = 1;
            $this->admin_edit_mo->upd_R01($val);
        }
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $Traveler[0]['R01_Id'];
        $this->load->view('redirect_vi', $data);
    }
    /**
     * 新規追加
     */
    public function Insert_new_member(){
        $now = new DateTime();
        $now->setTimezone(new DateTimezone('Asia/Tokyo'));
        $R01_UpdateTime = $now->format('Y-m-d H:i:s');
        $Traveler = $this->input->post('Traveler');
        $Traveler[0]['R01_Birthday'] = $Traveler[0]['R01_Birthday_Year'].'-'.$Traveler[0]['R01_Birthday_Month'].'-'.$Traveler[0]['R01_Birthday_Day'];
        unset( $Traveler[0]['R01_Birthday_Year'] );
        unset( $Traveler[0]['R01_Birthday_Month'] );
        unset( $Traveler[0]['R01_Birthday_Day'] );
        $Traveler[0]['R01_Plan_Child']          = 0;
        $Traveler[0]['R01_Sequence']          = 0;
        $Traveler[0]['R01_Relationship_Code']= 0;
        $Traveler[0]['R01_Participation']      = 1;
        $Traveler[0]['R01_Passport_Expire']  = '0000-00-00';
        $Traveler[0]['R01_Passport_Issue']   = '0000-00-00';
        $Traveler[0]['R01_UpdateTime']       = $R01_UpdateTime;
        $Traveler[0]['R01_PassportImg']      = '';
        $this->admin_edit_mo->Insert_new_member($Traveler[0]);
		$R00_Id = $this->input->post('user_id');
		 $this->CalTotalMoney($Traveler[0]['R01_Id']);
        //ポストデータ消えないようにデータを送る
        $data['redirect']['user_id'] = $Traveler[0]['R01_Id'];
        $this->load->view('redirect_vi', $data);
    }

    /**
     * 同グルプ者検索
     */
    public function getSameGroup(){
        $params= array(
            'R00_Group_No' => $this->input->post('R00_Group_No')
        );
        $result = $this->admin_edit_mo->getSameGroupForWarning($params);
        if(count($result)>0){
            echo json_encode($result);
        }else{

        }
    }
    /**
     * コースデータ取得共有メソッド
     * @param unknown $R00_Id
     */
    public function getM01_CourseFunc($R00_Id){
        $staff_info = $this->user_top_mo->getStaffInfo($R00_Id);
        $Course_Arr = $this->getM01_CourseArr($staff_info);
        $M01_Course    = $this->course_mo->getM01_Course($Course_Arr);
        return $M01_Course[0];
    }
    /**
     * コース配列作成
     * @param unknown $params
     * @return unknown[]
     */
    public function getM01_CourseArr($params){
        $Course_Arr = array(
            "M01_Dest_Kbn"=> $params['R00_Dest_Kbn'],
            "M01_Dest_Code"=> $params['R00_Dest_Code'],
            "M01_Han"=> $params['R00_Han'],
            "M01_Dep_Id"=> $params['R00_Dep_Id'],
            "M01_Air_Program"=> $params['R00_Air_Program']
        );
        return $Course_Arr;
    }
    /**
     * オプションナルツーアデータ配列作成
     * @param varchar $staff_id
     * @return array|NULL
     */
    private function getOptTourDataArr($staff_id){
         // オプショナルツアー
        $optionals = $this->admin_edit_mo->getOptionalByUserId($staff_id);
        if ($optionals != null) {
            foreach ($optionals as $optional_key => $optional) {
                $tmp = $optional;
                for ($i = 0 ; $i <=8  ; $i++) {
                    $R04_Tour_ParticipationPlan = 'R04_Tour_ParticipationPlan' . $i;
                    if ($optional[$R04_Tour_ParticipationPlan] != 0) {
                        $participant = $this->admin_edit_mo->getParticipantOptionalsByPlanAndUserId($staff_id , $i);
                        if ($participant != null) {
                            $tmp['participantOptionals'][] = $participant;
                        }
                    }
                }
                $result[] = $tmp;
            }
        }else{
            $result = NULL;
        }
        return $result;
    }

    /**
     * 金額更新する
     * @param varchar $staff_id
     */
    private function CalTotalMoney($staff_id){

        $StaffInfo = $this->admin_edit_mo->getStaffInfo($staff_id);
        $CourseArr = $this->admin_edit_mo->getKakuteiCourseId($staff_id);
        $kakuteiInfo = $this->admin_edit_mo->getKakuteCourseById($CourseArr);
        $cost_travel = 0;
        $cost_room = 0;
        $participantInfo_arr = $this->admin_edit_mo->getUserInfo($staff_id);
        foreach ( $participantInfo_arr as $info_key => $participant ) {
            $old = floor((date('Ymd', strtotime($kakuteiInfo['M01_Dep_Date'])) - date('Ymd', strtotime($participant['R01_Birthday']))) / 10000);
            // 代表者
            if ($participant['R01_Plan'] == 0) {
                $cost_travel = $kakuteiInfo['M01_Cost_Me'];
            }
            // 大人
            if ($participant['R01_Plan'] != 0 && $old >= 12) {
                $cost_travel = $kakuteiInfo['M01_Cost_Adult1'];
            }
            // 海外:子供
            if (($kakuteiInfo['M01_Dest_Kbn'] == 1) && (2 <= $old) && ($old < 12)) {
                $cost_travel = $kakuteiInfo['M01_Cost_Child'];
            }
            // 国内:子供
            if (($kakuteiInfo['M01_Dest_Kbn'] == 2) && (3 <= $old) && ($old < 12)) {
                $cost_travel = $kakuteiInfo['M01_Cost_Child'];
            }
            // 海外:幼児
            if (($kakuteiInfo['M01_Dest_Kbn'] == 1) && (0 <= $old) && ($old < 2)) {
                $cost_travel = $kakuteiInfo['M01_Cost_Baby'];
            }
            // 国内:幼児
            if (($kakuteiInfo['M01_Dest_Kbn'] == 2) && (0 <= $old) && ($old < 3)) {
                $cost_travel = $kakuteiInfo['M01_Cost_Baby'];
            }
            $traVal['R01_Id'] = $participant['R01_Id'];
            $traVal['R01_Plan'] = $participant['R01_Plan'];
            $traVal['R01_Cost_Name3'] = "参加料金";
            $traVal['R01_Cost3'] = $cost_travel;
            $result = $this->menu_mo->CostTravelinfo($traVal);

        }
    }

    public function payment() {
        $data = array();
        $staffId = $this->input->post('user_id');
        $paymentData = $this->admin_edit_mo->getPaymentDataByStaffId($staffId);
        $participantInfo = $this->admin_edit_mo->getUserInfo($staffId);
        $optionals = $this->getOptTourDataArr($staffId);
        $totalFee = $this->getTotalFee($participantInfo, $optionals, $staffId);
        $data['payment'] = $paymentData;
        $data['totalFee'] = $totalFee;
        $data['staffId'] = $staffId;
        $this->load->view('admin_payment_vi', $data);
    }

    private function getTotalFee($participantInfo , $optionals, $staff_id) {
        // get sum_cost
        $sum_cost = 0;
        for($i = 2; $i <= 11; $i ++) {
            foreach ( $participantInfo as $key_no => $CostInfo ) {
				if($CostInfo['R01_Cancel_flag'] == 0){
					$R01_Cost_Name = 'R01_Cost_Name' . $i;
					$R01_Cost = 'R01_Cost' . $i;
					if ($CostInfo[$R01_Cost] != '0' || $CostInfo[$R01_Cost_Name] = "" || $CostInfo[$R01_Cost] != null) {
						$data_flag = true;
						$sum_cost += $CostInfo[$R01_Cost];
					}
				}
            }
        }
        // get sumEsta_cost
        $sumEsta_cost = 0;
        $cost = 0;
        foreach ( $participantInfo as $key_no => $CostInfo ) {
			if($CostInfo['R01_Cancel_flag'] == 0){
				if ($CostInfo['R01_Cost_Name1'] != '' || $CostInfo['R01_Cost_Name1'] != null) {
					$cost = $CostInfo['R01_Cost1'];
					$sumEsta_cost += $cost;
					$data_flag = true;
				}	
			}
        }
        // get optional_total
        $optional_total = 0;
        if (!empty($optionals)) {
            $data_flag = true;
            $optional_total = 0;
            foreach ( $optionals as $optional_key => $optional ) {
                if ($optional['R04_STS'] != '6' && $optional['R04_STS'] != '1') {
                    if ($optional['R04_STS'] == '7') {
                        $optional_total += $optional['R04_Cancel_Cost'];
                    } else {
                        $optional_total += $optional['R04_Tour_Jpy'];
                    }
                }
            }
        }
		//キャンセルコスト
		$cancel_total =0;
		foreach ( $participantInfo as $key_no => $CostInfo ) {
			if($CostInfo['R01_Cancel_flag'] == 1){
				$cancel_total += $CostInfo['R01_Cancel_Cost'];
			}
        }
		$BeforeArr['R09_ReserveId'] = $staff_id; 
		$BeforeArr['R09_Type'] = 1; 
		$AfterArr['R09_ReserveId'] = $staff_id;
		$AfterArr['R09_Type'] = 2;
		$BeforeTotal = $this->operating_mo->getHotelTotal($BeforeArr);
		$AfterTotal  = $this->operating_mo->getHotelTotal($AfterArr);		
        $total = $sum_cost + $sumEsta_cost + $optional_total +$BeforeTotal+$AfterTotal+$cancel_total;
        return $total;
    }

    public function updateNyukin() {
        $updateData = $this->input->post();
        $staffId = isset($updateData['staffId'])?$updateData['staffId']:'';
        if ($staffId != '') {
            // update data payment
            for ($i = 1 ; $i < 5 ; $i++) {
                if (isset($updateData['R13_Payment_Cost' . $i]) && $updateData['R13_Payment_Cost' . $i] == 0) continue;
                $param = array(
                        'R13_Id' => $staffId ,
                        'R13_Seq' => $i ,
                        'R13_Payment_Cost' => $updateData['R13_Payment_Cost' . $i] ,
                        'R13_Payment_Date' => $updateData['R13_Payment_Date' . $i] ,
                        'R13_Payment_Type' => $updateData['R13_Payment_Type' . $i] ,
                        'R13_Payment_Note' => $updateData['R13_Payment_Note' . $i]
                );
                if ($this->admin_edit_mo->isExistPaymentByStaffIdAndSeq($param['R13_Id'] , $param['R13_Seq'])) {
                    // update data
                    $this->admin_edit_mo->updatePaymentExist($param);
                } else {
                    // insert new data
                    $this->admin_edit_mo->insertPayment($param);
                }
            }
            //ポストデータ消えないようにデータを送る
            $data['redirect']['user_id'] = $staffId;
            $this->load->view('redirect_vi', $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }

    public function getOptionalPerson() {
        $data = array();
        $staffId = $this->input->post('staffId');
        $optionalCode = $this->input->post('optionalCode');
        $optionalSeq = $this->input->post('optionalSeq');
        $optionalDateKibou = $this->input->post('optionalDateKibou');
        $data['staffId'] = $staffId;
        $data['optionalCode'] = $optionalCode;
        $data['optionalSeq'] = $optionalSeq;
        $data['optionalDateKibou'] = $optionalDateKibou;
		 $data['participantInfo'] = $this->admin_edit_mo->getUserInfo($staffId);
        $data['tour'] = $this->optional_mo->getOptional_Code($optionalCode,$optionalSeq);
        $kakuteiInfo = $this->getKakuteiInfo($staffId);
        $data['kakuteiInfo'] = $this->getKakuteiInfo($staffId);
        $data['rate']=$this->optional_mo->getRateId($kakuteiInfo);
        $data['traveler']  = $this->optional_mo->getTravelerInfo($staffId);
        $CourseArr = $this->user_top_mo->getKakuteiCourseId($staffId);
        if ($CourseArr != null) {
            $data['CourseTodo'] = $this->optional_mo->getM02CourseTodo($CourseArr);
        } else {
            $data['CourseTodo'] = null;
        }
        $optional = $this->admin_edit_mo->optionalReserveByStaffIdAndOptionalCode($staffId , $optionalCode , $optionalSeq , $optionalDateKibou);

        $data['optional'] = $optional;
        $this->load->view('admin_optional_change_person', $data);
    }
    private function getKakuteiInfo($staffId) {
        $CourseArr = $this->user_top_mo->getKakuteiCourseId($staffId);
        $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
        return $data['kakuteiInfo'] ;
    }
    public function changeOptionalPersonNum() {
        $data = $this->input->post();
        if ($data != null) {
            $param1 = array(
                    'R04_Id'          => $data['R04_Id'] ,
                    'R04_Seq'         => $data['R04_Seq'] ,
                    'R04_Tour_Cost'   => $data['R04_Tour_Cost'] ,
                    'R04_Tour_Jpy'    => $data['R04_Tour_Jpy'] ,
                    'R04_Tour_Adult'  => $data['R04_Tour_Adult'] ,
                    'R04_Tour_Child1' => $data['R04_Tour_Child1'] ,
                    'R04_Tour_Child2' => $data['R04_Tour_Child2'] ,
					 'R04_Tour_Child3' => $data['R04_Tour_Child3'] ,
                    'R04_Tour_Infant' => $data['R04_Tour_Infant'] ,
                    'R04_Optional_Tour_Code' => $data['R04_Optional_Tour_Code'] ,
                    'R04_Optional_Kibou_Date' => $data['R04_Optional_Kibou_Date'] ,
                    'R04_Tour_Participation_Total' => $data['R04_Tour_Participation_Total']
            );
            $param2 = array(
                    'R04_Tour_ParticipationPlan0' => 0 ,
                    'R04_Tour_ParticipationPlan1' => 0 ,
                    'R04_Tour_ParticipationPlan2' => 0 ,
                    'R04_Tour_ParticipationPlan3' => 0 ,
                    'R04_Tour_ParticipationPlan4' => 0 ,
                    'R04_Tour_ParticipationPlan5' => 0 ,
                    'R04_Tour_ParticipationPlan6' => 0 ,
                    'R04_Tour_ParticipationPlan7' => 0 ,
                    'R04_Tour_ParticipationPlan8' => 0 ,
                    'R04_Tour_ParticipationPlan9' => 0 ,
            );
            if (isset($data['R04_Tour_ParticipationPlanList'])) {
                $participationList = $data['R04_Tour_ParticipationPlanList'];
                foreach ($participationList as $participation) {
                    if (array_key_exists($participation , $param2)) {
                        $param2[$participation] = 1;
                    }
                }
            }
            $param = array_merge($param1 , $param2);
            $this->admin_edit_mo->updateOptionalPersonNum($param);

            // move to Optional_edit
            $user_id = $data['R04_Id'];
            // 確定コースに情報を取得する
            $CourseArr = $this->admin_edit_mo->getKakuteiCourseId($user_id);
            $kakuteiInfo = $this->admin_edit_mo->getKakuteCourseById($CourseArr);
            $tmp['kakuteiInfo'] = $kakuteiInfo ;
            $tmp['optionals']   = $this->getOptTourDataArr($user_id);
            $tmp['M10_Masters'] = $this->optional_mo->getAllStatus();
            $this->load->view('admin_optional_edit_vi',$tmp);
        }
    }
	
	 /*
    *ホテル共有
    *
    */
    public function hotel_common($type){
        //$type 1:前泊　2:後泊   
		$admin_id     = $this->session->userdata('admin_id_session');
		if ($admin_id == '' || $admin_id == null) {
            redirect(base_url("admin_con"));
            return;
        } else {
           if(isset($_POST['user_id'])){
            $staff_id  = $this->input->post('user_id');
			
			//セクションユーザID　と　全員のデータを取得
            $data['traveler']  = $this->user_top_mo->getUserInfo($staff_id);
		
            $data['course_master']  = $this->getM01_CourseFunc($staff_id);
            //R09_Hotel_Reserve
            $data['Hotel_Reserve'] = $this->hotel_mo->getR09_Hotel_Reserve($staff_id, $type);		
            return $data;
			
			}else{
				redirect('menu_con/detail_participant');
				return;
			} 
        }
		     
        /**/
    }
	 /*
    *ホテル情報更新
    *
    */
    public function upd_hotel_common($params, $type){
        //セクションからユーザID　取得
        $R00_Id = $this->input->post('user_id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('menu_con/detail_participant'));
            return;
        } else {
            $Hotel_Reserve = $params['Hotel_Reserve'];
            //R09_Hotel_Reserve保存
            foreach($Hotel_Reserve as $HotelKey=>$HotelVal){
				
                $HotelVal['R09_ReserveId'] = $R00_Id;
                $HotelVal['R09_Type'] =  $type;				
                //if(($HotelVal['R09_Hote_Room_Type'] != '') &&($HotelVal['R09_Type'] != '')){
                    $this->hotel_mo->insertHotel_Reserve($HotelVal);
                //}
                $data['Hotel_travel'] = $this->hotel_mo->getHotelDataInTraveler($HotelVal);                
                if($data['Hotel_travel'] == NULL){
                    $this->hotel_mo->delHotelHotel_Reserve($HotelVal);
                }
            }					
        }
    }
}
