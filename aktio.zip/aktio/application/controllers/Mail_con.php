﻿<?php defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Mail_con extends CI_Controller {

    public function Mail_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('validation');
        $this->load->library('email');
		$this->load->library('convert_format');
        $this->load->model('menu_mo');
        $this->load->model('common_mo');
        $this->load->model("login_mo");
        $this->load->model("entry_mo");
        $this->load->model("user_top_mo");
		$this->load->model("mail_mo");
    }

    /**
    * メール作成する
    */
    public function index() {
        // Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        $data['results'] = NULL;
        if (isset($admin_id)) {
            $data['title'] 		 = '管理画面メールテンプレート作成';
            $param = array(
                'Course'   => $this->input->post('Course'),
                'R00_Id'   => $this->input->post('R00_Id')
            );
			
            if(isset($_POST['subject'])){
                $param['subject'] = $_POST['subject'];
            }else{
                $param['subject'] = '';
            }
            if(isset($_POST['email_head'])){
                $param['email_head'] = $_POST['email_head'];
            }else{
                $param['email_head'] = '';
            }
            if(isset($_POST['email_body'])){
                $param['email_body'] = $_POST['email_body'];
            }else{
                $param['email_body'] = '';
            }
            if(isset($_POST['email_foot'])){
                $param['email_foot'] = $_POST['email_foot'];
            }else{
                $param['email_foot'] = '';
            }
			 if(isset($_POST['bcc_mail'])){
                $param['bcc_mail'] = $_POST['bcc_mail'];
            }else{
                $param['bcc_mail'] = '';
            }
            $CourseData =  $this->menu_mo->getM01Course($_POST['Course']);
            //データの格納
            $data['CourseData'] = $CourseData[0];
			
            $data['param']	    = $param;
            $data['title'] = '管理画面メールテンプレート作成';
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('mail/mail_template_vi' , $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }

    /*
    *
    * create mail template
    */
    public function previewMailTemp(){
        // Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        $data['results'] = NULL;      
        //後で確認
        if (isset($admin_id)) {
            $param = array(
                'Course'     => $this->input->post('Course'),
                'R00_Id'     => $this->input->post('R00_Id'),
                'sender'     => $this->input->post('sender'),
                'subject'    => $this->input->post('subject'),
                'email_head' => $this->input->post('email_head'),
                'email_body' => $this->input->post('email_body'),
                'email_foot' => $this->input->post('email_foot'),
				'bcc_mail'	 => $this->input->post('bcc_mail')
            );			
			$CourseData  		= $this->getCourseData($param['Course']);			
            $data['sender']		= $this->change_text($param['sender'],$param['R00_Id'][0],$CourseData);
            $data['subject']	= $this->change_text($param['subject'],$param['R00_Id'][0],$CourseData);
            $data['email_head'] = $this->change_text($param['email_head'],$param['R00_Id'][0],$CourseData);
            $data['email_body'] = $this->change_text($param['email_body'],$param['R00_Id'][0],$CourseData);
            $data['email_foot'] = $this->change_text($param['email_foot'],$param['R00_Id'][0],$CourseData);
            $data['title']		= '管理画面メールプレビュー';
            //$CourseData =  $this->menu_mo->getIdCourseData($param['R00_Course_Id'], $param['R00_Han']);
            $R00_Reserve = $this->user_top_mo->getStaffInfo($param['R00_Id'][0]);
            $data['R00_Mailaddress'] = $R00_Reserve['R00_Mailaddress'];
            $data['CourseData'] = $CourseData;			
            $data['param']		= $param;
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('mail/preview_mail_tmp_vi' , $data);
        }else{
            redirect(base_url("admin_con"));
        }
    }

    /*
    * メールの内容を置き換え
    *
    */
    public function change_text($email_data,$R00_Id,$CourseData){
        $email_data_result=array();
        $row_data = $this->mail_mo->getUserDataForMail($R00_Id);		
        $email_data_replace = array(
                '#customer_id#',
                '#customer_name_kanji#',
                '#customer_name_kana#',
				'#customer_name_eng#',
                '#customer_mail#',
                '#customer_kakutei#',
				'#kiten#',
				'#departure_date#',
				'#companion_name#',
				'#companion_name_kana#',
				'#companion_name_eng#'                
        );
        //要らないデータを除く
        $email_data_replacement=array();
        $email_data_replacement[] = $row_data['R00_Id'];
        $email_data_replacement[] = $row_data['R00_Sei'].' '.$row_data['R00_Name'];
        $email_data_replacement[] = $row_data['R00_Sei_Kana'].' '.$row_data['R00_Name_Kana'];
		$email_data_replacement[] = $row_data['R01_Sei_Eng'].' '.$row_data['R01_Name_Eng'];
        $email_data_replacement[] = $row_data['R00_Mailaddress'];
        $email_data_replacement[] = $CourseData['M01_Course_Name'];
		$email_data_replacement[] = $row_data['R01_Kiten'];
		$email_data_replacement[] = $this->convert_format->ChangeJpDay($CourseData['M01_Dep_Date']);
		$email_data_replacement[] = $this->getCompanionName($row_data['R00_Id'], 'R01_Sei', 'R01_Name');
		$email_data_replacement[] = $this->getCompanionName($row_data['R00_Id'], 'R01_Sei_Kana', 'R01_Name_Kana');
		$email_data_replacement[] = $this->getCompanionName($row_data['R00_Id'], 'R01_Sei_Eng', 'R01_Name_Eng');		
        $new_email_data= str_replace($email_data_replace,$email_data_replacement,$email_data);
        return $new_email_data;
    }
   

    /*
    *
    *メール送信
    */
    public function sendMail(){
        // Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_id)) {			
            $param = array(    
				'Course'     => $this->input->post('Course'),
                'R00_Id'     => $this->input->post('R00_Id'),
                'sender'     => $this->input->post('sender'),
                'subject'    => $this->input->post('subject'),
                'email_head' => $this->input->post('email_head'),
                'email_body' => $this->input->post('email_body'),
                'email_foot' => $this->input->post('email_foot'),
				'bcc_mail'	 => $this->input->post('bcc_mail')
            );
			$CourseDataArr = $this->menu_mo->getM01Course($param['Course']);
			$CourseData = $CourseDataArr[0];			
            $result['CourseData'] = $CourseData;
            $i = 0;
            foreach($param['R00_Id'] as $R00_Id){
                    $data['sender']	    = $this->change_text($param['sender'], $R00_Id, $CourseData);
                    $data['subject']    = $this->change_text($param['subject'], $R00_Id, $CourseData);
                    $data['email_head'] = $this->change_text($param['email_head'], $R00_Id, $CourseData);
                    $data['email_body'] = $this->change_text($param['email_body'], $R00_Id, $CourseData);
                    $data['email_foot'] = $this->change_text($param['email_foot'], $R00_Id, $CourseData);
					$results = $this->mail_mo->getUserDataForMail($R00_Id);                  
                    $mail_addr = $results['R00_Mailaddress'];
                    //メール送信
                    date_default_timezone_set('Asia/Tokyo');
                    mb_language("Japanese");
                    mb_internal_encoding("utf8");
                    $this->email->from($data['sender'], mb_encode_mimeheader('AKTIO'));
                    //$this->email->to('dothu.huong@nisshin-sys.co.jp');
                    //$this->email->to('htet.thu@nisshin-sys.co.jp');
                    $this->email->to($mail_addr);
					if($param['bcc_mail']!=''){
						//$this->email->bcc('test@nssproduct.com');
						$this->email->bcc($param['bcc_mail']);
					}
                    $this->email->subject($data['subject']);
                    $body = "";
                    $body .= $data['email_head'];
                    $body .= "\r\n";
                    $body .= "\r\n";
                    $body .= $data['email_body'];
                    $body .= "\r\n";
                    $body .= "\r\n";
                    $body .= $data['email_foot'];
                    $this->email->message($body);
                    $result['mail_status'][$i]['R00_Id']	  = $R00_Id;
					$mail_log = array(
						'L00_Id'=> $R00_Id,
						'L00_Mail_Subject'=> $data['subject'],
						'L00_Mail_Head'=> $data['email_head'],
						'L00_Mail_Body'=> $data['email_body'],
						'L00_Mail_Footer'=> $data['email_foot'],
						'L00_Mail_Address'=> $mail_addr,
						'L00_Bcc_Mail_Address'=> $param['bcc_mail'],
						'L00_Status'=>''
					);
                    if($this->email->send()){
						$mail_log['L00_Status']= '完了';
                        $result['mail_status'][$i]['status'] = 1;
                    }else{
						$mail_log['L00_Status']= '失敗';
                        $result['mail_status'][$i]['status'] = 0;
                    }
					$this->mail_mo->setMailLog($mail_log);
                    $i++;
                }

                $result['title']		= '管理画面メール送信';
                $this->load->view('header_admin_vi' , $result);
                $this->load->view('mail/send_mail_complete_vi' , $result);
        }else{
            redirect(base_url("admin_con"));
        }
    }
	/*
	*
	*
	*/
	public function getCourseData($CourseTmp){
		$Course = array(
				'M01_Dest_Kbn'=>$CourseTmp['R00_Dest_Kbn'],
				'M01_Dest_Code'=>$CourseTmp['R00_Dest_Code'],
				'M01_Han'=>$CourseTmp['R00_Han'],
				'M01_Dep_Id'=>$CourseTmp['R00_Dep_Id'],
				'M01_Air_Program'=>$CourseTmp['R00_Air_Program']
			);			
		$CourseData = $this->menu_mo->getM01Course($Course);
		return $CourseData[0];
	}
	/*
	*　同行者 名前取得
	*
	*/
	public function getCompanionName($R00_Id, $field_1, $field_2){
		$rows = $this->mail_mo->getCompanionData($R00_Id);
		$result = NULL;
		if(count($rows)>0){
			foreach($rows as $row){
				$result .= $row[$field_1].' '.$row[$field_2].'、';
			}
			$result = rtrim($result,'、');
		}	
		return $result;
	}
}
