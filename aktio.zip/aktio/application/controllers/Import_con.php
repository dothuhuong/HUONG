﻿<?php defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Import_con extends CI_Controller {

    public function Import_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('validation');
        $this->load->model('menu_mo');
        $this->load->model('notice_mo');
    }

    /**
    * メニュー作成するメソッド
    */
    public function index() {
        // Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        $data['msg']  = NULL;
        if (isset($admin_id)) {
            
//             echo '<pre>';
//             print_r($this->input->post());
//             echo $this->input->post('Course');
//             exit();
            /*
            $param = array(
                'R00_Course_Id'  => $this->input->post('R00_Course_Id'),
                'R00_Han'        => $this->input->post('R00_Han')
            );
            */
            //$CourseData =  $this->menu_mo->getIdCourseData($param['R00_Course_Id'], $param['R00_Han']);
            //$data['CourseData'] = $CourseData[0];
            $data['title'] = "管理画面インポート";
            /*
            if (isset($_POST["importData"])) {
                $filename=$_FILES["file"]["tmp_name"];
                $filename_ext = stripslashes($_FILES["file"]["name"]);
                $extension = $this->getExtension($filename_ext);
                $extension = strtolower($extension);
                if ($_FILES["file"]["size"] > 0) {
                    if (($extension != "csv")){
                        $data['msg'] = "＊(ERR)アップロードファイルはCSVでご用意ください。" ;
                    } else {
                        $file = fopen($filename, "r");
                        while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE) {
                            $importdata_param[] = array(
                                'name' => $importdata[0],
                                'email' =>$importdata[1]
                            );
                        }
                        fclose($file);
                        $data['msg'] = "＊アップロド完了。";
                    }
                }else{
                    $data['msg'] = '＊アップロードファイルを選んでください。';
                }
            }
            */
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('element/import_export_common_vi' , $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }

    /*
    *
    * csv　インポート
    */
    public function importData(){
         // Get admin session
        $admin_Id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');

        if (isset($admin_Id)) { // Check admin session
            $param = array(
                'R00_Course_Id'  => $this->input->post('R00_Course_Id'),
                'R00_Han'        => $this->input->post('R00_Han')
            );
            $CourseData =  $this->menu_mo->getIdCourseData($param['R00_Course_Id'], $param['R00_Han']);
            $data['CourseData'] = $CourseData[0];
            $data['title'] = "管理画面インポート";
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('import/import_vi', $data);

        } else {
            redirect(base_url('admin_con'));
        }
    }
    public function getExtension($str) {
        $i = strrpos($str,".");
        if (!$i) { return ""; }
        $l = strlen($str) - $i;
        $ext = substr($str,$i+1,$l);
        return $ext;
        }
}
