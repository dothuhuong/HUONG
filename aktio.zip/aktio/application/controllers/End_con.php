<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL ^ E_WARNING);
class End_con extends CI_Controller {

    function End_con() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('end_mo');
        $this->load->model('user_top_mo');
    }
    function index(){
        $R00_Id = $this->session->userdata('R00_Id');
        if($R00_Id == '' || $R00_Id ==NULL) {
            $this->load->view('login_vi');
            return;
        } else {
            //希望コースをセクションから取得
            $kibou_course = $this->session->userdata('kibouCourse');
            $this->end_mo->setKibou($R00_Id,$kibou_course);
            //緊急連絡データをセクションから取得
            $emerencyData = $this->session->userdata('entryData');
            $this->end_mo->setEmerData($R00_Id,$emerencyData);
            //参加者データ取得セクションから
            $UpdData = $this->session->userdata('UpdData');
            unset($UpdData['R00_emargency_mei'],$UpdData['R00_emargency_zoku'],$UpdData['R00_emargency_tel'],$UpdData['R00_Customer_Note']);
            //var_dump($UpdData);
            foreach ($UpdData as $row){
                $this->end_mo->setUpdData($R00_Id,$row);
            }
            $this->end_mo->setParicipate($R00_Id,$UpdData);
            $data['user_info'] = $this->user_top_mo->getStaffInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('end_vi',$data);
            $this->load->view('footer_vi');
            return;
        }
    }
}
