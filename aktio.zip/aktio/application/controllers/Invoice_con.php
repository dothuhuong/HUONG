<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Invoice_con extends CI_Controller {
    public function Invoice_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config'); 
		$this->load->model('invoice_mo');
		$this->load->model('operating_mo');
		$this->load->library('ExcelInvoice');
        date_default_timezone_set('Asia/Tokyo');
    }
    public function index() {
		//セクションの確認
		$admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
		if (isset($admin_id)) {
			$Course = $this->input->post('Course');
			$param = array(
                "M01_Dest_Kbn" => $Course['R00_Dest_Kbn'],
                "M01_Dest_Code" =>  $Course['R00_Dest_Code'],
                "M01_Han" => $Course['R00_Han'],
                "M01_Dep_Id" => $Course['R00_Dep_Id'],
                "M01_Air_Program" => $Course['R00_Air_Program']
            );
			$CourseDataMaster = $this->operating_mo->getCourseDataByParam($Course);
			
			$InvoiceArr = $this->invoice_mo->getInvoiceData($Course);
			/*echo '<pre>';
			print_r($InvoiceArr);
			echo '</pre>';
			exit;*/
			$this->excelinvoice->getExcelInvoice($InvoiceArr, $CourseDataMaster);			
		
		}else{
			redirect(base_url("admin_con"));
		}
    }
	
	
}
