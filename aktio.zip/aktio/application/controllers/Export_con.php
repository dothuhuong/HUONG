﻿<?php defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Export_con extends CI_Controller {

    public function Export_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('validation');
        $this->load->model('menu_mo');
        $this->load->model('notice_mo');
    }

    /**
    * メニュー作成するメソッド
    */
    public function index() {
        // Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        $data['results'] = NULL;
        if (isset($admin_id)) {
            foreach($_POST as $key => $val){
                $param[$key] = $val;
            }
            $data['results'] = $this->menu_mo->SearchReservation($param);
            if(count($data['results'])>0){
                $i = 0;
                foreach($data['results'] as $row){
                    $data['results'][$i]['doko'] = $this->menu_mo->getCountDokoshaById($row['R00_Id']);
                    $i++;
                }
            }
            $this->csvOutput($data['results']);
            /*
            echo '<pre>';
            print_r($data['results']);
            echo '</pre>';
            exit;
            */
            /*
            $param = array(
                'R00_Course_Id'  => $this->input->post('R00_Course_Id'),
                'R00_Han'        => $this->input->post('R00_Han')
            );
            $CourseData =  $this->menu_mo->getIdCourseData($param['R00_Course_Id'], $param['R00_Han']);

            $data['CourseData'] = $CourseData[0];
            $data['title'] = "管理画面エクスポート";
            $this->load->view('header_admin_vi' , $data);
            $this->load->view('export/export_vi', $data);
            */
        } else {
            redirect(base_url("admin_con"));
        }
    }

    /*
    *
    */
    /*
    *	CSV 出力処理
    *
    */
    public function csvOutput($data){
        date_default_timezone_set('Asia/Tokyo');
        // ヘッダ文字列
        $headers = array(
        "予約番号",
        "名前（漢字）",
        "名前（カナ）",
        "名前（英語）",
        "所属部門細目",
        "所属部門",
        "役職",
        "会社電話番号",
        "会社Fax番号",
        "会社内線",
        "会社住所",
        "パスポート提出",
        "パスポートチェック",
        "確定コース",
        "確定班",
        "【緊急連絡先】氏名",
        "【緊急連絡先】続柄",
        "【緊急連絡先】電話番号",
        "加者ログイン",
        "確定ルーム番号２",
        "確定ルーム番号３",
        "管理者備考",
        "参加者備考",
        "不参加備考",
        "集合場所",
        "解散場所",
        "集合空港1",
        "利用ホテル",
        "集合空港2",
        "参加者初回ログイン日付",
        "参加者最終ログイン日付",
        "会社名",
        "入社年月日",
        "メールアドレス",
        "パスワード",
        "参加者番号",
        "部屋番号",
        "旅行代金全額（オプショナル除く）",
        "キャンセル代金全額",
        "旅行代金備考",
        "旅行代金オプショナル全額",
        "オプショナル代金支払いリンク1",
        "オプショナル代金支払いリンク1への説明文言",
        "オプショナル代金支払いリンク2",
        "オプショナル代金支払いリンク2への説明文言",
        "オプショナル代金支払いリンク3",
        "オプショナル代金支払いリンク3への説明文言"
        );
        //ファイル名作成
        $fileName = mb_convert_encoding("AKTIO_RESERVE_" . date('Ymd_His') . ".csv", "SJIS" ,"UTF-8");
        // output headers so that the file is downloaded rather than displayed
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename='.$fileName);

        // create a file pointer connected to the output stream
        $output = fopen('php://output', 'w');

        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        // output the column headings
        fputcsv($output, $headers);
        $csvdata = array();
        foreach($data as $csvData){
            $csvdata['reserveNo'] = $csvData['R00_Id'];
            $csvdata['name_kanji']	  = $csvData['R00_Sei'].'　'.$csvData['R00_Name'];
            fputcsv($output, $csvdata);
        }

        fclose($output);
    }
}
