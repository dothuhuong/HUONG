<?php defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Rate_con extends CI_Controller {

    public function Rate_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('rate_mo');
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // メニュー画面
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * メニュー作成するメソッド
     */
    public function index() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');

        if (isset($admin_id)) {
            $data = array();
            $data['title'] = "レート管理画面";
            $data['Charger_Type'] = $charger_type;

            $rates = $this->rate_mo->getAllRate();
            if ($rates != NULL) {
                $data['rates'] = $rates;
            } else {
                $data['rates'] = NULL;
            }

            $rate_count = $this->rate_mo->getCountRate();
            if ($rate_count != NULL) {
                $data['rate_count'] = $rate_count;
            } else {
                $data['rate_count'] = NULL;
            }

            $this->load->view('header_admin_vi' , $data);
            $this->load->view('admin_rate_vi' , $data);
            $this->load->view('footer_vi');
        } else {
            redirect(base_url("admin_con"));
        }
    }

    public function update_rate() {
        $rateInfo = array();
        $rateInfo['M11_Id'] = !isset($_POST['M11_Id'])?"":$_POST['M11_Id'];
        $rateInfo['M11_start_date'] = !isset($_POST['M11_start_date'])?"":$_POST['M11_start_date'];
        $rateInfo['M11_rate'] = !isset($_POST['M11_rate'])?"":$_POST['M11_rate'];
        $rateInfo['M11_unitprice'] = !isset($_POST['M11_unitprice'])?"":$_POST['M11_unitprice'];

        $aff_row = $this->rate_mo->updateRate($rateInfo);

        if($aff_row != -1){
            echo json_encode("success");
        } else {
            echo json_encode("error");
        }
    }
    public function insert_rate() {
        $rateInfo = array();

        $rateInfo['M11_start_date'] = !isset($_POST['M11_start_date'])?"":$_POST['M11_start_date'];
        $rateInfo['M11_rate'] = !isset($_POST['M11_rate'])?"":$_POST['M11_rate'];
        $rateInfo['M11_unitprice'] = !isset($_POST['M11_unitprice'])?"":$_POST['M11_unitprice'];

        $aff_row = $this->rate_mo->insertRate($rateInfo);

        if($aff_row != -1){
            echo json_encode("success");
        } else {
            echo json_encode("error");
        }
    }
}
