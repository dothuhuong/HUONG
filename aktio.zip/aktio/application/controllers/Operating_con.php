<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Operating_con extends CI_Controller
{
    public function Operating_con() {
        parent::__construct();
        $this->load->helper('url');
        // ライブラリをロードする
        $this->load->library('session');
        $this->load->library('validation');
		$this->load->library('convert_format');

        // エクセルライブラリをロードする
        $this->load->library('ExcelTransport');
        $this->load->library('ExcelOptional');
        $this->load->library('ExcelSecretary');
        $this->load->library('ExcelRooming');                //20170406 catnhp add

        // モデルをロードする
        $this->load->model('operating_mo');
        $this->load->model('total_mo');
        $this->load->model('menu_mo');
        $this->load->model('notice_mo');
        $this->load->model('common_mo');
        $this->load->model('admin_edit_mo');
    }
    public function index() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (! empty($admin_id)) {
            $updateStatus = 0;
            $course = $this->input->post('Course');
            if (isset($course) && $course != null ) {
                $this->session->set_userdata('Course', $course);
            } else {
                if ($this->session->userdata('Course') != null) {
                    $course = $this->session->userdata('Course');
                } else {
                    // セッションチェック
                    redirect(base_url("menu_con"));
                }
            }

            if (isset($_POST['senyouFile'])) {
                $course = $this->session->userdata('Course');
                if ($course == null) {
                    redirect(base_url('menu_con'));
                } else {
                    $this->downloadSecretaryFileByCourse($course);
                }
            }
            
            //20170412 catnhp ADD_S add new button exportOrderByRoom
            if (isset($_POST['senyouFileOrderByRoom'])) {
            	$course = $this->session->userdata('Course');
            	if ($course == null) {
            		redirect(base_url('menu_con'));
            	} else {
            		$this->downloadSecretaryFileOrderByRoom($course);
            	}
            }
            //20170412 catnhp ADD_E add new button exportOrderByRoom

            //20170406 catnhp ADD_S
            // CSV　ルームデータファイルを読み込み処理
            $error_arr = array();
            if (isset($_POST['btnImportRooming'])) {
                if ($_FILES['fileImportRooming']['size'] > 0) {
                    setlocale(LC_ALL, 'ja_JP.UTF-8');
                    date_default_timezone_set('Asia/Tokyo');
                    // CSV 読み込み 処理
                    $excelFile = $_FILES["fileImportRooming"]["tmp_name"];
                    $error_arr = $this->excelrooming->readExcelData($excelFile);
                    $updateStatus = 1;
                }
            }
            //20170406 catnhp ADD_E

            if (isset($_POST['btnImportTransport'])) {
                if ($_FILES['fileImportTransport']['size'] > 0) {
                    setlocale(LC_ALL, 'ja_JP.UTF-8');
                    date_default_timezone_set('Asia/Tokyo');
                    // CSV 読み込み 処理
                    $excelFile = $_FILES["fileImportTransport"]["tmp_name"];
                    $this->exceltransport->readExcelData($excelFile);
                    $updateStatus = 1;
                }
            }

            if (isset($_POST['btnImportOptional'])) {
                if ($_FILES['fileImportOptional']['size'] > 0) {
                    setlocale(LC_ALL, 'ja_JP.UTF-8');
                    date_default_timezone_set('Asia/Tokyo');
                    // CSV 読み込み 処理
                    $excelFile = $_FILES["fileImportOptional"]["tmp_name"];
                    $this->exceloptional->readExcelData($excelFile);
                    $updateStatus = 1;
                }
            }
            $data['error_arr'] = $error_arr;

            $charger_entitle = $this->total_mo->getChargerEntitle($admin_id, $charger_type);
            $data['charger_type'] = $charger_type;
            $data['charger_entitle'] = $charger_entitle;

            $CourseData = $this->operating_mo->getCourseDataByParam($course);

            $data['CourseData'] = $CourseData;
            $data['course'] = $course;
            if ($charger_type == 0) {
                $data['title'] = 'インポート・エクスポート管理画面';
            } else {
                $data['title'] = 'エクスポート管理画面';
            }

            $data['update_status'] = $updateStatus;

            $this->load->view('header_admin_vi', $data);
            $this->load->view('element/import_export_common_vi', $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }
    private function isSessionCourseExist() {
        $course = $this->session->userdata('Course');
        if ($course == null) {
            return false;
        }
        return true;
    }
    private function load_course() {
        // コースのセッションデータを取得する
        if ($this->isSessionCourseExist()) {
            $course = $this->session->userdata('Course');
        } else {
            redirect(base_url('menu_con'));
        }
        $course = $this->session->userdata('Course');
        $CourseData = $this->operating_mo->getCourseDataByParam($course);	
        return $CourseData;
    }
    private function initInfoTitleByInfoType($infoType) {
        $infoTitleLbl = array (
                '0' => '参加者基本情報',
                '1' => '同行者・パスポート情報',
                '2' => 'オプショナル申し込み情報',
                '3' => 'フライト情報',
                '4' => '国内交通情報',
                '5' => '国内宿泊情報',
                '6' => '送付先リスト',
                '7' => 'ネームリスト'
        );

        $title = array_key_exists($infoType, $infoTitleLbl) ? $infoTitleLbl[$infoType] : '';
        return $title;
    }
    private function load_base_page($operatingType, $infoType, $data) {
        if ($operatingType == '' || $infoType == '') {
            redirect(base_url('menu_con'));
        }

        // 初期化
        $infoFileName = array (
                '0' => 'export_participant_info_vi',
                '1' => 'export_passport_info_vi',
                '2' => 'export_optional_info_vi',
                '3' => 'export_flight_info_vi',
                '4' => 'export_traffic_info_vi',
                '5' => 'export_stay_info_vi',
                '6' => 'export_destination_info_vi',
                '7' => 'export_name_list_vi'
        );

        // コースのセッションデータを取得する
        $CourseData = $this->load_course();
        $data['CourseData'] = $CourseData;

        // Lay ra thong tin cua cong ty , cua cac bo phan tuy theo so nguoi tham gia course
        $course = $this->session->userdata('Course');
        $companies = $this->operating_mo->getCompanyByCourseInfo($course);
        $data['companies'] = $companies;

        $divisons = $this->operating_mo->getDivisonByCourseInfo($course);
        $data['divisons'] = $divisons;

        // data push to view
        $title = $this->initInfoTitleByInfoType($infoType);
        $data['title'] = $title;
        $data['operating_type'] = $operatingType;
        $data['info_type'] = $infoType;

        //M10_STS取得
        if($infoType==2){
            $data['M10_STS'] = $this->common_mo->getStatus();
            $data['M10_Pay'] = $this->common_mo->getPay();
        }
        // 画面確認と移動
        if ($operatingType == 0) { // import
            $data['title_head'] = 'インポート管理画面 ';
            $data['msg'] = 'エクスポートしたのファイルで (★)がある項目なら、修正可能性があります。修正した後、インポートできます。他の項目が修正できないです。';
            $this->load->view('header_admin_vi', $data);
            $this->load->view('import/import_vi', $data);
        } else { // export
            $data['title_head'] = 'エクスポート管理画面 ';
            $this->load->view('header_admin_vi', $data);
            $this->load->view('export/' . $infoFileName[$infoType], $data);
        }
    }
    public function selectType() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (! empty($admin_id)) {
            // 初期化
            $data = array ();
            // リクエストデーターを取得する (request data)
            $operatingType = $this->input->post('operating_type');
            $infoType = $this->input->post('info_type');
            $this->load_base_page($operatingType, $infoType, $data);
        } else {
            redirect(base_url('admin_con'));
        }
    }
    private function getSearchKey() {
        $infoType = $this->input->post('info_type');
        $searchKey = array (
                'R00_Id_Start' => $this->input->post('R00_Id_Start'),
                'R00_Id_End' => $this->input->post('R00_Id_End'),
                'R00_Sei' => $this->input->post('R00_Sei'),
                'R00_Name' => $this->input->post('R00_Name'),
                'R00_Sei_Kana' => $this->input->post('R00_Sei_Kana'),
                'R00_Name_Kana' => $this->input->post('R00_Name_Kana'),
                'R00_Mailaddress' => $this->input->post('R00_Mailaddress'),
                'R00_Company' => $this->input->post('R00_Company'),
                'R00_Division' => $this->input->post('R00_Division'),
                'R01_Cancel_flag' => $this->input->post('R01_Cancel_flag'),
                'R01_Passpost_Upload_Flag' => $this->input->post('R00_Passpost_Upload_Flag'),
                'R04_Optional_Tour_Code' => $this->input->post('R04_Optional_Tour_Code'),
                'R04_STS' => $this->input->post('R04_STS'),
                'R00_Pay_Date' => $this->input->post('R00_Pay_Date'),
                'R00_Pay_Code_J' => $this->input->post('R00_Pay_Code_J')
        );
        return $searchKey;
    }
    private function getSearchResult($infoType, $searchKey, $course) {
        $searchResult = array ();
        switch ($infoType) {
            case 0 :
                $searchResult = $this->operating_mo->getSearchParticipantResult($infoType, $searchKey, $course);
                break;
            case 1 :
                $searchResult = $this->operating_mo->getSearchPassportResult($infoType, $searchKey, $course);
                break;
            case 2 :
                $searchResult = $this->operating_mo->getSearchOptionalResult($infoType, $searchKey, $course);
                break;
            case 3 :
                $searchResult = $this->operating_mo->getSearchFlightResult($infoType, $searchKey, $course);
                break;
            case 4 :
                $searchResult = $this->operating_mo->getSearchTrafficResult($infoType, $searchKey, $course);
                break;
            case 5 :
                $searchResult = $this->operating_mo->getSearchStayResult($infoType, $searchKey, $course);
                break;
            case 6 :
                $searchResult = $this->operating_mo->getSearchDestinationResult($infoType, $searchKey, $course);
                break;
            case 7 :
                $searchResult = $this->operating_mo->getSearchNameListResult($infoType, $searchKey, $course);
                break;
            default :
                $searchResult = null;
        }	
        return $searchResult;
    }

    /**
     * 参加者基本情報
     */
    public function search_info() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');

        if (! empty($admin_id)) {
            // 初期化
            $data = array ();
            // リクエストデーターを取得する
            $operatingType = $this->input->post('operating_type');
            $infoType = $this->input->post('info_type');
            if ($operatingType == '' || $infoType == '') {
                redirect(base_url('menu_con'));
            }

            // 検索の件
            $searchKey = $this->getSearchKey();
            $data['searchKey'] = $searchKey;

            // get search result
            $course = $this->session->userdata('Course');
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);
            //オプションナルツーアの入金文字変更
            if($infoType ==2){
                if(count($searchResult)>0){
                    $searchResult = $this->getOptionParticipate($searchResult);
                }
            }
            $data['searchResult'] = $searchResult;

            // load page
            $this->load_base_page($operatingType, $infoType, $data);

            if (isset($_POST['downloadcsv'])) {
                $this->download_csv($infoType);
                exit();
            }
        } else {
            redirect(base_url('admin_con'));
        }
    }

    /*
    *
    */
    private function getOptionParticipate($searchResult){
        $tmp_arr = array();
        if(count($searchResult)>0){
            foreach($searchResult as $result){
                if(($result['R04_Tour_ParticipationPlan0'] ==1) && ($result['R01_Plan'] ==0)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan1'] ==1) && ($result['R01_Plan'] ==1)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan2'] ==1) && ($result['R01_Plan'] ==2)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan3'] ==1) && ($result['R01_Plan'] ==3)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan4'] ==1) && ($result['R01_Plan'] ==4)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan5'] ==1) && ($result['R01_Plan'] ==5)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan6'] ==1) && ($result['R01_Plan'] ==6)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan7'] ==1) && ($result['R01_Plan'] ==7)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan8'] ==1) && ($result['R01_Plan'] ==8)){
                    $tmp_arr[] = $result;
                }
                if(($result['R04_Tour_ParticipationPlan9'] ==1) && ($result['R01_Plan'] ==9)){
                    $tmp_arr[] = $result;
                }
            }
        }
        //支払済、未支払い計算
		if(count($tmp_arr)>0){
			 foreach($tmp_arr as $key => $val){
				$tmp_arr[$key]['payment'] = $this->getTotalPayment($val['R01_Id']);
				$tmp_arr[$key]['Fee'] = $this->getTotalFee($val);
				$balance = $tmp_arr[$key]['Fee']- $tmp_arr[$key]['payment'];
				if($balance<0 AND $val['R04_STS'] == 2){
				//if($balance<0){
					$tmp_arr[$key]['payment_sts'] = '入金済み';
				}else{
					$tmp_arr[$key]['payment_sts'] = '未入金';
				}
			}
		}		
        return $tmp_arr;

    }
    private function download_csv($infoType) {
        switch ($infoType) {
            case 0 :
                $this->download_csv_participant($infoType);
                break;
            case 1 :
                $this->download_csv_passport($infoType);
                break;
            case 2 :
                $this->download_csv_optional($infoType);
                break;
            case 3 :
                $this->download_csv_flight($infoType);
                break;
            case 4 :
                $this->download_csv_traffic($infoType);
                break;
            case 5 :
                $this->download_csv_stay($infoType);
                break;
            case 6 :
                $this->download_csv_destination($infoType);
                break;
            case 7 :
                $this->download_csv_namelist($infoType);
                break;
            default :
                break;
        }
    }
    private function init_header($infoType) {
        $headers = array ();
        if ($infoType == 0) {
            // 参加者基本情報
			$headers = array(
				"社員番号",
				"姓（漢字）",
				"名（漢字）",
				"姓（カナ）",
				"名（カナ）",
				"書類送付先名称",
				"★会社名",
				"★所属部門",
				"★会社電話番号",
				"★自宅電話番号",
				"【書類送付先】郵便番号1",
				"【書類送付先】郵便番号2",
				"【書類送付先】都道府県",
				"【書類送付先】住所１",
				"【書類送付先】住所２",
				"★備考",
				"予約状況",
				"パスワード",
				"メールアドレス",
				"携帯電話番号"
			);
            /*$headers = array (
                    "社員番号",
                    "姓（漢字）",
                    "名（漢字）",
                    "姓（カナ）",
                    "名（カナ）",
                    "★所属部門コード",
                    "★所属部門",
                    "★役職",
                    "姓（英語）",
                    "名（英語）",
                    "★会社電話番号",
                    "★会社Fax番号",
                    "★会社内線",
                    "★【会社住所】郵便番号１",
                    "★【会社住所】郵便番号２",
                    "★【会社住所】都道府県",
                    "★【会社住所】住所１",
                    "★【会社住所】住所２",
                    "★会社名",
                    "入社年月日",
                    "会社メールアドレス",
                    "メールアドレス",
                    "パスワード",
                    "書類送付先区分　　1:自宅/2:会社/9:その他",
                    "書類送付先名称",
                    "【書類送付先】郵便番号1",
                    "【書類送付先】郵便番号2",
                    "【書類送付先】都道府県",
                    "【書類送付先】住所１",
                    "【書類送付先】住所２",
                    "【確定】方面区分　1:海外 2:国内　",
                    "【確定】方面コード",
                    "【確定】班",
                    "【確定】発着コード",
                    "【確定】AIR行程",
                    "コース名",
                    "★【緊急連絡先】氏名",
                    "★【緊急連絡先】続柄",
                    "★【緊急連絡先】電話番号",
                    "★日中の連絡先電話番号",
                    "★管理者備考",
                    "★参加者備考",
                    "★不参加備考",
                    "★アレルギー用の備考",
                    "★参加者番号",
                    "★部屋番号",
                    "旅行代金全額（オプショナル除く）",
                    "キャンセル代金全額",
                    "★旅行代金備考",
                    "旅行代金オプショナル全額",
                    "★オプショナル代金支払いリンク1",
                    "★オプショナル代金支払いリンク1への説明文言",
                    "★オプショナル代金支払いリンク2",
                    "★オプショナル代金支払いリンク2への説明文言",
                    "★オプショナル代金支払いリンク3",
                    "★オプショナル代金支払いリンク3への説明文言",
                    "★備考"
            );*/
			
        }
        // 同行者・パスポート情報
        if ($infoType == 1) {
            $headers = array (
                    "社員番号",
                    "申込者本人・同行者",
                    "コース名",
                    "性別",
                    "姓（漢字）",
                    "名（漢字）",
                    "姓（カナ）",
                    "名（カナ）",
                    "姓（ローマ字）",
                    "名（ローマ字）",
                    "★生年月日",
                    "★国籍名",
                    "パスポート番号",
                    "パスポート画像アップロード",
                    "パスポート有効期限",
                    "パスポート発行日",
                    "パスポート姓",
                    "パスポートミドル",
                    "パスポート名",
                    "★【自宅住所】郵便番号1",
                    "★【自宅住所】郵便番号2",
                    "★【自宅住所】都道府県",
                    "★【自宅住所】1",
                    "★【自宅住所】2",
                    "★【自宅】電話番号",
                    "★携帯電話番号",
                    "★お住いの地域",
                    "★最寄りの空港",
                    "★最寄りの駅",
                    "パスポート画像アップロード",
                    "参加費用（円）",
                    "個人負担額名称１",
                    "個人負担額１",
                    "個人負担額名称2",
                    "個人負担額2",
                    "個人負担額名称3",
                    "個人負担額3",
                    "個人負担額名称4",
                    "個人負担額4",
                    "個人負担額名称5",
                    "個人負担額5",
                    "★備考",
                    "★禁煙 ・喫煙 " . PHP_EOL . "(0:禁煙 1:喫煙)",
                    "キャンセル費用（円）",
                    "★キャンセル日",
                    "★キャンセル" . PHP_EOL . "(1:キャンセルになる)"
            );
        }
        // オプショナル申し込み情報
        if ($infoType == 2) {
            $headers = array (
                    "社員番号",
                    "申込者本人・同行者",
					"同伴者". PHP_EOL . "グループ",
					"所属部課名",
                    "氏名（漢字）",
                    "氏名（カナ）",
					"M/F",
					"Name",
					"生年月日",
					"年齢",
                    "オプショナルコード",
                    "オプショナル名",
                    "参加希望日",
                    "時間",
					"オプショナルツーアのオプショナル名",
					"選択オプション時間",
					"選択オプション",
                    "オプショナル備考",
                     "★手配状況" . PHP_EOL . "(1: 手配中　2:手配完了 3:手配不可 4:取消依頼中 5:取消完了 6:取消完了1 7:取消完了2 8:要確認 9:不催行)",
                   // "【実績】入金種別",
                    //"【予定】入金種別",
                    "入金状況",
					"予約状況",
					"オプショナル(登録日)",
					"オプショナル(更新日)"
                    //"★入金日",
                    //"承認番号",
                    //"入金備考・承認番号"
            );
        }
        // フライト情報
        if ($infoType == 3) {
            $headers = array (
                    "社員番号",
					"同行者",   //追加
					"同行者G",  //追加
					"所属部署名", //追加
					"氏名（漢字）",
					"カタカナ",  //追加
					"性別",	 //追加 
					"年齢",	//追加	
                    "★フライトID",
                    "★【往路】出発日",
                    "★【往路】出発便",
                    "★【往路】出発空港",
                    "★【往路】出発時刻",
                    "★【往路】到着時刻",
                    "★【往路】到着空港",
                    "★【復路】出発日",
                    "★【復路】出発便",
                    "★【復路】出発空港",
                    "★【復路】出発空港",
                    "★【復路】出発時刻",
                    "★【復路】到着時刻",
                    "★【復路】到着日",
                    "★備考",
					"予約状況"
            );
        }

        if ($infoType == 4) {
            $headers = array (
                    "社員番号",
                    "申込者本人・同行者",
                    "氏名（漢字）",                    
                    "別便番号",
                    "0:未登録　1:往路　２：復路",
                    "SeqNo",
                    "★出発日",
                    "★出発場所",
                    "★出発時刻",
                    "★便名",
                    "★到着場所",
                    "★到着時刻",
					"★備考",
					"予約状況"
            );
        }

        if ($infoType == 5) {
            $headers = array (
                    "社員番号",
                    "申込者本人・同行者",
                    "氏名（漢字）",                  
                    "前泊・後泊",
                    "項目番号",
                    "日付",
					"★ホテル名",
                    "★部屋タイプ",
					"★確定部屋タイプ",
                    "★備考",
					"★確定備考",
					"★ホテル代金",
					"予約状況"
            );
        }

        if ($infoType == 6) {
            // 送付先リスト
            $headers = array (
                    "社員番号",
                    "姓（漢字）",
                    "名（漢字）",
                    "姓（カナ）",
                    "名（カナ）",
                    "書類送付先名称",
                    "郵便番号",
                    "【書類送付先】都道府県",
                    "【書類送付先】住所１",
                    "【書類送付先】住所２",
                    "★会社名",
                    "★所属部門",
                    "★会社電話番号",
                    "自宅電話番号",
                    "★備考"
            );
        }
        if ($infoType == 7) {
            // ネーム リスト
            $headers = array (
                    "IDNo",
                    "★PAXNo.",
                    "同伴者グループ",
                    "所属部課名",
                    "氏名",
                    "Name",
                    "★AIR Class",
                    "生年月日",
                    "★CHD/INF機内RQ",
                    "★Remarks"
            );
        }

        return $headers;
    }

    /**
     * CSVファイルに 参加者基本情報を出す
     *
     * @param int $infoType
     *            エクスポートのID
     */
    private function download_csv_participant($infoType) {
        if ($this->isSessionCourseExist()) {

            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');

            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);

            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();
            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);
			
            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {					
                    $csvData = array ();
					$csvData['R00_Id']  = $result['R00_Id'];
					$csvData['R00_Sei'] = $result['R01_Sei'];
					$csvData['R00_Name'] = $result['R01_Name'];
					$csvData['R00_Sei_Kana'] = $result['R00_Sei_Kana'];
                    $csvData['R00_Name_Kana'] = $result['R00_Name_Kana'];
					/*if( $result['R00_Dest_Kbn'] == 1 ){
						$csvData['R01_Sei_Eng'] = $result['R01_Passport_Sei'];
						$csvData['R01_Name_Eng'] = $result['R01_Passport_Name'];
					} elseif( $result['R00_Dest_Kbn'] == 2 ){
						$csvData['R01_Sei_Eng'] = $result['R01_Sei_Eng'];
						$csvData['R01_Name_Eng'] = $result['R01_Name_Eng'];
					}*/
					if ($result['R00_SendPlace'] == '1') {
						$R00_SendPlace = '自宅';
					} elseif ($result['R00_SendPlace'] == '2') {
						$R00_SendPlace = '会社';
					} elseif ($result['R00_SendPlace'] == '9') {
						$R00_SendPlace = 'その他';
					} else {
						$R00_SendPlace = '';
					}
					$csvData['R00_SendPlace'] = $R00_SendPlace;
					$csvData['R00_Company'] = $result['R00_Company'];
					$csvData['R00_Division'] = $result['R00_Division'];		
					$csvData['R00_Company_Tel'] = $result['R00_Company_Tel'];
					$csvData['R01_Tel'] = $result['R01_Tel'];
					// 自宅の場合、自宅住所を参照
                    if ($result['R00_SendPlace'] == 1) {
                        $csvData['R00_Document_Post1'] = "'" . $result['R01_Post1'];
                        $csvData['R00_Document_Post2'] = "'" . $result['R01_Post2'];
                        $csvData['R00_Document_Pref'] = $result['R01_Address_Pref'];
                        $csvData['R00_Document_Addr1'] = "'" . $result['R01_Address1'];
                        $csvData['R00_Document_Addr2'] = $result['R01_Address2'];

                        // 会社の場合、会社住所を参照
                    } elseif ($result['R00_SendPlace'] == 2) {
                        $csvData['R00_Document_Post1'] = "'" .$result['R00_Company_Post1'];
                        $csvData['R00_Document_Post2'] = "'" .$result['R00_Company_Post2'];
                        $csvData['R00_Document_Pref'] = $result['R00_Company_Pref'];
                        $csvData['R00_Document_Addr1'] = "'" . $result['R00_Company_Address1'];
                        $csvData['R00_Document_Addr2'] = $result['R00_Company_Address2'];
                        // その他・設定なしの場合
                    } else {
                        $csvData['R00_Document_Post1'] = "'" .$result['R00_Document_Post1'];
                        $csvData['R00_Document_Post2'] = "'" .$result['R00_Document_Post2'];
                        $csvData['R00_Document_Pref'] = $result['R00_Document_Pref'];
                        $csvData['R00_Document_Addr1'] = "'" . $result['R00_Document_Addr1'];
                        $csvData['R00_Document_Addr2'] = $result['R00_Document_Addr2'];
                    }
					$csvData['R00_Note'] = $result['R00_Note'];
					if($result['R01_Cancel_flag'] ==1){
						$csvData['R01_Cancel_flag'] = "キャンセル";
					}else{
						$csvData['R01_Cancel_flag'] = "";
					}
					$csvData['R00_Password'] = "'".$result['R00_Password'];
					$csvData['R00_Mailaddress'] = $result['R00_Mailaddress'];
					$csvData['R01_Mobile'] = $result['R01_Mobile'];
                    /*$csvData['R00_Id'] = $result['R00_Id'];
                    $csvData['R00_Sei'] = $result['R00_Sei'];
                    $csvData['R00_Name'] = $result['R00_Name'];
                    $csvData['R00_Sei_Kana'] = $result['R00_Sei_Kana'];
                    $csvData['R00_Name_Kana'] = $result['R00_Name_Kana'];
                    $csvData['R00_Division_Code'] = $result['R00_Division_Code'];
                    $csvData['R00_Division'] = $result['R00_Division'];
                    $csvData['R00_Yakusyoku'] = $result['R00_Yakusyoku'];
                    $csvData['R00_Sei_Eng'] = $result['R00_Sei_Eng'];
                    $csvData['R00_Name_Eng'] = $result['R00_Name_Eng'];
                    $csvData['R00_Company_Tel'] = $result['R00_Company_Tel'];
                    $csvData['R00_Company_Fax'] = $result['R00_Company_Fax'];
                    $csvData['R00_Company_Naisen'] = $result['R00_Company_Naisen'];
                    $csvData['R00_Company_Post1'] = "'" .$result['R00_Company_Post1'];
                    $csvData['R00_Company_Post2'] = "'" .$result['R00_Company_Post2'];
                    $csvData['R00_Company_Pref'] = $result['R00_Company_Pref'];

                    // Update Start　テキスト出力できるようにする
                    // $csvData['R00_Company_Address1'] = $result['R00_Company_Address1'];
                    $csvData['R00_Company_Address1'] = "'" . $result['R00_Company_Address1'];
                    // Update End

                    $csvData['R00_Company_Address2'] = $result['R00_Company_Address2'];
                    $csvData['R00_Company'] = $result['R00_Company'];
                    $csvData['R00_Nyusha_Date'] = $result['R00_Nyusha_Date'];
                    $csvData['R00_Company_MailAddress'] = $result['R00_Company_MailAddress'];
                    $csvData['R00_Mailaddress'] = $result['R00_Mailaddress'];
                    $csvData['R00_Password'] = $result['R00_Password'];

                    // Update Start　R00_SendPlaceの値によって住所の参照先を切り替える
                    // if ($result['R00_SendPlace'] == '') {
                    // $R00_SendPlace = 'その他';
                    // } elseif ($result['R00_SendPlace'] == '1') {
                    // $R00_SendPlace = '自宅';
                    // } elseif ($result['R00_SendPlace'] == '2') {
                    // $R00_SendPlace = '会社';
                    // } else {
                    // $R00_SendPlace = '';
                    // }
                    // $csvData['R00_SendPlace'] = $R00_SendPlace;

                    $csvData['R00_SendPlace'] = $result['R00_SendPlace'];
                    $csvData['M21_Name'] = $result['M21_Name'];

                    // $csvData['R00_Document_Post1'] = $result['R00_Document_Post1'];
                    // $csvData['R00_Document_Post2'] = $result['R00_Document_Post2'];
                    // $csvData['R00_Document_Pref'] = $result['R00_Document_Pref'];
                    // $csvData['R00_Document_Addr1'] = $result['R00_Document_Addr1'];
                    // $csvData['R00_Document_Addr2'] = $result['R00_Document_Addr2'];

                    // 自宅の場合、自宅住所を参照
                    if ($result['R00_SendPlace'] == 1) {
                        $csvData['R00_Document_Post1'] = "'" . $result['R01_Post1'];
                        $csvData['R00_Document_Post2'] = "'" . $result['R01_Post2'];
                        $csvData['R00_Document_Pref'] = $result['R01_Address_Pref'];
                        $csvData['R00_Document_Addr1'] = "'" . $result['R01_Address1'];
                        $csvData['R00_Document_Addr2'] = $result['R01_Address2'];

                        // 会社の場合、会社住所を参照
                    } elseif ($result['R00_SendPlace'] == 2) {
                        $csvData['R00_Document_Post1'] = "'" .$result['R00_Company_Post1'];
                        $csvData['R00_Document_Post2'] = "'" .$result['R00_Company_Post2'];
                        $csvData['R00_Document_Pref'] = $result['R00_Company_Pref'];
                        $csvData['R00_Document_Addr1'] = "'" . $result['R00_Company_Address1'];
                        $csvData['R00_Document_Addr2'] = $result['R00_Company_Address2'];
                        // その他・設定なしの場合
                    } else {
                        $csvData['R00_Document_Post1'] = "'" .$result['R00_Document_Post1'];
                        $csvData['R00_Document_Post2'] = "'" .$result['R00_Document_Post2'];
                        $csvData['R00_Document_Pref'] = $result['R00_Document_Pref'];
                        $csvData['R00_Document_Addr1'] = "'" . $result['R00_Document_Addr1'];
                        $csvData['R00_Document_Addr2'] = $result['R00_Document_Addr2'];
                    }
                    // Update End　R00_SendPlaceの値によって住所の参照先を切り替える

                    $csvData['R00_Dest_Kbn'] = $result['R00_Dest_Kbn'];
                    $csvData['R00_Dest_Code'] = $result['R00_Dest_Code'];
                    $csvData['R00_Han'] = $result['R00_Han'];
                    $csvData['R00_Dep_Id'] = $result['R00_Dep_Id'];
                    $csvData['R00_Dep_Id'] = $result['R00_Dep_Id'];
                    $csvData['M01_Course_Name'] = $CourseData['M01_Course_Name'];
                    $csvData['R00_emargency_mei'] = $result['R00_emargency_mei'];
                    $csvData['R00_emargency_zoku'] = $result['R00_emargency_zoku'];
                    $csvData['R00_emargency_tel'] = $result['R00_emargency_tel'];
                    $csvData['R00_emargency_tel_daytime'] = $result['R00_emargency_tel_daytime'];
                    $csvData['R00_Admin_Note'] = $result['R00_Admin_Note'];
                    $csvData['R00_Customer_Note'] = $result['R00_Customer_Note'];
                    $csvData['R00_Fusanka_Note'] = $result['R00_Fusanka_Note'];
                    $csvData['R00_allergy_Note'] = $result['R00_allergy_Note'];
                    $csvData['R00_NumberOfParticipants'] = $result['R00_NumberOfParticipants'];
                    $csvData['R00_NumberOfRooms'] = $result['R00_NumberOfRooms'];
                    $csvData['R00_Total_Travel_Cost'] = $result['R00_Total_Travel_Cost'];
                    $csvData['R00_Cancel_Cost'] = $result['R00_Cancel_Cost'];
                    $csvData['R00_Travel_Cost_Note'] = $result['R00_Travel_Cost_Note'];
                    $csvData['R00_Total_Travel_Cost_Optional'] = $result['R00_Total_Travel_Cost_Optional'];
                    $csvData['R00_Optional_Credit_link1'] = $result['R00_Optional_Credit_link1'];
                    $csvData['R00_Optional_Credit_link_Text1'] = $result['R00_Optional_Credit_link_Text1'];
                    $csvData['R00_Optional_Credit_link2'] = $result['R00_Optional_Credit_link2'];
                    $csvData['R00_Optional_Credit_link_Text2'] = $result['R00_Optional_Credit_link_Text2'];
                    $csvData['R00_Optional_Credit_link3'] = $result['R00_Optional_Credit_link3'];
                    $csvData['R00_Optional_Credit_link_Text3'] = $result['R00_Optional_Credit_link_Text3'];
                    $csvData['R00_Note'] = $result['R00_Note'];*/

                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }

        // close csv file
        fclose($output);
    }

    /**
     *
     * @param int $infoType
     */
    private function download_csv_passport($infoType) {
        if ($this->isSessionCourseExist()) {
            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);
            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();
            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);

            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
                    $csvData = array ();
                    $csvData['R01_Id'] = $result['R01_Id'];

                    if ($result['R01_Plan'] == 0) {
                        $R01_Plan = '申込者本人';
                    } else {
                        $R01_Plan = '同行者' . $result['R01_Plan'];
                    }

                    $csvData['R01_Plan'] = $R01_Plan;
                    $csvData['M01_Course_Name'] = $CourseData['M01_Course_Name'];
					
                    $csvData['R01_Sex'] = $result['R01_Sex']==1 ? '男性' : '女性';
                    $csvData['R01_Sei'] = $result['R01_Sei'];
                    $csvData['R01_Name'] = $result['R01_Name'];
                    $csvData['R01_Sei_Kana'] = $result['R01_Sei_Kana'];
                    $csvData['R01_Name_Kana'] = $result['R01_Name_Kana'];
					if($result['R00_Dest_Kbn'] ==1){
						$csvData['R01_Sei_Eng'] = $result['R01_Passport_Sei'];
						$csvData['R01_Name_Eng'] = $result['R01_Passport_Name'];
					}else{
						$csvData['R01_Sei_Eng'] = $result['R01_Sei_Eng'];
						$csvData['R01_Name_Eng'] = $result['R01_Name_Eng'];
					}
                    $csvData['R01_Birthday'] = $result['R01_Birthday'];
                    $csvData['R01_Nationality'] = $result['R01_Nationality'];
                    $csvData['R01_Passport_No'] = $result['R01_Passport_No'];

                    if ($result['R01_PassportImg'] != null || $result['R01_PassportImg'] != "") {
                        $R01_PassportImg = 'アップロード済み';
                    } else {
                        $R01_PassportImg = '';
                    }
                    $csvData['R01_PassportImg'] = $R01_PassportImg;
                    $csvData['R01_Passport_Expire'] = $result['R01_Passport_Expire'];
                    $csvData['R01_Passport_Issue'] = $result['R01_Passport_Issue'];
                    $csvData['R01_Passport_Sei'] = $result['R01_Passport_Sei'];
                    $csvData['R01_Passport_Middle'] = $result['R01_Passport_Middle'];
                    $csvData['R01_Passport_Name'] = $result['R01_Passport_Name'];
                    $csvData['R01_Post1'] = $result['R01_Post1'];
                    $csvData['R01_Post2'] = $result['R01_Post2'];
                    $csvData['R01_Address_Pref'] = $result['R01_Address_Pref'];
                    $csvData['R01_Address1'] = $result['R01_Address1'];
                    $csvData['R01_Address2'] = $result['R01_Address2'];
                    $csvData['R01_Tel'] = $result['R01_Tel'];
                    $csvData['R01_Mobile'] = $result['R01_Mobile'];
                    $csvData['R01_Adress_Area'] = $result['R01_Adress_Area'];
                    $csvData['R01_Adress_Airport'] = $result['R01_Adress_Airport'];
                    $csvData['R01_Adress_Sta'] = $result['R01_Adress_Sta'];

                    if ($result['R01_Passpost_Upload_Flag'] == '0') {
                        $R01_Passpost_Upload_Flag = '未';
                    } elseif ($result['R01_Passpost_Upload_Flag'] == '1') {
                        $R01_Passpost_Upload_Flag = '済';
                    } else {
                        $R01_Passpost_Upload_Flag = '';
                    }

                    $csvData['R01_Passpost_Upload_Flag'] = $R01_Passpost_Upload_Flag;
                    $csvData['R01_Travel_Cost'] = $result['R01_Travel_Cost'];
                    $csvData['R01_Cost_Name1'] = $result['R01_Cost_Name1'];
                    $csvData['R01_Cost1'] = $result['R01_Cost1'];
                    $csvData['R01_Cost_Name2'] = $result['R01_Cost_Name2'];
                    $csvData['R01_Cost2'] = $result['R01_Cost2'];
                    $csvData['R01_Cost_Name3'] = $result['R01_Cost_Name3'];
                    $csvData['R01_Cost3'] = $result['R01_Cost3'];
                    $csvData['R01_Cost_Name4'] = $result['R01_Cost_Name4'];
                    $csvData['R01_Cost4'] = $result['R01_Cost4'];
                    $csvData['R01_Cost_Name5'] = $result['R01_Cost_Name5'];
                    $csvData['R01_Cost5'] = $result['R01_Cost5'];
                    $csvData['R01_Note'] = $result['R01_Note'];

                    if ($result['R01_tabaco'] == '0') {
                        $R01_tabaco = '禁煙';
                    } elseif ($result['R01_tabaco'] == '1') {
                        $R01_tabaco = '喫煙';
                    } else {
                        $R01_tabaco = '';
                    }

                    $csvData['R01_tabaco'] = $R01_tabaco;
                    $csvData['R01_Cancel_Cost'] = $result['R01_Cancel_Cost'];
                    $csvData['R01_Cancel_Day'] = $result['R01_Cancel_Day'];

                    if ($result['R01_Cancel_flag'] == 1) {
                        $R01_Cancel_flag = 'CXL';
                    } else {
                        $R01_Cancel_flag = '';
                    }

                    $csvData['R01_Cancel_flag'] = $R01_Cancel_flag;

                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }

        // close csv file
        fclose($output);
    }
    private function download_csv_optional($infoType) {
        if ($this->isSessionCourseExist()) {
            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);
            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();
            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);
	
            $searchResult = $this->getOptionParticipate($searchResult);			
			
            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
					$R04_Tour_Option = '';
                    $csvData = array ();
                    $csvData['R04_Id'] = $result['R04_Id'];
                    if ($result['R01_Plan'] == 0) {
                        $R01_Plan = '申込者本人';
                    } else {
                        $R01_Plan = '同行者' . $result['R01_Plan'];
                    }
                    $csvData['R01_Plan'] = $R01_Plan;
					$csvData['R00_Group_No'] = $result['R00_Group_No'];
					if($result['R01_Plan'] == 0){
						$csvData['R00_Division'] = $result['R00_Division'];										
					} else {
						$csvData['R00_Division'] = "";										
					}					
                    $csvData['R01_Sei_Name'] = $result['R01_Sei'].' '.$result['R01_Name'];
                    $csvData['R01_Sei_Kana'] = $result['R01_Sei_Kana'].' '.$result['R01_Name_Kana'];
					
					if($result['R01_Sex'] ==1){
						$csvData['MF'] = "MR";
					}else{
						$csvData['MF'] = "MS";
					}
					if($result['R00_Dest_Kbn'] ==1){
						$csvData['Name']				= $result['R01_Passport_Sei'].' '.$result['R01_Passport_Name'];
					}else{
						$csvData['Name']				= $result['R01_Sei_Eng'].' '.$result['R01_Name_Eng'];
					}
					
					$csvData['R01_Birthday'] 			= $result['R01_Birthday'];
					$csvData['Age']						= floor((date('Ymd' , strtotime($result['M01_Dep_Date']))-date('Ymd' , strtotime($result['R01_Birthday'])))/10000) . '歳';
                    $csvData['R04_Optional_Tour_Code']  = $result['R04_Optional_Tour_Code'];
                    $csvData['R04_Optional_Tour_Name']  = $result['R04_Optional_Tour_Name'];
                    $csvData['R04_Optional_Kibou_Date'] = $result['R04_Optional_Kibou_Date'].'日目';
                    $csvData['R04_Optional_Kibou_Time'] = $result['R04_Optional_Kibou_Time'];
					$csvData['opt_name'] = $result['opt_name'];
					$csvData['opt_time'] = $result['opt_time'];
					//選択オプションデータ取得
					for($i=1;$i<=10;$i++){
						if($result['R04_Tour_Option'.$i.'_Name'] != ''){
							$R04_Tour_Option .= $result['R04_Tour_Option'.$i.'_Name'].PHP_EOL;
						} 
					} 
					$csvData['R04_Tour_Option'] = $R04_Tour_Option;
                    $csvData['R04_Tour_Note'] = $result['R04_Tour_Note'];
                    $csvData['M10_STS'] = $result['M10_STS'];
                    $payment = $this->getTotalPayment($result['R01_Id']);
                    $Fee     = $this->getTotalFee($result);
                    $balance = $Fee - $payment;
					if($balance<0 AND $result['R04_STS'] == 2){
                    //if($balance<0){
                        $csvData['Payment_Sts'] = '入金済み';
                    }else{
                        $csvData['Payment_Sts'] = '未入金';
                    }	
					//予約キャンセル
					if($result['R01_Cancel_flag'] ==1){
						$csvData['Cancel'] = 'キャンセル';
					}else{
						$csvData['Cancel'] = '';
					}
					//オプションナル登録日
					$csvData['R04_Create_Date'] = $result['R04_Create_Date'];
					//オプションナル更新日
					if($result['R04_UpdateTime'] != "0000-00-00 00:00:00"){
						$csvData['R04_UpdateTime'] = $result['R04_UpdateTime'];
					}else{
						$csvData['R04_UpdateTime'] = '';
					}				
                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }
    }
    private function download_csv_flight($infoType) {
        if ($this->isSessionCourseExist()) {
            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);
            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();
            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);			
            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
                    $csvData = array ();
                    $csvData['R02_Id'] = $result['R02_Id'];
					if($result['R01_Plan'] == 0){
						$plan  = "申込者本人"; //追加
						$group = $result['R00_Group_No'];
						$department = $result['R00_Division'];
					}else{
						$plan = "同行者"; //追加
						$group = "";
						$department = "";
					}
					$csvData['R02_Doko'] = $plan;//追加
					$csvData['R02_Doko_G'] = $group; //追加
					$csvData['R02_Dept'] =  $department; //追加
                    $csvData['R02_Sei_Name'] = $result['R01_Sei'].' '.$result['R01_Name'];
					$csvData['R02_Kana'] = $result['R01_Sei_Kana'].' '.$result['R01_Name_Kana']; //追加
					if($result['R01_Sex'] == 1){
						$sex = "男性";
					}else{
						$sex = "女性";
					}
					$csvData['R02_Sex'] = $sex; //追加
					$csvData['R02_Age'] = floor((date('Ymd' , strtotime($CourseData['M01_Dep_Date']))-date('Ymd' , strtotime($result['R01_Birthday'])))/10000) . '歳'; //追加
                    $csvData['R02_Flight_id'] = $result['R02_Flight_id'];
                    $csvData['R02_Go_Date'] = $result['R02_Go_Date'];
                    $csvData['R02_Go_Air'] = $result['R02_Go_Air'];
                    $csvData['R02_Go_Airport'] = $result['R02_Go_Airport'];
                    $csvData['R02_Go_Dep_time'] = $result['R02_Go_Dep_time'];
                    $csvData['R02_Go_Arr_Time'] = $result['R02_Go_Arr_Time'];
                    $csvData['R02_Go_Arr_Airport'] = $result['R02_Go_Arr_Airport'];
                    $csvData['R02_Rtn_Date'] = $result['R02_Rtn_Date'];
                    $csvData['R02_Rtn_Air'] = $result['R02_Rtn_Air'];
                    $csvData['R02_Rtn_Airport'] = $result['R02_Rtn_Airport'];
                    $csvData['R02_Rtn_Arr_Airport'] = $result['R02_Rtn_Arr_Airport'];
                    $csvData['R02_Rtn_Dep_Time'] = $result['R02_Rtn_Dep_Time'];
                    $csvData['R02_Rtn_Arr_Time'] = $result['R02_Rtn_Arr_Time'];
                    $csvData['R02_Rtn_Arr_Date'] = $result['R02_Rtn_Arr_Date'];
                    $csvData['R02_Note'] = $result['R02_Note'];
					
					if($result['R01_Cancel_flag']==1){
						$cancel = "キャンセル";
					}else{
						$cancel = "";
					}
					$csvData['Cancel'] = $cancel;
					

                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }
    }
    private function download_csv_traffic($infoType) {
        if ($this->isSessionCourseExist()) {
            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);
            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();
            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);

            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
                    $csvData = array ();
                    $csvData['R07_ReserveId'] = $result['R07_ReserveId'].'-'.$result['R01_Plan'];

                    if ($result['R01_Plan'] == 0) {
                        $R01_Plan = '申込者本人';
                    } else {
                        $R01_Plan = '同行者';
                    }

                    $csvData['R01_Plan'] = $R01_Plan;
                    $csvData['R01_Sei_Name'] = $result['R01_Sei'].$result['R01_Name'];                    
                    $csvData['R07_Transport_No'] = $result['R07_Transport_No'];

                    if ($result['R07_Transport_Type'] == '0') {
                        $R07_Transport_Type = '未登録';
                    } elseif ($result['R07_Transport_Type'] == '1') {
                        $R07_Transport_Type = '往路';
                    } elseif ($result['R07_Transport_Type'] == '2') {
                        $R07_Transport_Type = '復路';
                    } else {
                        $R07_Transport_Type = '';
                    }

                    $csvData['R07_Transport_Type'] = $R07_Transport_Type;
                    $csvData['R07_Transport_Sequence'] = $result['R07_Transport_Sequence'];
                    $csvData['R07_Transport_Date'] = $result['R07_Transport_Date'];
                    $csvData['R07_Transport_Place'] = $result['R07_Transport_Place'];
                    $csvData['R07_Transport_Dep_Time'] = $result['R07_Transport_Dep_Time'];
                    $csvData['R07_Transport_Name'] = $result['R07_Transport_Name'];
                    $csvData['R07_Transport_Arr_Place'] = $result['R07_Transport_Arr_Place'];
                    $csvData['R07_Transport_Arr_Time'] = $result['R07_Transport_Arr_Time'];
					$csvData['R07_Note'] = $result['R07_Note'];
					if( $result['R01_Cancel_flag'] == 1){
						$csvData['R01_Cancel_flag'] = 'キャンセル';
					}else{
						$csvData['R01_Cancel_flag'] = '';
					}
                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }
    }
    private function download_csv_stay($infoType) {
        if ($this->isSessionCourseExist()) {
            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);
            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();
            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);

            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
                    $csvData = array ();
                    $csvData['R09_ReserveId'] = $result['R09_ReserveId'].'-'.$result['R01_Plan'];
                    if ($result['R01_Plan'] == 0) {
                        $R01_Plan = '申込者本人';
                    } else {
                        $R01_Plan = '同行者';
                    }

                    $csvData['R01_Plan'] = $R01_Plan;
                    $csvData['R01_Sei_Name'] = $result['R01_Sei'].' '.$result['R01_Name'];
                    //$csvData['R09_ReserveId'] = $CourseData['R09_ReserveId'];

                    if ($result['R09_Type'] == '1') {
                        $R09_Type = '前泊';
                    } elseif ($result['R09_Type'] == '2') {
                        $R09_Type = '後泊';
                    } else {
                        $R09_Type = '';
                    }

                    $csvData['R09_Type'] = $R09_Type;
                    $csvData['R09_Sequence'] = $result['R09_Sequence'];
					$csvData['R09_Hotel_Stay_Date'] = $this->convert_format->ChangeJpDay($result['R09_Hotel_Stay_Date']);
					$csvData['R09_Hotel_Name'] = $result['R09_Hotel_Name'];
                    $csvData['R09_Hote_Room_Type'] = $result['R09_Hote_Room_Type'];
					$csvData['R09_Confirm_Room_Type'] = $result['R09_Confirm_Room_Type'];
                    $csvData['R09_Hote_Note'] = $result['R09_Hote_Note'];
					$csvData['R09_Confirm_Hote_Note'] = $result['R09_Confirm_Hote_Note'];
					if($result['R01_Plan'] == 0){
						$csvData['total'] = $result['total'];
					}
					if( $result['R01_Cancel_flag'] == 1){
						$csvData['R01_Cancel_flag'] = 'キャンセル';
					}else{
						$csvData['R01_Cancel_flag'] = '';
					}
                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }
    }

    /**
     * CSVファイルに 送付先リストを出す
     *
     * @param int $infoType
     *            エクスポートのID
     */
    public function download_csv_destination($infoType) {
        if ($this->isSessionCourseExist()) {

            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);

            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');

            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);

            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();

            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);

            $NameSendPlace = $this->operating_mo->getNameSendPlace();
            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
                    $csvData = array ();
                    $csvData['R00_Id'] = $result['R00_Id'];
                    $csvData['R00_Sei'] = $result['R00_Sei'];
                    $csvData['R00_Name'] = $result['R00_Name'];
                    $csvData['R00_Sei_Kana'] = $result['R00_Sei_Kana'];
                    $csvData['R00_Name_Kana'] = $result['R00_Name_Kana'];
                    $csvData['R00_SendPlace'] = empty($NameSendPlace[$result['R00_SendPlace']]) ? '' : $NameSendPlace[$result['R00_SendPlace']];
                    $csvData['R00_Document_Post1'] = $result['R00_Document_Post1'] . "-" . $result['R00_Document_Post2'];
                    $csvData['R00_Document_Pref'] = $result['R00_Document_Pref'];
                    $csvData['R00_Document_Addr1'] = $result['R00_Document_Addr1'];
                    $csvData['R00_Document_Addr2'] = $result['R00_Document_Addr2'];
                    $csvData['R00_Company'] = $result['R00_Company'];
                    $csvData['R00_Division'] = $result['R00_Division'];
                    $csvData['R00_Company_Tel'] = $result['R00_Company_Tel'];
                    $csvData['R01_Tel'] = $result['R01_Tel'];
                    $csvData['R00_Note'] = $result['R00_Note'];

                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }

        // close csv file
        fclose($output);
    }
    /*
     *
     * ネーム リスト csv 取得
     */
    public function download_csv_namelist($infoType) {
        if ($this->isSessionCourseExist()) {
            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header($infoType);
            $title = $this->initInfoTitleByInfoType($infoType);
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            // output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $fileName);

            // create a file pointer connected to the output stream
            $output = fopen('php://output', 'w');

            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);

            // write content to csv file
            // get search result
            $course = $this->session->userdata('Course');
            $CourseData = $this->load_course();

            $searchKey = $this->getSearchKey();
            $searchResult = $this->getSearchResult($infoType, $searchKey, $course);
            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {
                    $csvData = array ();
                    $csvData['R01_Id'] = $result['R01_Id'] . '-' . ($result['R01_Plan'] + 1);
                    $csvData['R01_PaxNo'] = $result['R01_PaxNo'];
                    if ($result['R01_Plan'] == 0) {
                        $csvData['R00_Group_No'] = $result['R00_Group_No'];
                    } else {
                        $csvData['R00_Group_No'] = '';
                    }
                    if ($result['R01_Plan'] == 0) {
                        $csvData['R00_Division'] = $result['R00_Division'];
                    } else {
                        $csvData['R00_Division'] = '';
                    }
                    $csvData['R01_Sei'] = $result['R01_Sei'] . ' ' . $result['R01_Name'];
                    if ($result['R01_Sex'] == 1) {
                        $csvData['R01_Sei_Kana'] = 'MR　' . $result['R01_Sei_Kana'] . '　' . $result['R01_Name_Kana'];
                    } else {
                        $csvData['R01_Sei_Kana'] = 'MS　' . $result['R01_Sei_Kana'] . '　' . $result['R01_Name_Kana'];
                    }
                    $csvData['R01_AirClass'] = $result['R01_AirClass'];
                    $csvData['R01_Birthday'] = $result['R01_Birthday'];
                    $csvData['R01_CHD_NameList'] = $result['R01_CHD_NameList'];
                    $csvData['R01_Remarks_NameList'] = $result['R01_Remarks_NameList'];
                    // END
                    fputcsv($output, $csvData);
                }
            }
        } else {
            redirect(base_url('menu_con'));
        }

        // close csv file
        fclose($output);
    }
    public function import() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');

        if (! empty($admin_id)) {
            if ($this->isSessionCourseExist()) {
                $data = array ();

                // リクエストデーターを取得する
                $operatingType = $this->input->post('operating_type');
                $infoType = $this->input->post('info_type');

                if ($operatingType == '' || $infoType == '') {
                    redirect(base_url('menu_con'));
                }

                $errorArray = $this->selectImport($infoType);
                if ($errorArray != null) {
                    $data['update_status'] = 2; // error
                } else {
                    $data['update_status'] = 1; // success
                }
                $data['error_arr'] = $errorArray;
                $this->load_base_page($operatingType, $infoType, $data);
            } else {
                redirect(base_url('menu_con'));
            }
        } else {
            redirect(base_url('admin_con'));
        }
    }
    private function selectImport($infoType) {
        $errorResult = array ();
        switch ($infoType) {
            case 0 :
                $errorResult = $this->importParticipant();
                break;
            case 1 :
                $errorResult = $this->importPassport();
                break;
            case 2 :
                $errorResult = $this->importOptional();
                break;
            case 3 :
                $errorResult = $this->importFlight();
                break;
            case 4 :
                $errorResult = $this->importTraffic();
                break;
            case 5 :
                $errorResult = $this->importStay();
                break;
            case 6 :
                $errorResult = $this->importDestination();
                break;
            case 7 :
                $errorResult = $this->importNameList();
                break;
            default :
                $errorResult = null;
                break;
        }

        return $errorResult;
    }
    private function readCsvContent() {
        if (isset($_POST['btnImport'])) {
            if ($_FILES['fileImport']['size'] > 0) {
                setlocale(LC_ALL, 'ja_JP.UTF-8');
                // CSV 読み込み 処理
                $csv = $_FILES["fileImport"]["tmp_name"];
                $buffer = mb_convert_encoding(file_get_contents($csv), "UTF-8", "sjis-win");
                $fp = tmpfile();
                fwrite($fp, $buffer);
                rewind($fp);
                // CSV データ格納処理
                $data = array ();
                $i = 0;
                while( ($csv_row = fgetcsv($fp)) !== FALSE ) {
                    // CSVのHEADERを外す
                    if ($i == 0) {
                        $i ++;
                        continue;
                    }
                    // CSVデーターを取得する
                    $data[] = $csv_row;
                    $i ++;
                }
                fclose($fp);
                return $data;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
    private function convertCsvRowData($rowData = null) {
        $convertData = '';
        if (isset($rowData)) {
            $sub = substr($rowData, 0, 1);
            if ($sub === "'") {
                $convertData = preg_replace("", "'", $rowData, 1);
            }
        } else {
            $convertData = '';
        }
        return $convertData;
    }

    /**
     * 申込み本人基本情報
     *
     * @return array[] | null エラー発生配列
     */
    private function importParticipant() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R00_Id' => '',
                        'R00_Sei' => '',
                        'R00_Name' => '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else {
                foreach ( $csvContent as $key => $csvRowData ) {
                    $updateData['R00_Id']		   = ! isset($csvRowData[0]) ? "" : trim($csvRowData[0]); // 社員番号
					$updateData['R00_Company'] 	   = ! isset($csvRowData[6]) ? "" : trim($csvRowData[6]); // 会社名
					$updateData['R00_Division']    = ! isset($csvRowData[7]) ? "" : trim($csvRowData[7]); // 所属部門
					$updateData['R00_Company_Tel'] = ! isset($csvRowData[8]) ? "" : trim($csvRowData[8]); // 会社電話番号
					$R01_Upd['R01_Tel']		   = ! isset($csvRowData[9]) ? "" : trim($csvRowData[9]); // 自宅電話番号
					$updateData['R00_Note']		   = ! isset($csvRowData[15]) ? "" : trim($csvRowData[15]); // 備考
					
                    /*$updateData['R00_Division_Code'] = ! isset($csvRowData[5]) ? "" : trim($csvRowData[5]); // 所属部門コード
                    $updateData['R00_Division'] = ! isset($csvRowData[6]) ? "" : trim($csvRowData[6]); // 所属部門
                    $updateData['R00_Yakusyoku'] = ! isset($csvRowData[7]) ? "" : trim($csvRowData[7]); // 役職
                    $updateData['R00_Company_Tel'] = ! isset($csvRowData[10]) ? "" : trim($csvRowData[10]); // 会社電話番号
                    $updateData['R00_Company_Fax'] = ! isset($csvRowData[11]) ? "" : trim($csvRowData[11]); // 会社Fax番号
                    $updateData['R00_Company_Naisen'] = ! isset($csvRowData[12]) ? "" : trim($csvRowData[12]); // 会社内線

                    $R00_Company_Post1 = ! isset($csvRowData[13]) ? "" : trim($csvRowData[13]); // 【会社住所】郵便番号１
                    $R00_Company_Post2 = ! isset($csvRowData[14]) ? "" : trim($csvRowData[14]); // 【会社住所】郵便番号２
                    //20170404テットウ
                    if (strpos($R00_Company_Post1, "'") !== false) {
                        $R00_Company_Post1 = ltrim($R00_Company_Post1, "'");
                    }
                    if (strpos($R00_Company_Post2, "'") !== false) {
                        $R00_Company_Post2 = ltrim($R00_Company_Post2, "'");
                    }
                    $updateData['R00_Company_Post1'] = $R00_Company_Post1;
                    $updateData['R00_Company_Post2'] = $R00_Company_Post2;
                    //20170404テットウ
                    $updateData['R00_Company_Pref'] = ! isset($csvRowData[15]) ? "" : trim($csvRowData[15]); // 【会社住所】都道府県
                    $R00_Company_Address1 = ! isset($csvRowData[16]) ? "" : trim($csvRowData[16]); // 【会社住所】住所１

                    if (strpos($R00_Company_Address1, "'") !== false) {
                        $R00_Company_Address1 = ltrim($R00_Company_Address1, "'");
                    }

                    $updateData['R00_Company_Address1'] = $R00_Company_Address1;
                    $updateData['R00_Company_Address2'] = ! isset($csvRowData[17]) ? "" : trim($csvRowData[17]); // 【会社住所】住所２
                    $updateData['R00_Company'] = ! isset($csvRowData[18]) ? "" : trim($csvRowData[18]); // 会社名
                    $updateData['R00_emargency_mei'] = ! isset($csvRowData[36]) ? "" : trim($csvRowData[36]); // 【緊急連絡先】氏名
                    $updateData['R00_emargency_zoku'] = ! isset($csvRowData[37]) ? "" : trim($csvRowData[37]); // 【緊急連絡先】続柄
                    $updateData['R00_emargency_tel'] = ! isset($csvRowData[38]) ? "" : trim($csvRowData[38]); // 【緊急連絡先】電話番号
                    $updateData['R00_emargency_tel_daytime'] = ! isset($csvRowData[39]) ? "" : trim($csvRowData[39]); // 日中の連絡先電話番号
                    $updateData['R00_Admin_Note'] = ! isset($csvRowData[40]) ? "" : trim($csvRowData[40]); // 管理者備考
                    $updateData['R00_Customer_Note'] = ! isset($csvRowData[41]) ? "" : trim($csvRowData[41]); // 参加者備考
                    $updateData['R00_Fusanka_Note'] = ! isset($csvRowData[42]) ? "" : trim($csvRowData[42]); // 不参加備考
                    $updateData['R00_allergy_Note'] = ! isset($csvRowData[43]) ? "" : trim($csvRowData[43]); // アレルギー用の備考
                    $updateData['R00_NumberOfParticipants'] = ! isset($csvRowData[44]) ? "" : trim($csvRowData[44]); // 参加者番号
                    $updateData['R00_NumberOfRooms'] = ! isset($csvRowData[45]) ? "" : trim($csvRowData[45]); // 部屋番号
                    $updateData['R00_Travel_Cost_Note'] = ! isset($csvRowData[48]) ? "" : trim($csvRowData[48]); // 旅行代金備考
                    $updateData['R00_Optional_Credit_link1'] = ! isset($csvRowData[50]) ? "" : trim($csvRowData[50]); // オプショナル代金支払いリンク1
                    $updateData['R00_Optional_Credit_link_Text1'] = ! isset($csvRowData[51]) ? "" : trim($csvRowData[51]); // オプショナル代金支払いリンク1への説明文言
                    $updateData['R00_Optional_Credit_link2'] = ! isset($csvRowData[52]) ? "" : trim($csvRowData[52]); // オプショナル代金支払いリンク2
                    $updateData['R00_Optional_Credit_link_Text2'] = ! isset($csvRowData[53]) ? "" : trim($csvRowData[53]); // オプショナル代金支払いリンク2への説明文言
                    $updateData['R00_Optional_Credit_link3'] = ! isset($csvRowData[54]) ? "" : trim($csvRowData[54]); // オプショナル代金支払いリンク3
                    $updateData['R00_Optional_Credit_link_Text3'] = ! isset($csvRowData[55]) ? "" : trim($csvRowData[55]); // オプショナル代金支払いリンク3への説明文言
                    $updateData['R00_Note'] = ! isset($csvRowData[56]) ? "" : trim($csvRowData[56]); // 備考
					*/
                    // check exist
                    $isParticipantExcist = $this->operating_mo->checkParticipantExistById($updateData['R00_Id']);
                    if ($isParticipantExcist) {
                        $result = $this->operating_mo->updateParticipantInfo($updateData);
						$this->operating_mo->updateTelParticipantInfo($updateData['R00_Id'], $R01_Upd);
                        if ($result == - 1) {
                            $errorArray[] = array (
                                    'R00_Id' => $updateData['R00_Id'],
                                    'R00_Sei' => ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]),
                                    'R00_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
                                    'msg' => '<font color="red">インポート失敗しました。</font>'
                            );
                        }
                    } else {
                        $errorArray[] = array (
                                'R00_Id' => $updateData['R00_Id'],
                                'R00_Sei' => ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]),
                                'R00_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
                                'msg' => '<font color="red">ユーザー存在していません。</font>'
                        );
                    }
                }
            }
            return $errorArray;
        }
    }

    /**
     * 同行者・パスポート情報
     *
     * @return array[] | null エラー発生配列
     */
    private function importPassport() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R01_Id' => '',
                        'R01_Sei' => '',
                        'R01_Name' => '',
                        'R01_Plan' => '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // Neu co noi dung thi thuc hien luu vao db va lay ra mang
                foreach ( $csvContent as $key => $csvRowData ) {
                    $updateData['R01_Id'] = ! isset($csvRowData[0]) ? "" : trim($csvRowData[0]); // 社員番号

                    $R01_Plan = ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]); // 申込者本人・同行者
                    if ($R01_Plan == '申込者本人') {
                        $updateData['R01_Plan'] = 0;
                    } else {
                        $updateData['R01_Plan'] = mb_substr($R01_Plan, 3, 1, 'utf-8');
                    }

                    $updateData['R01_Birthday'] = ! isset($csvRowData[10]) ? "" : trim($csvRowData[10]); // 生年月日
                    $updateData['R01_Nationality'] = ! isset($csvRowData[11]) ? "" : trim($csvRowData[11]); // 国籍名
                    $updateData['R01_Post1'] = ! isset($csvRowData[19]) ? "" : trim($csvRowData[19]); // 【自宅住所】郵便番号1
                    $updateData['R01_Post2'] = ! isset($csvRowData[20]) ? "" : trim($csvRowData[20]); // 【自宅住所】郵便番号2
                    $updateData['R01_Address_Pref'] = ! isset($csvRowData[21]) ? "" : trim($csvRowData[21]); // 【自宅住所】都道府県
                    $updateData['R01_Address1'] = ! isset($csvRowData[22]) ? "" : trim($csvRowData[22]); // 【自宅住所】1
                    $updateData['R01_Address2'] = ! isset($csvRowData[23]) ? "" : trim($csvRowData[23]); // 【自宅住所】2
                    $updateData['R01_Tel'] = ! isset($csvRowData[24]) ? "" : trim($csvRowData[24]); // 【自宅】電話番号
                    $updateData['R01_Mobile'] = ! isset($csvRowData[25]) ? "" : trim($csvRowData[25]); // 携帯電話番号
                    $updateData['R01_Adress_Area'] = ! isset($csvRowData[26]) ? "" : trim($csvRowData[26]); // お住いの地域
                    $updateData['R01_Adress_Airport'] = ! isset($csvRowData[27]) ? "" : trim($csvRowData[27]); // 最寄りの空港
                    $updateData['R01_Adress_Sta'] = ! isset($csvRowData[28]) ? "" : trim($csvRowData[28]); // 最寄りの駅
                    $updateData['R01_Note'] = ! isset($csvRowData[41]) ? "" : trim($csvRowData[41]); // 備考
                    $updateData['R01_tabaco'] = ! isset($csvRowData[42]) ? "" : trim($csvRowData[42]); // 0:禁煙 1:喫煙
                    $updateData['R01_Cancel_Day'] = ! isset($csvRowData[44]) ? "" : trim($csvRowData[44]); // キャンセル日
                    $updateData['R01_Cancel_flag'] = ! isset($csvRowData[45]) ? "" : trim($csvRowData[45]); // キャンセル

                    // check exist
                    $isPassportExist = $this->operating_mo->checkPassportExistById($updateData['R01_Id'], $updateData['R01_Plan']);
                    if ($isPassportExist) {
                        $result = $this->operating_mo->updatePassportInfo($updateData);
                        if ($result == - 1) {
                            $errorArray[] = array (
                                    'R01_Id' => $updateData['R01_Id'],
                                    'R01_Plan' => ($updateData['R01_Plan'] == '0') ? ('申込者本人') : ('同行者' . $updateData['R01_Plan']),
                                    'R01_Sei' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
                                    'R01_Name' => ! isset($csvRowData[5]) ? "" : trim($csvRowData[5]),
                                    'msg' => '<font color="red">インポート失敗しました。</font>'
                            );
                        }
                    } else {
                        $errorArray[] = array (
                                'R01_Id' => $updateData['R01_Id'],
                                'R01_Plan' => ($updateData['R01_Plan'] == '0') ? ('申込者本人') : ('同行者' . $updateData['R01_Plan']),
                                'R01_Sei' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
                                'R01_Name' => ! isset($csvRowData[5]) ? "" : trim($csvRowData[5]),
                                'msg' => '<font color="red">ユーザー存在していません。</font>'
                        );
                    }
                }
            }
            return $errorArray;
        }
    }

    /**
     * オプショナル
     *
     * @return array[] | null エラー発生配列
     */
    private function importOptional() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R04_Id' => '',
                        'R01_Plan' => '',
                        'R01_Sei_Name' => '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // Neu co noi dung thi thuc hien luu vao db va lay ra mang
                foreach ( $csvContent as $key => $csvRowData ) {
                    $updateData['R04_Id'] = ! isset($csvRowData[0]) ? "" : trim($csvRowData[0]); // 社員番号
                    $R04_STS = ! isset($csvRowData[15]) ? "" : trim($csvRowData[15]); // 手配状況
                    $status = $this->operating_mo->getStatus($R04_STS);
                    $updateData['R04_STS'] = $status['M10_Id'];
                    // check exist
                    $isOptionalExist = $this->operating_mo->checkOptionalExistById($updateData['R04_Id']);
                    if ($isOptionalExist) {
                        $result = $this->operating_mo->updateOptionalInfo($updateData);
                        if ($result == - 1) {
                            $errorArray[] = array (
                                    'R04_Id' => $updateData['R04_Id'],
                                    'R01_Plan' => ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]),
                                    'R01_Sei_Name' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
                                    'msg' => '<font color="red">インポート失敗しました。</font>'
                            );
                        }
                    } else {
                        $errorArray[] = array (
                                'R04_Id' => $updateData['R01_Id'],
                                'R01_Plan' => ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]),
                                'R01_Sei_Name' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
                                'msg' => '<font color="red">ユーザー存在していません。</font>'
                        );
                    }
                }
            }
            return $errorArray;
        }
    }
    private function importFlight() {
		setlocale(LC_ALL, 'ja_JP.UTF-8');
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R02_Id' => '',
                        'R01_Sei_Name' => '',
                        'R02_Flight_id' => '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // Neu co noi dung thi thuc hien luu vao db va lay ra mang				
                foreach ( $csvContent as $key => $csvRowData ) {
					if($csvRowData[1] != "同行者"){
						$updateData['R02_Id'] = ! isset($csvRowData[0]) ? "" : trim($csvRowData[0]); // 社員番号
						$updateData['R02_Flight_id'] = ! isset($csvRowData[8]) ? "" : trim($csvRowData[8]); // フライトID
						$updateData['R02_Go_Date'] = ! isset($csvRowData[9]) ? "" : trim($csvRowData[9]); // 【往路】出発日
						$updateData['R02_Go_Air'] = ! isset($csvRowData[10]) ? "" : trim($csvRowData[10]); // 【往路】出発便
						$updateData['R02_Go_Airport'] = ! isset($csvRowData[11]) ? "" : trim($csvRowData[11]); // 【往路】出発空港
						$updateData['R02_Go_Dep_time'] = ! isset($csvRowData[12]) ? "" : trim($csvRowData[12]); // 【往路】出発時刻
						$updateData['R02_Go_Arr_Time'] = ! isset($csvRowData[13]) ? "" : trim($csvRowData[13]); // 【往路】到着時刻
						$updateData['R02_Go_Arr_Airport'] = ! isset($csvRowData[14]) ? "" : trim($csvRowData[14]); // 【往路】到着空港
						$updateData['R02_Rtn_Date'] = ! isset($csvRowData[15]) ? "" : trim($csvRowData[15]); // 【復路】出発日
						$updateData['R02_Rtn_Air'] = ! isset($csvRowData[16]) ? "" : trim($csvRowData[16]); // 【復路】出発便
						$updateData['R02_Rtn_Airport'] = ! isset($csvRowData[17]) ? "" : trim($csvRowData[17]); // 【復路】出発空港
						$updateData['R02_Rtn_Arr_Airport'] = ! isset($csvRowData[18]) ? "" : trim($csvRowData[18]); // 【復路】出発空港
						$updateData['R02_Rtn_Dep_Time'] = ! isset($csvRowData[19]) ? "" : trim($csvRowData[19]); // 【復路】出発時刻
						$updateData['R02_Rtn_Arr_Time'] = ! isset($csvRowData[20]) ? "" : trim($csvRowData[20]); // 【復路】到着時刻
						$updateData['R02_Rtn_Arr_Date'] = ! isset($csvRowData[21]) ? "" : trim($csvRowData[21]); // 【復路】到着日
						$updateData['R02_Note'] = ! isset($csvRowData[22]) ? "" : trim($csvRowData[22]); // 備考

						// check exist
						$isFlightExist = $this->operating_mo->checkFlightExistById($updateData['R02_Id']);
						if ($isFlightExist) {
							$result = $this->operating_mo->updateFlightInfo($updateData);
							if ($result == - 1) {
								$errorArray[] = array (
										'R02_Id' => $updateData['R01_Id'],
										'R01_Sei_Name' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
										'R02_Flight_id' => $updateData['R02_Flight_id'],
										'msg' => '<font color="red">インポート失敗しました。</font>'
								);
							}
						} else {
							$errorArray[] = array (
									'R02_Id' => $updateData['R02_Id'],
									'R01_Sei_Name' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
									'R02_Flight_id' => $updateData['R02_Flight_id'],
									'msg' => '<font color="red">ユーザー存在していません。</font>'
							);
						}
					}
                }
            }
            return $errorArray;
        }
    }
    private function importTraffic() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R07_Id' => '',
                        'R01_Plan' => '',
                        'R01_Sei_Name' => '',
                        'R07_Transport_No' => '',
						'R07_Transport_Type'=> '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // Neu co noi dung thi thuc hien luu vao db va lay ra mang
                foreach ( $csvContent as $key => $csvRowData ) {
                    $R07_Id = explode('-',$csvRowData[0]); // 社員番号
					$updateData['R07_Id'] = $R07_Id[0];
					$R01_Plan = $R07_Id[1];
                    /*$R07_Transport_Sequence = ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]); // 申込者本人・同行者
                    if ($R07_Transport_Sequence == '申込者本人') {
                        $updateData['R07_Transport_Sequence'] = 0;
                    } else {
                        $updateData['R07_Transport_Sequence'] = mb_substr($R07_Transport_Sequence, 3, 1, 'utf-8');
                    }*/	
					$updateData['R07_Transport_No'] = ! isset($csvRowData[3]) ? "" : trim($csvRowData[3]); // 別便番号
					// 往路・復路状況
					if($csvRowData[4] == '往路'){
						$updateData['R07_Transport_Type'] = 1;
					}elseif($csvRowData[4] == '復路'){
						$updateData['R07_Transport_Type'] = 2;
					}elseif($csvRowData[4] == '未登録'){
						$updateData['R07_Transport_Type'] = 0;
					}else{
						$updateData['R07_Transport_Type'] = $csvRowData[4];
					}					
					$updateData['R07_Transport_Sequence'] = ! isset($csvRowData[5]) ? "" : trim($csvRowData[5]); // SeqNo
                    $updateData['R07_Transport_Date'] = ! isset($csvRowData[6]) ? "" : trim($csvRowData[6]); // 出発日
                    $updateData['R07_Transport_Place'] = ! isset($csvRowData[7]) ? "" : trim($csvRowData[7]); // 出発場所
                    $updateData['R07_Transport_Dep_Time'] = ! isset($csvRowData[8]) ? "" : trim($csvRowData[8]); // 出発時刻
                    $updateData['R07_Transport_Name'] = ! isset($csvRowData[9]) ? "" : trim($csvRowData[9]); // 便名
                    $updateData['R07_Transport_Arr_Place'] = ! isset($csvRowData[10]) ? "" : trim($csvRowData[10]); // 到着場所
                    $updateData['R07_Transport_Arr_Time'] = ! isset($csvRowData[11]) ? "" : trim($csvRowData[11]); // 到着時刻
					$updateData['R07_Note'] = ! isset($csvRowData[12]) ? "" : trim($csvRowData[12]); // 到着時刻
                    if($R01_Plan ==0){
						$isTrafficExist = $this->operating_mo->checkTrafficExistById($updateData['R07_Id']);
						if ($isTrafficExist) {
							$result = $this->operating_mo->updateTrafficInfo($updateData);
							if ($result == - 1) {
								$errorArray[] = array (
										'R07_Id' => $updateData['R07_Id'],
										'R01_Plan' => ($R01_Plan == '0') ? ('申込者本人') : ('同行者'),
										'R01_Sei_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
										'R07_Transport_No' => ! isset($csvRowData[3]) ? "" : trim($csvRowData[3]),
										'R07_Transport_Type'=> ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
										'msg' => '<font color="red">インポート失敗しました。</font>'
								);
							}
						} else {
							$errorArray[] = array (
									'R07_Id' => $updateData['R07_Id'],
									'R01_Plan' => ($R01_Plan == '0') ? ('申込者本人') : ('同行者'),
									'R01_Sei_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
									'R07_Transport_No' => ! isset($csvRowData[3]) ? "" : trim($csvRowData[3]),
									'R07_Transport_Type'=> ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),
									'msg' => '<font color="red">ユーザー存在していません。</font>'
							);
						}
					}                                                                                               // check exist
                }
            }
            return $errorArray;
        }
    }
    private function importStay() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R09_ReserveId' => '',
                        'R09_Sequence' => '',
                        'R01_Sei_Name' => '',                       
						'R09_Type' => '',//前泊・後泊
						'R09_Sequence' => '',//項目番号
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // Neu co noi dung thi thuc hien luu vao db va lay ra mang
				$tmp_seq = null;
                foreach ( $csvContent as $key => $csvRowData ) {
					$R09_ReserveId = explode('-',$csvRowData[0]); // 社員番号
					$updateData['R09_ReserveId'] = $R09_ReserveId[0];
					$R01_Plan = $R09_ReserveId[1];                 								
					//前泊・後泊判断
					if($csvRowData[3] == '前泊'){
						$updateData['R09_Type'] =1;
					}elseif($csvRowData[3] == '後泊'){
						$updateData['R09_Type'] =2;
					}
					//R09_Sequence
					$updateData['R09_Sequence'] = ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]); // R09_Sequence
					$updateData['R09_Hotel_Name'] = ! isset($csvRowData[6]) ? "" : trim($csvRowData[6]); //ホテル名
                    $updateData['R09_Hote_Room_Type'] = ! isset($csvRowData[7]) ? "" : trim($csvRowData[7]); // 部屋タイプ
					$updateData['R09_Confirm_Room_Type'] = ! isset($csvRowData[8]) ? "" : trim($csvRowData[8]); // 確定部屋タイプ
                    $updateData['R09_Hote_Note'] = ! isset($csvRowData[9]) ? "" : trim($csvRowData[9]); // 備考
					$updateData['R09_Confirm_Hote_Note'] = ! isset($csvRowData[10]) ? "" : trim($csvRowData[10]); // 確定備考
					$updateData['R09_Room_Price'] = ! isset($csvRowData[11]) ? "" : trim($csvRowData[11]); // ホテル代金				
					
                    // check exist
					if($tmp_seq != $updateData['R09_Sequence']){
						$isStayExist = $this->operating_mo->checkStayExistById($updateData['R09_ReserveId'], $updateData['R09_Sequence'], $updateData['R09_Type']);
						if ($isStayExist) {
							$result = $this->operating_mo->updateStayInfo($updateData);
							if ($result == - 1) {
								$errorArray[] = array (
										'R09_ReserveId' => $updateData['R09_ReserveId'],
										'R09_Sequence' => ($R01_Plan == '0') ? ('申込者本人') : ('同行者' . $R01_Plan),
										'R01_Sei_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
										'R09_Type' => ! isset($csvRowData[3]) ? "" : trim($csvRowData[3]),//前泊・後泊
										'R09_Sequence' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[3]),//項目番号
										'msg' => '<font color="red">インポート失敗しました。</font>'
								);
							}
						} else {
							$errorArray[] = array (
									'R09_ReserveId' => $updateData['R09_ReserveId'],
									'R09_Sequence' => ($R01_Plan == '0') ? ('申込者本人') : ('同行者' . $R01_Plan),
									'R01_Sei_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
									'R09_Type' => ! isset($csvRowData[3]) ? "" : trim($csvRowData[3]),//前泊・後泊
									'R09_Sequence' => ! isset($csvRowData[4]) ? "" : trim($csvRowData[4]),//項目番号
									'msg' => '<font color="red">ユーザー存在していません。</font>'
							);
						}
					}
					$tmp_seq = $updateData['R09_Sequence'];
                    
                }				
            }
            return $errorArray;
        }
    }
    /**
     * 送付先リスト
     *
     * @return array[] | null エラー発生配列
     */
    public function importDestination() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();

            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R00_Id' => '',
                        'R00_Sei' => '',
                        'R00_Name' => '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // 内容がれば、配列をとってDBに保存して行う

                foreach ( $csvContent as $key => $csvRowData ) {
                    $updateData['R00_Id'] = ! isset($csvRowData[0]) ? "" : trim($csvRowData[0]); // 社員番号
                    $updateData['R00_Company'] = ! isset($csvRowData[10]) ? "" : trim($csvRowData[10]); // 会社名
                    $updateData['R00_Division'] = ! isset($csvRowData[11]) ? "" : trim($csvRowData[11]); // 所属部門
                    $updateData['R00_Company_Tel'] = ! isset($csvRowData[12]) ? "" : trim($csvRowData[12]); // 会社電話番号
                    $updateData['R00_Note'] = ! isset($csvRowData[14]) ? "" : trim($csvRowData[14]); // 備考
                    // check exist
                    $isDestinationExcist = $this->operating_mo->checkDestinationExistById($updateData['R00_Id']);
                    if ($isDestinationExcist) {
                        $result = $this->operating_mo->updateDestinationInfo($updateData);

                        if ($result == - 1) {
                            $errorArray[] = array (
                                    'R00_Id' => $updateData['R00_Id'],
                                    'R00_Sei' => ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]),
                                    'R00_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
                                    'msg' => '<font color="red">インポート失敗しました。</font>'
                            );
                        }
                    } else {
                        $errorArray[] = array (
                                'R00_Id' => $updateData['R00_Id'],
                                'R00_Sei' => ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]),
                                'R00_Name' => ! isset($csvRowData[2]) ? "" : trim($csvRowData[2]),
                                'msg' => '<font color="red">ユーザー存在していません。</font>'
                        );
                    }
                }
            }
            return $errorArray;
        }
    }
    /**
     * ネームリスト
     *
     * @return array[] | null エラー発生配列
     */
    public function importNameList() {
        if (isset($_POST['btnImport'])) {
            $csvContent = $this->readCsvContent();
            $updateData = array ();
            $errorArray = array ();
            if ($csvContent == null) {
                $errorArray[] = array (
                        'R01_Id' => '',
                        'msg' => '<font color="red">ファイルの内容がありません。</font>'
                );
            } else { // 内容がれば、配列をとってDBに保存して行う
                foreach ( $csvContent as $key => $csvRowData ) {

                    $﻿﻿id_no = ! isset($csvRowData[0]) ? "" : trim($csvRowData[0]);
                    $﻿﻿id_no_arr = explode('-', $﻿﻿id_no);
                    $updateData['R01_Id'] = $﻿﻿id_no_arr[0];
                    if (isset($﻿﻿id_no_arr[1])) {
                        $updateData['R01_Plan'] = $﻿﻿id_no_arr[1] - 1;
                        $error_plan_no = $﻿﻿id_no_arr[1];
                    } else {
                        $updateData['R01_Plan'] = "";
                        $error_plan_no = "";
                    }
                    $updateData['R01_PaxNo'] = ! isset($csvRowData[1]) ? "" : trim($csvRowData[1]); //
                    $updateData['R01_AirClass'] = ! isset($csvRowData[6]) ? "" : trim($csvRowData[6]); //
                    $updateData['R01_CHD_NameList'] = ! isset($csvRowData[8]) ? "" : trim($csvRowData[8]); //
                    $updateData['R01_Remarks_NameList'] = ! isset($csvRowData[9]) ? "" : trim($csvRowData[9]); //
                    // check exist
                    $isNameListExist = $this->operating_mo->checkNameListExistById($updateData['R01_Id'], $updateData['R01_Plan']);

                    if ($isNameListExist) {
                        $result = $this->operating_mo->updateNameListInfo($updateData);

                        if ($result == - 1) {
                            $errorArray[] = array (
                                    'R01_Id' => $updateData['R01_Id'] . '-' . $error_plan_no,
                                    'msg' => '<font color="red">インポート失敗しました。</font>'
                            );
                        }
                    } else {
                        $errorArray[] = array (
                                'R01_Id' => $updateData['R01_Id'] . '-' . $error_plan_no,
                                'msg' => '<font color="red">ユーザー存在していません。</font>'
                        );
                    }
                }
            }
            return $errorArray;
        }
    }

    /**
     * コースによって、予約本人ID配列を取得する
     * @param array $param コース主キー
     * @return array|null 予約本人ID配列
     */
    private function getReserveIdListByCourse($param) {
        $reserves = $this->menu_mo->getReserveIdListByCourse($param);
        $reserveIdList = array ();
        if ($reserves != null) {
            foreach ( $reserves as $reserve ) {
                $reserveIdList[] = $reserve['R00_Id'];
            }
            return $reserveIdList;
        }
        return null;
    }

    private function downloadSecretaryFileByCourse($course) {
        // コース情報
        $courseData = $this->operating_mo->getCourseDataByParam($course);
		$Event = $this->operating_mo->getIdEventByParam($course);
		$EventId  = $Event['M20_Event_Code'];
        // コースの参加者情報
        $reserveIdList = $this->getReserveIdListByCourse($course);
        $userData = $this->operating_mo->getTravelInfoByIdList($reserveIdList,$EventId);
        $type = 1;//Excel_Secretary.xlsxを読み込む	
		$kubun	= 	$course['R00_Dest_Kbn'];
       $this->excelsecretary->createSecretaryFile($courseData , $userData, $type,$kubun);
    }
    
    /**
     * 幹事作業用リスト（Room順）を出力する。 
     * @param $course
     * @return 幹事作業用リスト
     * @author catnhp
     */
    private function downloadSecretaryFileOrderByRoom($course) {
    	// コース情報
    	$courseData = $this->operating_mo->getCourseDataByParam($course);
		$Event = $this->operating_mo->getIdEventByParam($course);
		$EventId  = $Event['M20_Event_Code'];
    	// コースの参加者情報
    	$reserveIdList = $this->getReserveIdListByCourse($course);
    	$userData = $this->operating_mo->getTravelInfoOderByRoom($reserveIdList,$EventId);
    	$type = 2;//Excel_Secretary_OderByRoom.xlsxを読み込む	
		$kubun	= 	$course['R00_Dest_Kbn'];
    	$this->excelsecretary->createSecretaryFile($courseData , $userData, $type,$kubun);
    }

    /*
    *
    *入金額
    *
    */
      private function getTotalPayment($staffId) {
        $paymentData = $this->admin_edit_mo->getPaymentDataByStaffId($staffId);
        $totalPayment = 0;
        if ($paymentData != null) {
            foreach ($paymentData as $payment) {
                $totalPayment += $payment['R13_Payment_Cost'];
            }
        }
        return $totalPayment;
    }
        /*
    *支払金額
    *
    */
    private function getTotalFee($participantInfo) {
        // get sum_cost
        $sum_cost = 0;
        for($i = 2; $i <= 5; $i ++) {
            //foreach ( $participantInfo as $key_no => $CostInfo ) {
                $R01_Cost_Name = 'R01_Cost_Name' . $i;
                $R01_Cost = 'R01_Cost' . $i;
                if ($participantInfo[$R01_Cost] != '0' || $participantInfo[$R01_Cost_Name] = "" || $participantInfo[$R01_Cost] != null) {
                    $data_flag = true;
                    $sum_cost += $participantInfo[$R01_Cost];
                }
            //}
        }
        // get sumEsta_cost
        $sumEsta_cost = 0;
        $cost = 0;
        //foreach ( $participantInfo as $key_no => $CostInfo ) {
            if ($participantInfo['R01_Cost_Name1'] != '' || $participantInfo['R01_Cost_Name1'] != null) {
                $cost = $participantInfo['R01_Cost1'];
                $sumEsta_cost += $cost;
                $data_flag = true;
            }
        //}
        // get optional_total
        $optional_total = 0;
		$optionals   = $this->getOptTourDataArr($participantInfo['R01_Id']);
        if (!empty($optionals)) {
            $data_flag = true;
            $optional_total = 0;
            foreach ( $optionals as $optional_key => $optional ) {
                $optional_total += $participantInfo['R04_Tour_Jpy'];
            }
        }
        $total = $sum_cost + $sumEsta_cost + $optional_total;
        return $total;
    }
	
	 private function getOptTourDataArr($staff_id){
         // オプショナルツアー
        $optionals = $this->admin_edit_mo->getOptionalByUserId($staff_id);
        if ($optionals != null) {
            foreach ($optionals as $optional_key => $optional) {
                $tmp = $optional;
                for ($i = 0 ; $i <=8  ; $i++) {
                    $R04_Tour_ParticipationPlan = 'R04_Tour_ParticipationPlan' . $i;
                    if ($optional[$R04_Tour_ParticipationPlan] != 0) {
                        $participant = $this->admin_edit_mo->getParticipantOptionalsByPlanAndUserId($staff_id , $i);
                        if ($participant != null) {
                            $tmp['participantOptionals'][] = $participant;
                        }
                    }
                }
                $result[] = $tmp;
            }
        }else{
            $result = NULL;
        }
        return $result;
    }
}
