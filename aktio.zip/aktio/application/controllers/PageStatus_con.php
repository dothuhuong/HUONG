<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );

class PageStatus_con extends CI_Controller {

    public function PageStatus_con() {
        parent::__construct ();
        $this->load->helper( 'url' );
        $this->load->library ( 'session' );
        $this->load->model('pagestatus_mo');
    }

    public function index() {
        $data = array();
        $data['title'] = "管理画面ページ";
        $data['pgstatus'] = $this->pagestatus_mo->getPgStatus();
        //var_dump($data['pgstatus']);
        $this->load->view('header_admin_vi' , $data);
        $this->load->view('pageStausCg_vi');
        $this->load->view('footer_vi');
    }
}
