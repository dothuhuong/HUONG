<?php

defined('BASEPATH') or exit('No direct script access allowed');
error_reporting(E_ALL ^ E_WARNING);
class User_top_con extends CI_Controller {
    public function User_top_con() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
		$this->load->library('email');
        $this->load->model('user_top_mo');
        $this->load->model('mypage_mo');
        $this->load->model('common_mo');
        $this->load->model('menu_mo');
        $this->load->model('transport_ptn_mo');
        $this->load->model('course_mo');
        $this->load->model('anni_event_mo');
        $this->load->model('hotel_mo');
        $this->load->model('optional_mo');
        $this->load->model('admin_edit_mo');
		$this->load->model('operating_mo');
		$this->load->model('anq_mo');
        $this->load->library('convert_format');
    }

    public function index() {
        //セクションから代表者ID　取得
        $staff_id = $this->session->userdata('R00_Id');
        $BeforeStay1Name = "";
        $BeforeStay2Name = "";
        $BeforeStay3Name = "";
        $AfterStay1Name = "";
        $AfterStay2Name = "";
        $AfterStay3Name = "";
        if ($staff_id == '' || $staff_id == null) {// セッションがなくなった場合はログインページに移動する
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $data['user_name'] = $this->getUserName();
            // 代表者情報
			$data['anq']        = $this->anq_mo->getAnqStaffInfo($staff_id);
            $StaffInfo         = $this->user_top_mo->getStaffInfo($staff_id);
            $data['SameGroupNo']       = $this->user_top_mo->getSameGroup($StaffInfo['R00_Group_No'],$staff_id);
            $data['traveler_info'] = $this->user_top_mo->getAdress_Jitaku($staff_id);
            $data['staffInfo'] = $StaffInfo;
            $R04_data_arr = array(
                "R04_Dest_Kbn"   => $StaffInfo['R00_Dest_Kbn'],
                "R04_Dest_Code"  => $StaffInfo['R00_Dest_Code'],
                "R04_Han"        => $StaffInfo['R00_Han'],
                "R04_Dep_Id"     => $StaffInfo['R00_Dep_Id'],
                "R04_Air_Program"=> $StaffInfo['R00_Air_Program']
            );

            // お知らせを取得する
			$M02Arr = array(
                "R00_Dest_Kbn"    => $StaffInfo['R00_Dest_Kbn'],
                "R00_Dest_Code"   => $StaffInfo['R00_Dest_Code'],
                "R00_Han"         => $StaffInfo['R00_Han'],
                "R00_Dep_Id"      => $StaffInfo['R00_Dep_Id'],
                "R00_Air_Program" => $StaffInfo['R00_Air_Program']
            );
			$data['CourseTodoInfo'] = $this->user_top_mo->getCourseTodoById($M02Arr);
            $data['notices'] = $this->user_top_mo->getNoticeByCondition($R04_data_arr);
            // 確定コースに情報を取得する
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($staff_id);
            $kakuteiInfo = $this->user_top_mo->getKakuteCourseById($CourseArr);
            $data['kakuteiInfo'] = $kakuteiInfo ;
            $data['rate']=$this->optional_mo->getRateId($kakuteiInfo);
            $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
            $data['visainfo'] = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
            //参加者の情報を取得
            $data['participantInfo'] = $this->user_top_mo->getUserInfo($staff_id);
            $data['esta_sts'] = $this->user_top_mo->getEstaSts();
            $data['etas_sts'] = $this->user_top_mo->getEstaSts();
            $data['cnmi_sts'] = $this->user_top_mo->getCNMISts();
            // オプショナルツアー
            $optionals = $this->user_top_mo->getOptionalByUserId($staff_id);

            $data['optionals'] = array();
            if ($optionals != null) {
                foreach ($optionals as $optional_key => $optional) {
                    $tmp = $optional;
                    for ($i = 0 ; $i <=8  ; $i++) {
                        $R04_Tour_ParticipationPlan = 'R04_Tour_ParticipationPlan' . $i;
                        if ($optional[$R04_Tour_ParticipationPlan] != 0) {
                            $participant = $this->user_top_mo->getParticipantOptionalsByPlanAndUserId($staff_id , $i);
                            if ($participant != null) {
                                $tmp['participantOptionals'][] = $participant;
                            }
                        }
                    }
					//20170430 add by HT		
					$tmp['opt_select'] = $this->optional_mo->optional_reserve_opt($optional['R04_Pkey']);					
                    $data['optionals'][] = $tmp;
                }			
            }								
            // 20170406 add by Vien start
            $courseTodoPrimary = $this->convertPrimaryCourseTodo($CourseArr , 'M02');
            if ($courseTodoPrimary != null) {
                $optHayaDate = $this->user_top_mo->getOPHayaByPrimary($courseTodoPrimary);
                $courseLimitPrimary = $this->convertPrimaryLimitSet($CourseArr , 'M18');
                $optEndDate  = $this->user_top_mo->getOPEndByPrimary($courseLimitPrimary);
            } else {
                $optHayaDate = null;
                $optEndDate  = null;
            }
            $data['optHayaDate'] = $optHayaDate;
            $data['optEndDate']  = $optEndDate;
            // 20170406 add by Vien end

            // 支払いデーターがあるかどうかチェックプラグ
            $isExistTotalFeeFlg = $this->isTotalFeeExistFlg($data['participantInfo'] , $data['optionals']);
            $data['isExistTotalFeeFlg'] = $isExistTotalFeeFlg;
            $timePeriod = $this->getPaymentTimePeriod($StaffInfo);
            $data['timePeriod'] = $timePeriod;
            // 2017/04/02 add payment start
            $paymentData = $this->admin_edit_mo->getPaymentDataByStaffId($staff_id);
            $data['payment'] = $paymentData;
            $totalPayment = $this->getTotalPayment($staff_id);
            $totalFee = $this->getTotalFee($data['participantInfo'] , $data['optionals']);
            $data['balance'] = $totalFee - $totalPayment;
            // 20170402 add payment end

            //国内交通　マスタ取得
            $M011_TransArr = array(
                "M011_Dest_Kbn"=>$StaffInfo['R00_Dest_Kbn'],
                "M011_Dest_Code"=>$StaffInfo['R00_Dest_Code'],
                "M011_Han"=>$StaffInfo['R00_Han'],
                "M011_Dep_Id"=>$StaffInfo['R00_Dep_Id'],
                "M011_Air_Program"=>$StaffInfo['R00_Air_Program']
            );
            $data['transport_master'] = $this->common_mo->getTransportPtn($M011_TransArr );
            foreach($data['transport_master'] as $key => $val){
                $data['transport_master'][$key]->Transport_Date = $this->convert_format->ChangeJpDay($val->Transport_Date);
            }
            //ホテル前泊取得
            $data['Hotel_Reserve_Before'] = $this->hotel_mo->getR09_Hotel_Reserve($staff_id, 1);
			$data['Hotel_Reserve_After'] = $this->hotel_mo->getR09_Hotel_Reserve($staff_id, 2);
			$BeforeArr['R09_ReserveId'] = $staff_id; 
			$BeforeArr['R09_Type'] = 1; 
			$AfterArr['R09_ReserveId'] = $staff_id;
			$AfterArr['R09_Type'] = 2;
			$data['BeforeTotal'] = $this->operating_mo->getHotelTotal($BeforeArr);
			$data['AfterTotal']  = $this->operating_mo->getHotelTotal($AfterArr);			
            //前泊者名取得
            foreach($data['participantInfo'] as $key=>$val){
                if($val['R01_Before_Stay_Hotel']==1){
                    $BeforeStay1Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                } elseif ($val['R01_Before_Stay_Hotel']==2){
                    $BeforeStay2Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                } elseif ($val['R01_Before_Stay_Hotel']==3){
                    $BeforeStay3Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                }
            }
            //後泊者名取得
            foreach($data['participantInfo'] as $key=>$val){
                if ($val['R01_After_Stay_Hotel']==1){
                    $AfterStay1Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                } elseif ($val['R01_After_Stay_Hotel']==2){
                    $AfterStay2Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                } elseif ($val['R01_After_Stay_Hotel']==3){
                    $AfterStay3Name .= $val['R01_Sei']."　".$val['R01_Name'].",";
                }
            }
            $data['BeforeStay1Name'] = $BeforeStay1Name;
            $data['BeforeStay2Name'] = $BeforeStay2Name;
            $data['BeforeStay3Name'] = $BeforeStay3Name;
            $data['AfterStay1Name']  = $AfterStay1Name;
            $data['AfterStay2Name']  = $AfterStay2Name;
            $data['AfterStay3Name']  = $AfterStay3Name;
            //別便で手配往路
            $data['R07_Transport'] = $this->transport_ptn_mo->getTransportDep($StaffInfo['R00_Id']);
            //M20マスタを取得ための配列キー変更
            $M20Arr = $this->convert_format->ChangeArrKey($R04_data_arr, 'R04', 'M20');
            $data['M20_Course_Event'] = $this->anni_event_mo->getMCourseEvent($M20Arr,$staff_id);
            //var_dump($data['M20_Course_Event']);
            $this->load->view('head_vi');
            $this->load->view('user_top_vi', $data);
            return;
        }
    }
    private function convertPrimaryCourseTodo($CourseArr , $newStr) {
        $newPrimary = array();
        if ($CourseArr != null) {
            foreach ($CourseArr as $key => $course) {
                if ($key == 'R00_Dest_Kbn') {
                    $newKey = 'R00_Dest_kbn';
                } else {
                    $newKey = $key;
                }
                $changeKey = str_replace('R00', 'M02', $newKey);
                $newPrimary[$changeKey] = $course;
            }
            return $newPrimary;
        } else {
            return null;
        }
    }

    private function convertPrimaryLimitSet($CourseArr , $newStr) {
        $newPrimary = array();
        if ($CourseArr != null) {
            foreach ($CourseArr as $key => $course) {
                if ($key == 'R00_Dest_Kbn') {
                    $newKey = 'R00_Dest_kbn';
                } else {
                    $newKey = $key;
                }
                $changeKey = str_replace('R00', 'M18', $newKey);
                $newPrimary[$changeKey] = $course;
            }
            $newPrimary['M18_SubSystem_ID'] = '60';
            $newPrimary['M18_Seq'] = 1;
            return $newPrimary;
        } else {
            return null;
        }
    }

    private function getTotalPayment($staffId) {
        $paymentData = $this->admin_edit_mo->getPaymentDataByStaffId($staffId);
        $totalPayment = 0;
        if ($paymentData != null) {
            foreach ($paymentData as $payment) {
                $totalPayment += $payment['R13_Payment_Cost'];
            }
        }
        return $totalPayment;
    }
    private function getTotalFee($participantInfo , $optionals) {
        // get sum_cost
        $sum_cost = 0;
        for($i = 2; $i <= 5; $i ++) {
            foreach ( $participantInfo as $key_no => $CostInfo ) {
                $R01_Cost_Name = 'R01_Cost_Name' . $i;
                $R01_Cost = 'R01_Cost' . $i;
                if ($CostInfo[$R01_Cost] != '0' || $CostInfo[$R01_Cost_Name] = "" || $CostInfo[$R01_Cost] != null) {
                    $data_flag = true;
                    $sum_cost += $CostInfo[$R01_Cost];
                }
            }
        }
        // get sumEsta_cost
        $sumEsta_cost = 0;
        $cost = 0;
        foreach ( $participantInfo as $key_no => $CostInfo ) {
            if ($CostInfo['R01_Cost_Name1'] != '' || $CostInfo['R01_Cost_Name1'] != null) {
                $cost = $CostInfo['R01_Cost1'];
                $sumEsta_cost += $cost;
                $data_flag = true;
            }
        }
        // get optional_total
        $optional_total = 0;
        if (!empty($optionals)) {
            $data_flag = true;
            $optional_total = 0;
            foreach ( $optionals as $optional_key => $optional ) {
                if ($optional['R04_STS'] != '6' && $optional['R04_STS'] != '1') {
                    if ($optional['R04_STS'] == '7') {
                        $optional_total += $optional['R04_Cancel_Cost'];
                    } else {
                        $optional_total += $optional['R04_Tour_Jpy'];
                    }
                }
            }
        }
        $total = $sum_cost + $sumEsta_cost + $optional_total;
        return $total;
    }

    /**
     * 御支払合計金額
     * @param unknown $participantInfo
     * @param unknown $optionals
     */
    private function isTotalFeeExistFlg($participantInfo , $optionals) {
        $data_flag = false;
        // get sum_cost
        $sum_cost = 0;
        for($i = 2; $i <= 5; $i ++) {
            foreach ( $participantInfo as $key_no => $CostInfo ) {
                $R01_Cost_Name = 'R01_Cost_Name' . $i;
                $R01_Cost = 'R01_Cost' . $i;
                if ($CostInfo[$R01_Cost] != '0' || $CostInfo[$R01_Cost_Name] = "" || $CostInfo[$R01_Cost] != null) {
                    $data_flag = true;
                    $sum_cost += $CostInfo[$R01_Cost];
                }
            }
        }
        // get sumEsta_cost
        $sumEsta_cost = 0;
        $cost = 0;
        foreach ( $participantInfo as $key_no => $CostInfo ) {
            if ($CostInfo['R01_Cost_Name1'] != '' || $CostInfo['R01_Cost_Name1'] != null) {
                $cost = $CostInfo['R01_Cost1'];
                $sumEsta_cost += $cost;
                $data_flag = true;
            }
        }
        // get optional_total
        $optional_total = 0;
        if (!empty($optionals)) {
            $data_flag = true;
            $optional_total = 0;
            foreach ( $optionals as $optional_key => $optional ) {
                $optional_total += $optional['R04_Tour_Jpy'];
            }
        }
        $total = $sum_cost + $sumEsta_cost + $optional_total;

        if ($total == 0) {
            $data_flag = false;
        }

        if ($data_flag == true) {
            return 1; // 支払ボターン出す
        } else {
            return 2; // 支払ボターン出さない
        }
    }

    private function getCoursePrimaryByStaffInfo($staffInfo) {
        $coursePrimary = array();
        if ($staffInfo != null) {
            $coursePrimary = array(
                    'M01_Dest_Kbn' => $staffInfo['R00_Dest_Kbn'],
                    'M01_Dest_Code' => $staffInfo['R00_Dest_Code'],
                    'M01_Han' => $staffInfo['R00_Han'],
                    'M01_Dep_Id' => $staffInfo['R00_Dep_Id'],
                    'M01_Air_Program' => $staffInfo['R00_Air_Program'],
            );
        }
        return $coursePrimary;
    }

    private function getPaymentTimePeriod($staffInfo) {
        $coursePrimary = $this->getCoursePrimaryByStaffInfo($staffInfo);

        if ($coursePrimary != null ) {
            $timePeriod = $this->user_top_mo->getTimePeriodByCourse($coursePrimary);
            return $timePeriod;
        }
        return null;
    }

    /**
     * パスポート変更画面
     */
    function edit_pass() {
        //セクションからユーザID　取得
        $staffId = $this->session->userdata('R00_Id');
        if ($staffId == '' || $staffId == null) {
            // セッションがなくなった場合はログインページに移動する
            redirect(base_url('login_con/logout'));
            return;
        } else {
            // 初期化
            $data      = array();
            $user_id   = !empty($_POST['user_id'])?$_POST['user_id']:0; // R01_Id
            $user_plan = !empty($_POST['user_plan'])?$_POST['user_plan']:0; // R01_Plan

            $data['participantInfo'] = $this->user_top_mo->getParticipantInfoByIdAndPlan( $user_id , $user_plan);
            $this->load->view('edit_pass_vi', $data);
            return;
        }
    }

    public function saveFile() {
        $user_id = $_POST['user_id'];
        $user_plan = $_POST['user_plan'];
        if (isset($_FILES["R01_PassportImg_File"])) {
            if($_FILES["R01_PassportImg_File"]["name"] != ""){
                $maxFileSize = 10 * 1000 * 1000; //MB
                if($_FILES["R01_PassportImg_File"]["size"] > ($maxFileSize * 1000 * 1000)) {
                    echo "(ERR)Size error";
                } else {
                    $filename = stripslashes($_FILES["R01_PassportImg_File"]["name"]);
                    $extension = $this->getExtension($filename);
                    $extension = strtolower($extension);
                    // check extension
                    if ( ($extension != "jpg")  &&
                         ($extension != "jpeg") &&
                         ($extension != "png")  &&
                         ($extension != "gif")  &&
                         ($extension != "pdf")  &&
                         ($extension != "BMP")
                       ){
                        echo "(ERR)アップロードファイルはJPG/JPEG/GIF/PNG/BMP/PDFでご用意ください。" ;
                    } else {
                        // move to folder
                        $attach_file = '';
                        $uploadDir = "pass_img/";
                        $date = date("YmdHis");

                        $file_name = $_FILES["R01_PassportImg_File"]["name"];
                        $attach_file = $date.'_' . $user_id . '_' . $user_plan . '_' .$file_name; // データーベースにattach_file形は「YYYYmmddHHiissFILENAME」というタイプを保存する
                        $full_path = $uploadDir.$attach_file;

                        move_uploaded_file($_FILES["R01_PassportImg_File"]["tmp_name"] , $full_path);
                        $param = array(
                            "R01_Id"   => $user_id,
                            "R01_Plan" => $user_plan,
                            "R01_PassportImg" => $attach_file,
                            "R01_Passpost_Upload_Flag" => 1
                        );
                        $this->user_top_mo->updatePasspost($param);
                        echo $attach_file;
                    }
                }
            } else {
                echo "(ERR)アップロードファイルを選んでください！";
            }
        } else {
            echo "(ERR)アップロードファイルを選んでください！";
        }
    }

    public function getExtension($str) {
        $i = strrpos($str,".");
        if (!$i) {
            return "";
        }
        $l = strlen($str) - $i;
        $ext = substr($str,$i+1,$l);
        return $ext;
    }

    public function getImageConfirm() {
        $data['file_name'] = $_POST['file_name'];
        $this->load->view('passport_img_confirm_vi' , $data);

    }

    /*
     ESTA変更画面
     */
    function edit_esta() {
        $R00_Id = $this->session->userdata('R00_Id');
        $user_plan = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        if ($R00_Id != '' || $R00_Id != null) {
            $ESTA_result  = $this->user_top_mo->getEsta($R00_Id, $user_plan);
            $data['esta'] = $ESTA_result;
            $data['R00_Id'] = $R00_Id;
            $data['user_plan'] = $user_plan;
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
            //Visa 査証情報を取得
            $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
			
			$data['course'] =  $data['kakuteiInfo']['M01_Dep_Date'];
            $Visainfo = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
            $data['Visa_Arr'] = $this->user_top_mo->getVisaArrbyDestCode($Visainfo);
            $this->load->view('edit_esta_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *
    *ESTA データ作成
    */
    public function EstaCreate(){
        $R00_Id = $this->session->userdata('R00_Id');
        $data['R01_Plan'] = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $params = array(
                "R06_Id"              => $this->input->post('R06_Id'),
                "R06_Id_Seq"          => $this->input->post('R06_Id_Seq'),
                "R06_Esta_Have"       => $this->input->post('R06_Esta_Have'),
                "R06_Esta_Exp_Yr"     => $this->input->post('R06_Esta_Exp_Yr'),
                "R06_Esta_Exp_M"      => $this->input->post('R06_Esta_Exp_M'),
                "R06_Esta_Exp_Day"   => $this->input->post('R06_Esta_Exp_Day'),
                "R06_Esta_Register"  => $this->input->post('R06_Esta_Register')
            );
            $result  = $this->user_top_mo->getEsta($params['R06_Id'], $params['R06_Id_Seq']);
            if($params['R06_Esta_Have'] == "1"){

                $data = array(
                    "R01_Id"            => $this->input->post('R06_Id'),
                    "R01_Plan"          => $this->input->post('R06_Id_Seq'),
                    "R01_Cost_Name1"    => "",
                    "R01_Cost1"         => "0",
                    "R01_UpdateTime" =>$today
                );

                $result_visa = $this->user_top_mo->updVisainfo($data);

            }


            if($result == NULL){
                //insert
                $result_cnt = $this->user_top_mo->setEsta($params);
            }else{
                //update
                $result_cnt = $this->user_top_mo->updEsta($params);

            }

            //if($result_cnt >0){
                echo 'success';
            //}else{
            //  echo 'error';
            //}
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *
    *
    */
    public function EstaCreateWithAns(){
        $today = date('Y-m-d H:i:s', time());
        unset( $_POST['register'] );

        $result  = $this->user_top_mo->getEsta($_POST['R06_Id'], $_POST['R06_Id_Seq']);
        if(isset($_POST['R06_CitizenElse_Expire_Yr']) && isset($_POST['R06_CitizenElse_Expire_Yr']) && isset($_POST['R06_CitizenElse_Expire_Yr'])){
            $_POST['R06_CitizenElse_Expire'] = $_POST['R06_CitizenElse_Expire_Yr'].'-'.$_POST['R06_CitizenElse_Expire_Month'].'-'.$_POST['R06_CitizenElse_Expire_Day'];
            unset( $_POST['R06_CitizenElse_Expire_Yr'] );
            unset( $_POST['R06_CitizenElse_Expire_Month'] );
            unset( $_POST['R06_CitizenElse_Expire_Day'] );
        }
        if(isset($_POST['kiyaku1'])){
            unset( $_POST['kiyaku1'] );
        }
        if(isset($_POST['kiyaku2'])){
            unset( $_POST['kiyaku2'] );
        }
        $_POST['Update'] = $today;
        if($_POST['R06_Esta_Register'] == "2"){

                $data = array(
                    "R01_Id"            => $this->input->post('R06_Id'),
                    "R01_Plan"          => $this->input->post('R06_Id_Seq'),
                    "R01_Cost_Name1"    => $this->input->post('R01_Cost_Name'),
                    "R01_Cost1"         => $this->input->post('R01_Cost'),
                    "R01_UpdateTime" =>$today
                );

                $result_visa = $this->user_top_mo->updVisainfo($data);
            }elseif($_POST['R06_Esta_Register'] == "1"){
                $data = array(
                    "R01_Id"            => $this->input->post('R06_Id'),
                    "R01_Plan"          => $this->input->post('R06_Id_Seq'),
                    "R01_Cost_Name1"    => null,
                    "R01_Cost1"         => "0",
                    "R01_UpdateTime" =>$today
                );

                $result_visa = $this->user_top_mo->updVisainfo($data);

            }
        unset( $_POST['R01_Cost_Name'] );
        unset( $_POST['R01_Cost'] );
        if($result == NULL){
            //insert
            $result_cnt = $this->user_top_mo->setEsta($_POST);
        }else{
            //update
            $result_cnt = $this->user_top_mo->updEsta($_POST);
        }

        redirect(base_url('user_top_con'));
    }
    //決定方面
    public function process() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            $data['M01_Course'] = $this->getM01_CourseFunc();
            $this->load->view('head_vi');
            $this->load->view('process_vi', $data);
            return;
        }
    }
    //代表者情報変更
     function reserve_edit() {
        //セクションからユーザID　取得
         $staff_id = $this->session->userdata('R00_Id');
        if ($staff_id != '' || $staff_id != null) {
           //参加者の情報を取得
            $data['staffInfo']         = $this->user_top_mo->getStaffInfo($staff_id);

            $this->load->view('reserve_edit_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    //、参加者情報変更
     function traveler_edit() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
           //参加者の情報を取得
            $data['participantInfo'] = $this->user_top_mo->getUserInfo($R00_Id);

            $this->load->view('traveler_edit_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    //連絡先等情報変更
    function mypage_edit() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            //$this->load->view('login_vi');
            //return;
            //demo20161111
            $data['emergency_info'] = $this->mypage_mo->getEmergenctDataById($R00_Id);
            $data['sendplace_info'] = $this->user_top_mo->getSendPlace();
            $data['traveler_info'] = $this->user_top_mo->getAdress_Jitaku($R00_Id);

            $this->load->view('mypage_edit_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }


    //ホテル案内
    //オプショナルツアー
    function optional() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
             // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('optional_test_vi', $data);

            return;
        }
    }
    function optional_entry() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            //$this->load->view('login_vi');
            //return;
            //demo20161111
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('optional_entry_vi', $data);

            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('optional_entry_vi', $data);

            return;
        }
    }
    function optional_confirm() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            //$this->load->view('login_vi');
            //return;
            //demo20161111
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('optional_confirm_vi', $data);

            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('optional_confirm_vi', $data);

            return;
        }
    }
    //コース変更・取
    function corse() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
             // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            $StaffInfo = $this->user_top_mo->getStaffInfo($R00_Id);
            $M02Arr = array(
                "R00_Dest_Kbn"    => $StaffInfo['R00_Dest_Kbn'],
                "R00_Dest_Code"   => $StaffInfo['R00_Dest_Code'],
                "R00_Han"         => $StaffInfo['R00_Han'],
                "R00_Dep_Id"      => $StaffInfo['R00_Dep_Id'],
                "R00_Air_Program" => $StaffInfo['R00_Air_Program']
            );

            $data['CourseTodoInfo'] = $this->user_top_mo->getCourseTodoById($M02Arr);
            $this->load->view('head_vi');
            $this->load->view('corse_vi', $data);
            return;
        }
    }
    //現地情報
    function local_info() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            $data['M01_Course'] = $this->getM01_CourseFunc();
            $this->load->view('head_vi');
            $this->load->view('local_info_vi', $data);
            return;
        }
    }
    //行程表画面
    function schedule() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            //セクションユーザID　と　全員のデータを取得
            $staff_info = $this->user_top_mo->getStaffInfo($R00_Id);
            $Course_Schedule_Arr = array(
                "M03_Dest_Kbn"=> $staff_info['R00_Dest_Kbn'],
                "M03_Dest_Code"=> $staff_info['R00_Dest_Code'],
                "M03_Han"=> $staff_info['R00_Han'],
                "M03_Dep_Id"=> $staff_info['R00_Dep_Id'],
                "M03_Air_Program"=> $staff_info['R00_Air_Program']
            );
            $Course_Arr = $this->getM01_CourseArr($staff_info);
            $M01_Course = $this->course_mo->getM01_Course($Course_Arr);
            $data['M01_Course'] = $M01_Course[0];
            /*日ごとの行程数を数える*/
            $CountScheduleDay        =  $this->course_mo->getScheduleDayCnt($Course_Schedule_Arr);
            /*Schedule なしの場合*/
            if(count($CountScheduleDay)>0){
                for($i = 0;$i < count($CountScheduleDay);$i++){
                    $j =$i+1;
                    $Course_Schedule_Arr['M03_Ryotei_Day'] = $j;
                    $M03_Course_ScheduleArr[$i]  = $CountScheduleDay[$i];
                    $M03_Course_ScheduleArr[$i]['Schedule']  = $this->course_mo->getCourseScheduleById($Course_Schedule_Arr);
                }
                $data['Course_ScheduleArr'] = $M03_Course_ScheduleArr;
            }else{
                $data['Course_ScheduleArr'] = NULL;
            }
            $this->load->view('head_vi');
            $this->load->view('schedule_vi', $data);
            return;
        }
    }
    //ホテル案内
    function hotel() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['M01_Course'] = $this->getM01_CourseFunc();
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('hotel_vi', $data);
            return;
        }
    }
    //国内交通情報 overlay
    function edit_transport() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data = $this->TransportCommon($R00_Id);
            $this->load->view('edit_transport_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *マイページ用
    */
    function transport() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data = $this->TransportCommon($R00_Id);
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('transport_vi', $data);
            return;
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *
    *国内交通更新
    */
    function update_transport(){
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $data['course_master']  = $this->getM01_CourseFunc();
            $Traveler = $_POST['Traveler'];
            //参加者の国内交通データの格納
            foreach($Traveler as $traKey => $traVal){
                $traVal['R01_Id'] = $R00_Id;
                $result = $this->transport_ptn_mo->setTranportPtn($traVal);
                if ($traVal['R01_Departure_Ptn'] != 1 && $traVal['R01_Departure_Ptn'] != 2){

                }
            }

            for($i=0;$i<2;$i++){
                $j=$i+1;
                $departure = $_POST['departure'.$j];
                foreach($departure as $depKey => $depVal){
                    $depVal['R07_Transport_Sequence'] =$depKey+1;
                    $depVal['R07_Transport_No'] = $j;
                    $depVal['R07_Transport_Type'] =1;
                    $depVal['R07_ReserveId']      = $R00_Id;

                    $Tranport = $this->transport_ptn_mo->getTranportlDataInTraveler(1,$R00_Id,$j);

                    if($Tranport == null){
                        $depVal['R07_Transport_Date']      = $data['course_master']['M01_Dep_Date'];
                        $depVal['R07_Transport_Place']      = "";
                        $depVal['R07_Transport_Dep_Time']      = "";
                        $depVal['R07_Transport_Name']      = "";
                        $depVal['R07_Transport_Arr_Place']      = "";
                        $depVal['R07_Transport_Arr_Time']      = "";
                        $depVal['R07_Note']      = "";
                    }



                    $this->transport_ptn_mo->setTranport($depVal);
                }

                $arrival = $_POST['arrival'.$j];
                foreach($arrival as $arrKey => $arrVal){
                    $arrVal['R07_Transport_Sequence'] =$arrKey+1;
                    $arrVal['R07_Transport_No'] = $j;
                    $arrVal['R07_Transport_Type'] =2;
                    $arrVal['R07_ReserveId']      = $R00_Id;
                    $Tranport = $this->transport_ptn_mo->getTranportlDataInTraveler(2,$R00_Id,$j);

                    if($Tranport == null){
                        $arrVal['R07_Transport_Date']      = $data['course_master']['M01_Arr_Date'];
                        $arrVal['R07_Transport_Place']      = "";
                        $arrVal['R07_Transport_Dep_Time']      = "";
                        $arrVal['R07_Transport_Name']      = "";
                        $arrVal['R07_Transport_Arr_Place']      = "";
                        $arrVal['R07_Transport_Arr_Time']      = "";
                        $arrVal['R07_Note']      = "";
                    }
                    $this->transport_ptn_mo->setTranport($arrVal);
                }
            }
             redirect(base_url('user_top_con'));
        } else {
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    //前泊 メーニュ用
    function hotel_before(){
        $data = $this->hotel_common(1);
        $data['user_name'] = $this->getUserName();
        $this->load->view('head_vi');
        $this->load->view('hotel_before_vi', $data);
        return;
    }
    //前泊
    function edit_hotel_before() {
        $data = $this->hotel_common(1);
        $this->load->view('edit_hotel_before_vi', $data);
        return;
    }
    function upd_hotel_before() {
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        //ページ移動の為値取得
        if(isset($_POST['process'])){
            $process = $_POST['process'];
        }
        unset($_POST['process']);

        $Reserve       = $_POST['Reserve'];
        //R01_Reserve保存
        foreach($Reserve as $ReserveKey=>$ReserveVal){
            $ReserveVal['R01_Id'] = $R00_Id;
            $ReserveVal['R01_UpdateTime'] = $today;

            if(!isset($ReserveVal['R01_Before_Stay_Hotel'])){
                $ReserveVal['R01_Before_Stay_Hotel'] = NULL;
            }
            //var_dump($ReserveVal);
            //exit;
                $this->hotel_mo->setHotelDataInTraveler($ReserveVal);

        }
        $params["R00_Id"] = $R00_Id;
        $params["R00_Zenhaku_Flag"] =  1;
        $params["Update"] =  $today;
        $this->hotel_mo->setHotelDataInResever($params);
        $data = $this->upd_hotel_common($_POST, 1);
        if($process == 'view'){
            redirect(base_url('user_top_con/hotel_before'));
        }else{
            redirect(base_url('user_top_con'));
        }
        return;
    }
     //後泊 メーニュ用
    function hotel_after(){
        $data = $this->hotel_common(2);
        $data['user_name'] = $this->getUserName();
        $this->load->view('head_vi');
        $this->load->view('hotel_after_vi', $data);
        return;
    }
    //後泊
    function edit_hotel_after() {
        //セクションからユーザID　取得
        $data = $this->hotel_common(2);
        $this->load->view('edit_hotel_after_vi', $data);
        return;
    }
    public function upd_hotel_After(){
        //ページ移動の為値取得
        if(isset($_POST['process'])){
            $process = $_POST['process'];
        }

        unset($_POST['process']);
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        $Reserve       = $_POST['Reserve'];
        //R01_Reserve保存
        foreach($Reserve as $ReserveKey=>$ReserveVal){
            $ReserveVal['R01_Id'] = $R00_Id;
            $ReserveVal['R01_UpdateTime'] = $today;
            if(!isset($ReserveVal['R01_After_Stay_Hotel'])){
                $ReserveVal['R01_After_Stay_Hotel'] = NULL;
            }
                $this->hotel_mo->setHotelDataInTraveler($ReserveVal);

        }
        $params["R00_Id"] = $R00_Id;
        $params["R00_Kouhaku_Flag"] =  1;
        $params["Update"] =  $today;
        $this->hotel_mo->setHotelDataInResever($params);
        $data = $this->upd_hotel_common($_POST, 2);
        if($process == 'view'){
            redirect(base_url('user_top_con/hotel_after'));
        }else{
            redirect(base_url('user_top_con'));
        }
        return;
    }

    function transport_edit_confirm() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('transport_edit_confirm_vi', $data);
            return;
        }
    }
    //50周年イベント参加
    function edit_event() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('edit_event_vi', $data);
            return;
        }
    }
    function event_edit_confirm() {
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['user_info'] = $this->user_top_mo->getUserInfo($R00_Id);
            $this->load->view('head_vi');
            $this->load->view('event_edit_confirm_vi', $data);

            return;
        }
    }
    /*
    *entry ページ処理
    *
    */
    public function entry() {
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $user_info = $this->user_top_mo->getStaffInfo($R00_Id);
            $kibouCourse = array(
                "R00_kibou1" => $user_info['R00_kibou1'],
                "R00_kibou2" => $user_info['R00_kibou2'],
                "R00_kibou3" => $user_info['R00_kibou3'],
                );
            $data['kibouStatus1'] = $this->user_top_mo->getkibouStatus($kibouCourse['R00_kibou1']);
            $data['kibouStatus2'] = $this->user_top_mo->getkibouStatus($kibouCourse['R00_kibou2']);
            $data['kibouStatus3'] = $this->user_top_mo->getkibouStatus($kibouCourse['R00_kibou3']);
            $data['user_info'] = $this->user_top_mo->getStaffInfo($R00_Id);
            $data['course_data'] = $this->user_top_mo->getCourseData();
            $data['kibouCourse'] = $kibouCourse;
            $this->load->view('head_vi');
            $this->load->view('entry_vi', $data);

            return;
        }
    }

    /*
    *
    *   パスポート更新
    */
    public function updatePasspost(){
        $today = date('Y-m-d H:i:s', time());
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {

            $params = array(
                "R01_Id"                    => $this->input->post('R01_Id'),
                "R01_Plan"                  => $this->input->post('R01_Plan'),
                "R01_Passport_No"           => $this->input->post('R01_Passport_No'),
                "R01_Passport_Sei"          => $this->input->post('R01_Passport_Sei'),
                "R01_Passport_Name"         => $this->input->post('R01_Passport_Name'),
                "R01_Passport_Middle"       => $this->input->post('R01_Passport_Middle'),
                "R01_Passport_Expire"       => $this->input->post('R01_Passport_Expire_Year').'-'.$this->input->post('R01_Passport_Expire_Month').'-'.$this->input->post('R01_Passport_Expire_Date'),
                "R01_UpdateTime"            => $today
            );
            $updateResult = $this->user_top_mo->updatePasspost($params);
            if($updateResult > 0){
                echo "success";
            }else{
                echo "error";
            }
        }
    }

    /*
    *
    *   緊急連絡先更新
    */
    public function updateEmergencyInfo(){
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $params = array(
                "R00_Id"             => $R00_Id,
                "R00_emargency_mei"  => $this->input->post('R00_emargency_mei'),
                "R00_emargency_zoku" => $this->input->post('R00_emargency_zoku'),
                "R00_emargency_tel"  => $this->input->post('R00_emargency_tel'),
                "R00_allergy_Note"   => $this->input->post('R00_allergy_Note'),
                "R00_SendPlace"      => $this->input->post('R00_SendPlace'),
                "R00_Document_Atena"     => $this->input->post('R00_Document_Atena')

            );

            $updateResult = $this->user_top_mo->updateEmergency($params);
            //会社
            if($params['R00_SendPlace'] == 2){
                $data['R00_Id'] = $R00_Id;
                $data['R00_Company_Post1']  = $this->input->post('R00_Document_Post1');
                $data['R00_Company_Post2'] = $this->input->post('R00_Document_Post2');
                $data['R00_Company_Pref']  = $this->input->post('R00_Document_Pref');
                $data['R00_Company_Address1']    = $this->input->post('R00_Document_Addr1');
                $data['R00_Company_Address2']    = $this->input->post('R00_Document_Addr2');
                $updatePlace = $this->user_top_mo->updateAdressCompany($data);

            }

            //その他
            if($params['R00_SendPlace'] == 9){
                $data['R00_Id'] = $R00_Id;
                $data['R00_Document_Post1']  = $this->input->post('R00_Document_Post1');
                $data['R00_Document_Post2'] = $this->input->post('R00_Document_Post2');
                $data['R00_Document_Pref']  = $this->input->post('R00_Document_Pref');
                $data['R00_Document_Addr1']      = $this->input->post('R00_Document_Addr1');
                $data['R00_Document_Addr2']      = $this->input->post('R00_Document_Addr2');
                $updatePlace = $this->user_top_mo->updateAdressCompany($data);
            }
            //自宅
            if($params['R00_SendPlace'] == 1){
                $data['R01_Id'] = $R00_Id;
                $data['R01_Post1']  = $this->input->post('R00_Document_Post1');
                $data['R01_Post2'] = $this->input->post('R00_Document_Post2');
                $data['R01_Address_Pref']  = $this->input->post('R00_Document_Pref');
                $data['R01_Address1']    = $this->input->post('R00_Document_Addr1');
                $data['R01_Address2']    = $this->input->post('R00_Document_Addr2');
                $updatePlace = $this->user_top_mo->updateAdressCompany_Travel($data);
            }

            if($updateResult > 0){
                echo 'success';
            }else{
                echo 'error';
            }
        } else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *
    *50周年イベント参加
    */
    public function anni_event(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $user_id = $this->input->post('user_id');
            $StaffInfo = $this->user_top_mo->getStaffInfo($user_id);
            $M20Arr = array(
                "M20_Dest_Kbn"    => $StaffInfo['R00_Dest_Kbn'],
                "M20_Dest_Code"   => $StaffInfo['R00_Dest_Code'],
                "M20_Han"         => $StaffInfo['R00_Han'],
                "M20_Dep_Id"      => $StaffInfo['R00_Dep_Id'],
                "M20_Air_Program" => $StaffInfo['R00_Air_Program']
            );
            $M01Arr = array(
                "R00_Dest_Kbn"    => $StaffInfo['R00_Dest_Kbn'],
                "R00_Dest_Code"   => $StaffInfo['R00_Dest_Code'],
                "R00_Han"         => $StaffInfo['R00_Han'],
                "R00_Dep_Id"      => $StaffInfo['R00_Dep_Id'],
                "R00_Air_Program" => $StaffInfo['R00_Air_Program']
            );
            $M20_result = $this->anni_event_mo->getMCourseEvent($M20Arr,$R00_Id);
            $data['StaffInfo'] = $StaffInfo;
            $data['M01_result'] = $this->user_top_mo->getKakuteCourseById($M01Arr);
            $data['M20_result'] = $M20_result;
            $this->load->view('anni_event_vi', $data);
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }

    }
    /*
    *50周年イベント参加更新
    *
    */
    public function updateAnni(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $R08_Course_Event = $this->input->post('R08_Course_Event_Reserve');
            foreach ($R08_Course_Event as $key=>$val){
                $this->anni_event_mo->set_Course_Event_Reserve($val);
            }
            redirect(base_url('user_top_con'));

        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *Ｑ＆Ａ
    */
    public function qa(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('qa_vi', $data);
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *お問い合わせ
    */
    public function contact(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('contact_vi', $data);
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *
    *コース別参加者数一覧表
    */
    public function course_ta(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('course_ta_vi', $data);
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *
    *ダウンロート
    */
    public function download(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data['user_name'] = $this->getUserName();
            $this->load->view('head_vi');
            $this->load->view('download_vi', $data);
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *カナダETA
    *
    */
    public function CanadaForm(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $this->load->view('canada_eta_entry_vi');
        } else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *オーストラリアETA
    *
    */
    public function AustraliaForm(){
        $R00_Id = $this->session->userdata('R00_Id');
        $user_plan = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        if ($R00_Id != '' || $R00_Id != null) {
            $ETAS_result  = $this->user_top_mo->getEtas($R00_Id, $user_plan);
            $data['etas'] = $ETAS_result;
            $data['R00_Id'] = $R00_Id;
            $data['user_plan'] = $user_plan;
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
            //Visa 査証情報を取得
            $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
            $Visainfo = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
            $data['Visa_Arr'] = $this->user_top_mo->getVisaArrbyDestCode($Visainfo);
			$data['course'] =  $data['kakuteiInfo']['M01_Dep_Date'];
            $this->load->view('australia_eta_entry_vi', $data);
            return;
        } else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    *
    *ETASデータ作成
    */
    public function EtasCreate(){
        $R00_Id = $this->session->userdata('R00_Id');
        $data['R01_Plan'] = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];

        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $params = array(
                "R10_Id"              => $this->input->post('R10_Id'),
                "R10_Seq"         => $this->input->post('R10_Seq'),
                "R10_Etas_Have"       => $this->input->post('R10_Etas_Have'),
                "R10_Etas_Exp_Yr"     => $this->input->post('R10_Etas_Exp_Yr'),
                "R10_Etas_Exp_M"      => $this->input->post('R10_Etas_Exp_M'),
                "R10_Etas_Exp_Day"   => $this->input->post('R10_Etas_Exp_Day'),
                //"R10_Etas_Register"  => $this->input->post('R10_Etas_Register'),
                "R10_Create_Date" =>$today
            );
            $result  = $this->user_top_mo->getEtas($params['R10_Id'], $params['R10_Seq']);


                $data = array(
                    "R01_Id"            => $this->input->post('R10_Id'),
                    "R01_Plan"          => $this->input->post('R10_Seq'),
                    "R01_Cost_Name1"    => null,
                    "R01_Cost1"         => "0",
                    "R01_UpdateTime" =>$today
                );

                $result_visa = $this->user_top_mo->updVisainfo($data);



            if($result == NULL){
                //insert
                $result_cnt = $this->user_top_mo->setEtas($params);
            }else{
                //update
                $result_cnt = $this->user_top_mo->updEtas($params);
            }
            if($result_visa >0){
                echo 'success';
            }else{
                echo 'error';
            }
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    public function EtasCreateWithAns(){
        $today = date('Y-m-d H:i:s', time());
        unset( $_POST['register'] );

        $result  = $this->user_top_mo->getEtas($_POST['R10_Id'], $_POST['R10_Seq']);

        $data = array(
            "R01_Id"            => $this->input->post('R10_Id'),
            "R01_Plan"          => $this->input->post('R10_Seq'),
            "R01_Cost_Name1"    => $this->input->post('R01_Cost_Name'),
            "R01_Cost1"         => $this->input->post('R01_Cost'),
            "R01_UpdateTime" =>$today
        );
        $result_visa = $this->user_top_mo->updVisainfo($data);
        unset( $_POST['R01_Cost_Name'] );
        unset( $_POST['R01_Cost'] );
        if($result == NULL){
            //insert
            $_POST['R10_Create_Date'] = $today;
            $result_cnt = $this->user_top_mo->setEtas($_POST);
        }else{
            //update
            $_POST['R10_Update_Date'] = $today;
            $result_cnt = $this->user_top_mo->updEtas($_POST);
        }

        redirect(base_url('user_top_con'));
    }

    /*
    *グアムETA
    *
    */
    public function GuamForm(){

        $R00_Id = $this->session->userdata('R00_Id');
        $user_plan = ! isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        if ($R00_Id != '' || $R00_Id != null) {
            $CNMI_result  = $this->user_top_mo->getCNMI($R00_Id, $user_plan);
            $data['cnmi'] = $CNMI_result;
            $data['R00_Id'] = $R00_Id;
            $data['user_plan'] = $user_plan;
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
            //Visa 査証情報を取得
            $dest_code = $data['kakuteiInfo']['M01_Dest_Code'];
            $Visainfo = $this->user_top_mo->getVisaInfobyDestCode($dest_code);
            $data['Visa_Arr'] = $this->user_top_mo->getVisaArrbyDestCode($Visainfo);
            $this->load->view('guam_eta_entry_vi', $data);
            return;
        } else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }


    public function CNMICreateWithAns(){
        $today = date('Y-m-d H:i:s', time());

        $result  = $this->user_top_mo->getCNMI($_POST['R11_Id'], $_POST['R11_Seq']);
        $data = array(
            "R01_Id"            => $this->input->post('R11_Id'),
            "R01_Plan"          => $this->input->post('R11_Seq'),
            "R01_Cost_Name1"    => $this->input->post('R01_Cost_Name'),
            "R01_Cost1"         => $this->input->post('R01_Cost'),
            "R01_UpdateTime" =>$today
        );

        $result_visa = $this->user_top_mo->updVisainfo($data);
        if(isset($_POST['R11_CNMI_Issue_Yr']) && isset($_POST['R11_CNMI_Issue_Month']) && isset($_POST['R11_CNMI_Issue_Day'])){
            $_POST['R11_CNMI_Issue'] = $_POST['R11_CNMI_Issue_Yr'].'-'.$_POST['R11_CNMI_Issue_Month'].'-'.$_POST['R11_CNMI_Issue_Day'];
            unset( $_POST['R11_CNMI_Issue_Yr'] );
            unset( $_POST['R11_CNMI_Issue_Month'] );
            unset( $_POST['R11_CNMI_Issue_Day'] );
        }
        unset( $_POST['R01_Cost_Name'] );
        unset( $_POST['R01_Cost'] );
        if($result == NULL){
            //insert
            $_POST['R11_Create_Date'] = $today;
            $result_cnt = $this->user_top_mo->setCNMI($_POST);
        }else{
            //update
            $_POST['R11_Update_Date'] = $today;
            $result_cnt = $this->user_top_mo->updCNMI($_POST);
        }

        redirect(base_url('user_top_con'));
    }

    /*
    * セクションからユーザ名取得
    */
    public function getUserName(){
        $staff_id = $this->session->userdata('R00_Id');
        $user_name = $this->user_top_mo->getUserName($staff_id);
        $data = $user_name;
        return $data;
    }

    /*
    *
    * コース配列作成
    */
    public function getM01_CourseArr($params){
        $Course_Arr = array(
            "M01_Dest_Kbn"=> $params['R00_Dest_Kbn'],
            "M01_Dest_Code"=> $params['R00_Dest_Code'],
            "M01_Han"=> $params['R00_Han'],
            "M01_Dep_Id"=> $params['R00_Dep_Id'],
            "M01_Air_Program"=> $params['R00_Air_Program']
        );
        return $Course_Arr;
    }

    /*
    *コースデータ取得共有function
    */
    public function getM01_CourseFunc(){
        $R00_Id = $this->session->userdata('R00_Id');
        $staff_info = $this->user_top_mo->getStaffInfo($R00_Id);
        $Course_Arr = $this->getM01_CourseArr($staff_info);
        $M01_Course = $this->course_mo->getM01_Course($Course_Arr);
        return $M01_Course[0];
    }
    /*
    * 国内交通共有
    *
    */
    public function TransportCommon($param){
        $data['traveler'] = $this->user_top_mo->getUserInfo($param);
        $StaffInfo = $this->user_top_mo->getStaffInfo($param);
        //国内交通　マスタ取得
        $M011_TransArr = array(
            "M011_Dest_Kbn"=>$StaffInfo['R00_Dest_Kbn'],
            "M011_Dest_Code"=>$StaffInfo['R00_Dest_Code'],
            "M011_Han"=>$StaffInfo['R00_Han'],
            "M011_Dep_Id"=>$StaffInfo['R00_Dep_Id'],
            "M011_Air_Program"=>$StaffInfo['R00_Air_Program']
        );
        $data['transport_master'] = $this->common_mo->getTransportPtn($M011_TransArr);
        $data['course_master']    = $this->getM01_CourseFunc();
        $data['R07_Transport']    = $this->transport_ptn_mo->getTransportDep($param);
        return $data;
    }
    /*
    *ホテル共有
    *
    */
    public function hotel_common($type){
        //$type 1:前泊　2:後泊
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            //セクションユーザID　と　全員のデータを取得
            $data['traveler']  = $this->user_top_mo->getUserInfo($R00_Id);
            $data['course_master']  = $this->getM01_CourseFunc();
            //R09_Hotel_Reserve
            $data['Hotel_Reserve'] = $this->hotel_mo->getR09_Hotel_Reserve($R00_Id, $type);
            return $data;
        }
    }
    /*
    *ホテル情報更新
    *
    */
    public function upd_hotel_common($params, $type){
        //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $Hotel_Reserve = $params['Hotel_Reserve'];
            //R09_Hotel_Reserve保存
            foreach($Hotel_Reserve as $HotelKey=>$HotelVal){
                $HotelVal['R09_ReserveId'] = $R00_Id;
                $HotelVal['R09_Type'] =  $type;
                if(($HotelVal['R09_Hote_Room_Type'] != '') &&($HotelVal['R09_Type'] != '')){
                    $this->hotel_mo->insertHotel_Reserve($HotelVal);
                }
                $data['Hotel_travel'] = $this->hotel_mo->getHotelDataInTraveler($HotelVal);

                //var_dump($data['Hotel_travel']);
                if($data['Hotel_travel'] == NULL){
                    $this->hotel_mo->delHotelHotel_Reserve($HotelVal);
                }

            }
        }
    }
    /*
    *代表者情報更新
    *
    */

    function updateReserveInfo(){
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
        $params = array(
                "R00_Id"            => $R00_Id ,
                "R00_Company"       => $this->input->post('R00_Company'),
                /*"R00_Shiten_Code"         => $this->input->post('R00_Shiten_Code'),
                "R00_Shiten_Name"       => $this->input->post('R00_Shiten_Name'),
                "R00_Syozoku_Code"      => $this->input->post('R00_Syozoku_Code'),
                "R00_Syozoku_Name"      => $this->input->post('R00_Syozoku_Name'),*/
                "R00_Division_Code"         => $this->input->post('R00_Division_Code'),
                "R00_Division"      => $this->input->post('R00_Division'),
                "R00_Company_Post1"         => $this->input->post('R00_Company_Post1'),
                "R00_Company_Post2"         => $this->input->post('R00_Company_Post2'),
                "R00_Company_Pref"      => $this->input->post('R00_Company_Pref'),
                "R00_Company_Address1"      => $this->input->post('R00_Company_Address1'),
                "R00_Company_Address2"      => $this->input->post('R00_Company_Address2'),
                "R00_Company_Tel"       => $this->input->post('R00_Company_Tel'),
                "R00_Division"      => $this->input->post('R00_Division'),
                "R00_Company_Fax"       => $this->input->post('R00_Company_Fax'),
                "R00_Mailaddress"       => $this->input->post('R00_Mailaddress'),
                "Update"            => $today
            );
            $result = $this->user_top_mo->updateEmergency($params);

            redirect(base_url('user_top_con'));

        return;
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *代表者情報更新
    *
    */

    function updateReseverFlag(){
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
        $params = array(
                "R00_Id"            => $R00_Id ,
                "R00_Zenhaku_Flag"      => $this->input->post('R00_Zenhaku_Flag'),
                "R00_Kouhaku_Flag"      => $this->input->post('R00_Kouhaku_Flag'),
                "Update"            => $today
            );

            $HotelFlag['R09_ReserveId'] = $R00_Id;
            $TravelerFlag['R01_Id'] = $R00_Id;
            if($params['R00_Zenhaku_Flag'] == 0 && $params['R00_Kouhaku_Flag'] == NULL){
                $HotelFlag['R09_Type'] = 1;
                $TravelerFlag['R01_Before_Stay_Hotel'] = NULL;
            }elseif($params['R00_Kouhaku_Flag'] == 0 && $params['R00_Zenhaku_Flag'] == NULL){
                $HotelFlag['R09_Type'] = 2;
                $TravelerFlag['R01_After_Stay_Hotel'] = NULL;
            }
            $TravelerFlag['R01_UpdateTime'] = $today;
            $this->hotel_mo->delHotel_byFlagReserve($HotelFlag);
            $this->hotel_mo->delHotel_byFlagTraveler($TravelerFlag);
            if ($params['R00_Zenhaku_Flag'] == null ||$params['R00_Zenhaku_Flag'] == '') {
                unset ($params['R00_Zenhaku_Flag']);
            }elseif($params['R00_Kouhaku_Flag'] == NULL ||$params['R00_Kouhaku_Flag'] == ''){
                unset ($params['R00_Kouhaku_Flag']);
            }

            $updateResult = $this->user_top_mo->updateEmergency($params);

            if($updateResult > 0){
                echo 'success';
            }else{
                echo 'error';
            }

            redirect(base_url('user_top_con'));


        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }
    /*
    *参加者情報更新
    *
    */

    function updateTravelInfo(){
        $R00_Id = $this->session->userdata('R00_Id');
        $today = date('Y-m-d H:i:s', time());
        if ($R00_Id != '' || $R00_Id != null) {
            $Traveler = $_POST['Traveler'];

            //参加者の国内交通データの格納
			//メール送信
			$flag_tag = true;
			foreach($Traveler as $traKey => $item_da){
				$participantInfo = $this->user_top_mo->getUserInfobyPlan($R00_Id,$item_da['R01_Plan']);
				$flag[$item_da['R01_Plan']] = 0;
				$birthday = $item_da['R01_Birthday_Year'].'-'.$item_da['R01_Birthday_Month'].'-'.$item_da['R01_Birthday_Date'];
				if (($birthday != $participantInfo['R01_Birthday']) || 
					
					($item_da['R01_Post1'] != $participantInfo['R01_Post1']) ||
					($item_da['R01_Post2'] != $participantInfo['R01_Post2']) ||
					($item_da['R01_Address_Pref'] != $participantInfo['R01_Address_Pref']) ||
					($item_da['R01_Address1'] != $participantInfo['R01_Address1']) ||
					($item_da['R01_Address2'] != $participantInfo['R01_Address2']) ||
					($item_da['R01_Tel'] != $participantInfo['R01_Tel']) ||
					($item_da['R01_Mobile'] != $participantInfo['R01_Mobile']) ||
					($item_da['R01_tabaco'] != $participantInfo['R01_tabaco']) ||
					($item_da['R01_Note'] != $participantInfo['R01_Note'])) {
					$flag_tag = false;
					$flag[$item_da['R01_Plan']] = 1;
					
				}
				if(isset($item_da['R01_Sex'] )){
					if($item_da['R01_Sex'] != $participantInfo['R01_Sex']){
						$flag_tag = false;
						$flag[$item_da['R01_Plan']] = 1;
					}
				}
			
				
			}
			$StaffInfo           = $this->user_top_mo->getStaffInfo($R00_Id);
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $kakuteiInfo = $this->user_top_mo->getKakuteCourseById($CourseArr);
			if( $flag_tag == false) {
				date_default_timezone_set('Asia/Tokyo');
				mb_language("Japanese");
				mb_internal_encoding("utf8");
				$this->load->config('mail_config');
				$mail_config['protocol']=$this->config->item('protocol');
				$mail_config['smtp_host']=$this->config->item('smtp_host');
				$this->email->initialize($mail_config);

				$this->email->from('tourdesk110@or.knt.co.jp',mb_encode_mimeheader('AKTIO旅行社員　マイページ'));
				$tos = array('yi942278@mb.knt.co.jp','ayabe140023@mb.knt.co.jp','suzuki060636@mb.knt.co.jp','ecc01-02@or.knt.co.jp','kagawaa01937@mb.knt.co.jp','ide.naomi@nisshin-sys.co.jp');
				//$tos = array('dothu.huong@nisshin-sys.co.jp','ide.naomi@nisshin-sys.co.jp');
				$this->email->to($tos); 
				$this->email->subject("参加者情報の変更");
				$body = "";
				$body .= "\r\n";
				$body .= "{unwrap}参加者情報の変更をお知らせいたします。{/unwrap}\r\n";
				$body .= "{unwrap}社員番号　　　　: ".$StaffInfo['R00_Id']."{/unwrap}\r\n";
				$body .= "{unwrap}社員名　　　　　: ".$StaffInfo['R00_Sei'].'　'.$StaffInfo['R00_Name']."{/unwrap}\r\n";
				$body .= "{unwrap}参加コース　　　: ".$kakuteiInfo['M01_Course_Name']."{/unwrap}\r\n";
				$body .= "\r\n";
                $body .= "\r\n";
				$body .= "{unwrap}◆変更前情報◆{/unwrap}\r\n";
				foreach($Traveler as $key_no => $item){
					if($item['R01_Plan']==0 ){
						$kubunn = "本人" ;
					}else{ 
						$kubunn = "同行者".($key_no) ;
					}
					if($flag[$item['R01_Plan']] == 1){
						$body .= "{unwrap}　●".$kubunn."{/unwrap}\r\n";
					
				$participantInfo = $this->user_top_mo->getUserInfobyPlan($R00_Id,$item['R01_Plan']);
				$birthday = $item['R01_Birthday_Year'].'-'.$item['R01_Birthday_Month'].'-'.$item['R01_Birthday_Date'];
				if ($birthday != $participantInfo['R01_Birthday']){
					$body .= "{unwrap}　　生年月日  : ".$participantInfo['R01_Birthday']."{/unwrap}\r\n";
				}
				if(isset($participantInfo['R01_Sex'] )){
					if($participantInfo['R01_Sex'] == 1){
						$gender = "男";
					}else if ($participantInfo['R01_Sex'] == 2 ){
						$gender = "女";
						
					}
					if($item['R01_Sex'] != $participantInfo['R01_Sex']){
						$body .= "{unwrap}　　性別  　　: ".$gender."{/unwrap}\r\n";
					}
				}
				if (($item['R01_Post1'] != $participantInfo['R01_Post1']) ||
					($item['R01_Post2'] != $participantInfo['R01_Post2']) ||
					($item['R01_Address_Pref'] != $participantInfo['R01_Address_Pref']) ||
					($item['R01_Address1'] != $participantInfo['R01_Address1']) ||
					($item['R01_Address2'] != $participantInfo['R01_Address2'])) {
					
					$body .= "{unwrap}　　住所  　　: ".$participantInfo['R01_Post1'].'　'.$participantInfo['R01_Post2']."{/unwrap}\r\n";
					$body .= "{unwrap}　　　　　　　　　".$participantInfo['R01_Address_Pref'].'　'.$participantInfo['R01_Address1'].'　'.$participantInfo['R01_Address2']."{/unwrap}\r\n";
					
				}
				if ($item['R01_Tel'] != $participantInfo['R01_Tel']){
					$body .= "{unwrap}　　自宅電話番号: ".$participantInfo['R01_Tel']."{/unwrap}\r\n";
				}
				if ($item['R01_Mobile'] != $participantInfo['R01_Mobile']){
					$body .= "{unwrap}　　携帯電話番号: ".$participantInfo['R01_Mobile']."{/unwrap}\r\n";
				}
				if($participantInfo['R01_tabaco'] == 0){
						$tabaco = "禁煙";
					}else if ($item['R01_tabaco'] == 1) {
						$tabaco = "喫煙";
						
					}
				if ($item['R01_tabaco'] != $participantInfo['R01_tabaco']){
					$body .= "{unwrap}　　喫煙  　　: ".$tabaco."{/unwrap}\r\n";
				}
				if ($item['R01_Note'] != $participantInfo['R01_Note']){
					$body .= "{unwrap}　　備考  　　: ".$participantInfo['R01_Note']."{/unwrap}\r\n";
				}
				}
				
				}
			
				$body .= "============================================================================\r\n";
				$body .= "{unwrap}◆変更後情報◆{/unwrap}\r\n";
				foreach($Traveler as $key_no2 => $item2){
					if($item2['R01_Plan']==0 ){
						$kubunn2 = "本人" ;
					}else{ 
						$kubunn2 = "同行者".($key_no2) ;
					}
					if($flag[$item2['R01_Plan']] == 1){
						$body .= "{unwrap}　●".$kubunn2."{/unwrap}\r\n";
					
				$participantInfo = $this->user_top_mo->getUserInfobyPlan($R00_Id,$item2['R01_Plan']);
				$birthday = $item2['R01_Birthday_Year'].'-'.$item2['R01_Birthday_Month'].'-'.$item2['R01_Birthday_Date'];
				if ($birthday != $participantInfo['R01_Birthday']){
					$body .= "{unwrap}　　生年月日  : ".$birthday."{/unwrap}\r\n";
				}
				if(isset($item2['R01_Sex'] )){
					if($item2['R01_Sex'] == 1){
						$gender2 = "男";
					}else if ($item2['R01_Sex'] == 2 ){
						$gender2 = "女";
						
					}
					if($item2['R01_Sex'] != $participantInfo['R01_Sex']){
						$body .= "{unwrap}　　性別  　　: ".$gender2."{/unwrap}\r\n";
					}
				}
				if (($item2['R01_Post1'] != $participantInfo['R01_Post1']) ||
					($item2['R01_Post2'] != $participantInfo['R01_Post2']) ||
					($item2['R01_Address_Pref'] != $participantInfo['R01_Address_Pref']) ||
					($item2['R01_Address1'] != $participantInfo['R01_Address1']) ||
					($item2['R01_Address2'] != $participantInfo['R01_Address2'])) {
					
					$body .= "{unwrap}　　住所  　　: ".$item2['R01_Post1'].'　'.$item2['R01_Post2']."{/unwrap}\r\n";
					$body .= "{unwrap}　　　　　　　　　".$item2['R01_Address_Pref'].'　'.$item2['R01_Address1'].'　'.$item2['R01_Address2']."{/unwrap}\r\n";
					
				}
				if ($item2['R01_Tel'] != $participantInfo['R01_Tel']){
					$body .= "{unwrap}　　自宅電話番号: ".$item2['R01_Tel']."{/unwrap}\r\n";
				}
				if ($item2['R01_Mobile'] != $participantInfo['R01_Mobile']){
					$body .= "{unwrap}　　携帯電話番号: ".$item2['R01_Mobile']."{/unwrap}\r\n";
				}
				if($item2['R01_tabaco'] == 0){
						$tabaco2 = "禁煙";
					}else if ($item2['R01_tabaco'] == 1) {
						$tabaco2 = "喫煙";
						
					}
				if ($item2['R01_tabaco'] != $participantInfo['R01_tabaco']){
					$body .= "{unwrap}　　喫煙  　　: ".$tabaco2."{/unwrap}\r\n";
				}
				if ($item2['R01_Note'] != $participantInfo['R01_Note']){
					$body .= "{unwrap}　　備考  　　: ".$item2['R01_Note']."{/unwrap}\r\n";
				}
					}
				
				}
				
				$body .= "============================================================================\r\n";
				$body .= "\r\n";
				$this->email->message($body);	

				$this->email->send();
			}
            foreach($Traveler as $traKey => $traVal){
                $traVal['R01_Id'] = $R00_Id;
                $traVal['R01_Birthday'] = $traVal['R01_Birthday_Year'].'-'.$traVal['R01_Birthday_Month'].'-'.$traVal['R01_Birthday_Date'];
                $traVal['R01_UpdateTime'] = $today;
                unset( $traVal['R01_Birthday_Year'] );
                unset( $traVal['R01_Birthday_Month'] );
                unset( $traVal['R01_Birthday_Date'] );

                $result = $this->user_top_mo->setTravelinfo($traVal);
            }
            $this ->CalTotalMoney($R00_Id);
			
			
            redirect(base_url('user_top_con'));

        return;
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }


    /*
    *
    *コース別空席状況
    *
    */
    public function seat_course(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id != '' || $R00_Id != null) {
            $data['user_name'] = $this->getUserName();
             // 全てのコース取得
            $CourseKbn = $this->user_top_mo->countDestkbn ();
            foreach ( $CourseKbn as $val ) {
                $Kbn ['kbn_' . $val ['M01_Dest_Kbn']] = $val ['totalCount'];
            }

            $CourseCode = $this->user_top_mo->countDestCode ();
            foreach ( $CourseCode as $val ) {
                $Code ['code_' . $val ['M01_Dest_Code']] = $val ['totalCount'];
            }
            $CourseDate = $this->user_top_mo->countDate ();
            foreach ( $CourseDate as $val ) {
                $Date['date_' . $val ['M01_Dest_Code'].'_'.$val ['M01_Han']] = $val ['totalCount'];
            }

            $data['Kbn'] = $Kbn;
            $data ['code'] = $Code;
            $data ['date_code'] = $Date;

            $data['results'] = $this->user_top_mo->GetAllCourse();
            $this->load->view('head_vi');
            $this->load->view('seat_course_vi', $data);
        }else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    public function bankInfo() {
        $user_id = $this->session->userdata('R00_Id');
        $user_plan = !isset($_POST['user_plan']) ? "" : $_POST['user_plan'];
        if ($user_id != '' || $user_id != null) {
            $data = array();
            $coursePrimary = $this->user_top_mo->getCoursePrimaryByUserId($user_id);
            $bankInfo = $this->user_top_mo->getBankInfoByCoursePrimary($coursePrimary);
            $data['bankInfo'] = $bankInfo;
            $this->load->view('payment_bank_info_vi', $data);
            return;
        } else{
            redirect(base_url('login_con/logout'));
            return;
        }
    }

    /*
    /*
    *金額更新する
    *
    */
    public function CalTotalMoney($staff_id){

            $cost_travel = 0;
            $cost_room = 0;
            $StaffInfo           = $this->user_top_mo->getStaffInfo($staff_id);
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($staff_id);
            $kakuteiInfo = $this->user_top_mo->getKakuteCourseById($CourseArr);
            $participantInfo_arr = $this->user_top_mo->getUserInfo($staff_id);

                foreach ( $participantInfo_arr as $info_key => $participant ) {
                    $old = floor((date('Ymd', strtotime($kakuteiInfo['M01_Dep_Date'])) - date('Ymd', strtotime($participant['R01_Birthday']))) / 10000);
                    // 代表者
                    if ($participant['R01_Plan'] == 0) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Me'];
                    }
                    // 大人
                    if ($participant['R01_Plan'] != 0 && $old >= 12) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Adult1'];
                    }
                    // 海外:子供
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 1) && (2 <= $old) && ($old < 12)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Child'];
                    }
                    // 国内:子供
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 2) && (3 <= $old) && ($old < 12)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Child'];
                    }
                    // 海外:幼児
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 1) && (0 <= $old) && ($old < 2)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Baby'];
                    }
                    // 国内:幼児
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 2) && (0 <= $old) && ($old < 3)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Baby'];
                    }
                    $traVal['R01_Id'] = $participant['R01_Id'];
                    $traVal['R01_Plan'] = $participant['R01_Plan'];
                    $traVal['R01_Cost_Name3'] = "参加料金";
                    $traVal['R01_Cost3'] = $cost_travel;
                    $result = $this->user_top_mo->CostTravelinfo($traVal);

                }
                /*-----end 金額----*/
    }
}
