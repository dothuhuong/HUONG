<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Anq_con extends CI_Controller {
    function Anq_con() {
        parent:: __construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('user_top_mo');
        $this->load->model('common_mo');
		$this->load->model('anq_mo');
        $this->load->library('convert_format');
        date_default_timezone_set('Asia/Tokyo');
    }

    public function index(){
        //セクションから代表者ID　取得
        $staff_id = $this->session->userdata('R00_Id');
        
         if ($staff_id == '' || $staff_id == null) {
            // セッションがなくなった場合はログインページに移動する
            redirect(base_url('login_con/logout'));
            return;
        } else {
             // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            $StaffInfo         = $this->anq_mo->getStaffInfo($staff_id);
            $M26_data_arr = array(
                
                "M26_Dest_Code "  => $StaffInfo['R00_Dest_Code'],
                "M26_Han "        => $StaffInfo['R00_Han']
				
            );
			$data['anq_data'] = $this->anq_mo->getAnqbyCourse($M26_data_arr);
            $this->load->view('head_vi');
            $this->load->view('anq_form_vi', $data);
            return;
        }
    }

    /*
    * セクションからユーザ名取得
    */
    public function getUserName(){
        $staff_id = $this->session->userdata('R00_Id');
        $user_name = $this->user_top_mo->getUserName($staff_id);
        $data = $user_name;
        return $data;
    }

	public function anq_confirm(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $data['user_name'] = $this->getUserName();
            $StaffInfo         = $this->anq_mo->getStaffInfo($R00_Id);
            $M26_data_arr = array(
                
                "M26_Dest_Code "  => $StaffInfo['R00_Dest_Code'],
                "M26_Han "        => $StaffInfo['R00_Han']
				
            );
			$data['anq_data'] = $this->anq_mo->getAnqbyCourse($M26_data_arr);
            
          
              
            $data['R14_Anq_Other'] = !isset($_POST['Other_kanso'])?"":$_POST['Other_kanso'];
            for($i=1;$i<=10;$i++){
				
                $data['R14_Anq_Level'][$i]= !isset($_POST[$i.'_aq'])?"":$_POST[$i.'_aq'];
                $data['R14_Anq_Text'][$i]= !isset($_POST[$i.'_kanso'])?"":$_POST[$i.'_kanso'];
            }
            $this->load->view('head_vi');
            $this->load->view('anq_confirm_vi', $data);
            return;
        }

    }
	public function SaveReserve(){
        
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $data['user_name'] = $this->getUserName();
            $submit = $this->input->post('submit');

            $params = array(
                "R14_Anq_Id"                   => $R00_Id,
                "R14_Anq_Other"                => $this->input->post('R14_Anq_Other')
                
            );
            
			for($i=1;$i<=10;$i++){
				$params['R14_Anq_'.$i.'_Level'] =  !isset($_POST['R14_Anq_'.$i.'_Level'])?"":$_POST['R14_Anq_'.$i.'_Level'];
				$params['R14_Anq_'.$i.'_Text'] =  !isset($_POST['R14_Anq_'.$i.'_Text'])?"":$_POST['R14_Anq_'.$i.'_Text'];
			}
                


            if ($submit=="登録"){			
                $R04_Pkey_Sub = $this->anq_mo->insertR14Reserve( $params );											
                
                redirect(base_url('user_top_con'));
            }elseif ($submit=="前の画面へ"){
				$StaffInfo         = $this->anq_mo->getStaffInfo($R00_Id);
				$M26_data_arr = array(
					
					"M26_Dest_Code "  => $StaffInfo['R00_Dest_Code'],
					"M26_Han "        => $StaffInfo['R00_Han']
					
				);
				$data['anq_data'] = $this->anq_mo->getAnqbyCourse($M26_data_arr);
				$data['anq_row'] = $params;
                $this->load->view('head_vi');
                $this->load->view('anq_form_vi', $data);
                return;
            }
        }
    }
    
   
   

   
    
}
?>
