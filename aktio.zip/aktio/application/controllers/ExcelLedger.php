<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');
require_once APPPATH . 'libraries/excel/PHPExcel.php';
require_once APPPATH . 'libraries/excel/PHPExcel/IOFactory.php';
/**
 */
class ExcelLedger extends PHPExcel
{
    public function __construct() {
        parent::__construct();
    }
    /*
     *
     * 台帳
	 *$Data :検索データ結果　、 $CourseDataMaster:コース情報
     */
    public function getExcelLedger($Data, $CourseDataMaster) {
        date_default_timezone_set("Asia/Tokyo");
        $objPHPExcel = PHPExcel_IOFactory::load(APPPATH . "libraries/template_excel/Ledger.xlsx");
        $objPHPExcel->setActiveSheetIndex(0);
        $objSheet = $objPHPExcel->getActiveSheet();
        $objSheet->setTitle("Ledger");
        $this->createContentSheet($Data, $CourseDataMaster, $objSheet);
        $filename = 'Ledger.xlsx';
        header("Content-Type: application/octet-stream"); // ダウンロードの指示
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0'); // no cache
        ob_end_clean(); // ファイル破損エラー防止
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
    private function createContentSheet($Data, $CourseDataMaster, PHPExcel_Worksheet $objSheet) {
        $CI = & get_instance();
        $CI->load->library('convert_format');
		$CI->load->model('ledger_mo');
        // コース名
        $objSheet->setCellValue('A2', $CourseDataMaster['M01_Course_Name']);
        $objSheet->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        //例2017年05月12日(金)～2017年05月17日(水)
        $M01_Dep_Date = $CI->convert_format->ChangeJpDay($CourseDataMaster['M01_Dep_Date']);
        $M01_Arr_Date = $CI->convert_format->ChangeJpDay($CourseDataMaster['M01_Arr_Date']);		
        $objSheet->setCellValue('A3', $M01_Dep_Date . '～' . $M01_Arr_Date);		
		// フライト情報
        $go_air = isset($CourseDataMaster['M011_Go_Air'])?('往路フライト：' . $CourseDataMaster['M011_Go_Air']):'往路フライト：';
        $objSheet->setCellValue('A4', $go_air);
        $rtn_air = isset($CourseDataMaster['M011_Rtn_Air'])?('往路フライト：' . $CourseDataMaster['M011_Rtn_Air']):'往路フライト：';
        $objSheet->setCellValue('D4', $rtn_air);	
        $i = 8;	
        foreach ( $Data as $row ) {
			if($row['R01_Id'] != '' ||$row['R01_Id'] != NULL){
				$total = 0;	
				$opt_cost1=0;
				$opt_cost2=0;
				$opt_cost3=0;
				$opt_cost4=0;
				$opt_cost5=0;
				$opt_cost6=0;
				$opt_cost7=0;
				$opt_cost8=0;
				$before_stay_cost1 =0;
				$before_stay_cost2 =0;
				$before_stay_cost3 =0;
				$after_stay_cost1 =0;
				$after_stay_cost2 =0;
				$after_stay_cost3 =0;
				$payment_total=0;
				if($row['R01_Plan'] == 0){
					$parti_cnt     = $CI->ledger_mo->getParticaipate($row['R01_Id']).'人';
					$group_no      = $row['R00_Group_No'];
					$one_room_wish = $row['R00_1Room_wish'];
					$R00_allergy_Note = $row['R00_allergy_Note'];
					$before_stay = $this->hotel_reserve($row['R01_Id'], 1);
					$after_stay = $this->hotel_reserve($row['R01_Id'], 2);
					
					if(count($before_stay)>0){
						foreach($before_stay as $stay){
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==1){
								$before_stay_cost1 = $stay['R09_Room_Price'];							
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==2){
								$before_stay_cost2 = $stay['R09_Room_Price'];							
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==3){
								$before_stay_cost3 = $stay['R09_Room_Price'];							
							}
						}
						
					}
					if(count($after_stay)>0){
						foreach($after_stay as $stay){
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==1){
								$after_stay_cost1 = $stay['R09_Room_Price'];
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==2){
								$after_stay_cost2 = $stay['R09_Room_Price'];							
							}
							if(isset($stay['R09_Sequence']) AND $stay['R09_Sequence'] ==3){
								$after_stay_cost3 = $stay['R09_Room_Price'];
							}
						}
					}
				}else{
					$parti_cnt     = '';
					$group_no      = '';
					$one_room_wish = '';
					$R00_allergy_Note = '';
					$before_stay_cost1 = 0;
					$before_stay_cost2 = 0;
					$before_stay_cost3 = 0;
					$after_stay_cost1 = 0;
					$after_stay_cost2 = 0;
					$after_stay_cost3 = 0;
				}		
				$user_id = $row['R01_Id'] . '-' . ($row['R01_Plan'] + 1);
				$objSheet->setCellValue('A' . $i, $user_id);//IDNO
				$objSheet->setCellValue('B' . $i, $row['R01_PaxNo'] );//PaxNo
				$objSheet->setCellValue('C' . $i, $row['R00_Dest_Kbn'].$row['R00_Dest_Code'].$row['R00_Han'].$row['R00_Dep_Id'].$row['R00_Air_Program'] );//コースコード
				$objSheet->setCellValue('D' . $i, $M01_Dep_Date);//出発日
				$objSheet->setCellValue('E' . $i, $row['R01_Sei']);//姓
				$objSheet->setCellValue('F' . $i, $row['R01_Name']);//名
				if($row['R00_Han'] ==2){
					$objSheet->setCellValue('G' . $i, $row['R01_Sei_Eng']);//姓_英字
					$objSheet->setCellValue('H' . $i, $row['R01_Name_Eng']);//名_英字
				}elseif($row['R00_Han'] ==1){
					$objSheet->setCellValue('G' . $i, $row['R01_Passport_Sei']);//姓_英字
					$objSheet->setCellValue('H' . $i, $row['R01_Passport_Name']);//名_英字
				}
				
				
				$objSheet->setCellValue('I' . $i, $row['R01_Nationality']);//国籍
				if($row['R01_Sex'] ==1){
					$sex = '男性';
				}else{
					$sex = '女性';
				}
				$objSheet->setCellValue('J' . $i, $sex);//性別
				$R01_Birthday = str_replace("-", "/",  $row['R01_Birthday']);//生年月日
				
				$objSheet->setCellValue('K' . $i, $R01_Birthday);
				$age = floor((date('Ymd', strtotime($CourseDataMaster['M01_Dep_Date'])) - date('Ymd', strtotime($row['R01_Birthday']))) / 10000);//年齢
				$objSheet->setCellValue('L' . $i, $age.'歳');					
				$objSheet->setCellValue('M' . $i, $parti_cnt);//参加者人数	
				$objSheet->setCellValue('N' . $i, $group_no);//グルプ番号
				$objSheet->setCellValue('P' . $i,  $CI->convert_format->ChangeJpDay($row['R06_Update']));//ESTA返送日	
				$objSheet->setCellValue('Q' . $i,  $CI->convert_format->ChangeJpDay($row['R10_Update_Date']));//ETAS返送日	
				$objSheet->setCellValue('S' . $i,  $CI->convert_format->ChangeJpDay($row['R11_Update_Date']));//グアム質問書返送日
				if( ($row['R06_Esta_Have'] != NULL) AND($row['R06_Esta_Have'] == 1) AND ($row['R00_Dest_Code'] == 'HNL')){
					$R06_Esta_Have = '持ってる';
				}elseif( ($row['R06_Esta_Have'] != NULL) AND($row['R06_Esta_Have']==0) AND ($row['R00_Dest_Code'] == 'HNL')){
					$R06_Esta_Have = '持ってない';
				}else{
					$R06_Esta_Have = '';
				}			
				if( ($row['R06_Esta_Register']==1)  AND ($row['R00_Dest_Code'] == 'HNL')){
					$R06_Esta_Register = '自身で取得';
				}elseif( ($row['R06_Esta_Register']==2)  AND ($row['R00_Dest_Code'] == 'HNL')){
					$R06_Esta_Register = '代行';
				}else{
					$R06_Esta_Register = '';
				}
				$objSheet->setCellValue('T' . $i,  $R06_Esta_Have);//ESTAの有無
				$objSheet->setCellValue('U' . $i, $R06_Esta_Register);//申請方法	
				if( ($row['R10_Etas_Have'] != NULL) AND ($row['R10_Etas_Have'] == 1) AND ($row['R00_Dest_Code'] == 'SYD')){
					$R10_Etas_Have = '持ってる';
				}elseif( ($row['R10_Etas_Have'] != NULL) AND ($row['R10_Etas_Have']==0) AND ($row['R00_Dest_Code'] == 'SYD')){
					$R10_Etas_Have = '持ってない';
				}else{
					$R10_Etas_Have = '';
				}			
				if( $row['R10_Etas_Register']==1  AND ($row['R00_Dest_Code'] == 'SYD')){
					$R10_Etas_Register = '自身で取得';
				}elseif( $row['R10_Etas_Register']==2  AND ($row['R00_Dest_Code'] == 'SYD')){
					$R10_Etas_Register = '代行';
				}else{
					$R10_Etas_Register = '';
				}
				$objSheet->setCellValue('V' . $i,  $R10_Etas_Have);//ESTAの有無
				$objSheet->setCellValue('W' . $i, $R10_Etas_Register);//申請方法	
				$objSheet->setCellValue('X' . $i, $one_room_wish);
				$objSheet->setCellValue('Y' . $i, $R00_allergy_Note);
				$objSheet->setCellValue('Z' . $i, $row['R01_Note']);
				$objSheet->setCellValue('AA' . $i, $row['R01_AirClass']);
				$optional_tour = $this->getOptionalTour($row['R01_Id'], $row['R01_Plan'], $row['R01_Birthday'], $CourseDataMaster['M01_Dep_Date']);
				if(count($optional_tour)>0){
					foreach($optional_tour as $optKey => $optVal){
						if($optKey ==1){						
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('AE' . $i, $optVal[0]['R04_Optional_Tour_Name']);	
								}							
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('BH' . $i, $optVal[0]['opt_price']);
									$opt_cost1=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BI' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost1=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BH' . $i, 0);
									$opt_cost1= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('AF' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('BJ' . $i, $optVal[1]['opt_price']);
									$opt_cost2=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BK' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost2=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BJ' . $i, 0);
									$opt_cost2= 0;
								}			
							}	
						
						}elseif($optKey ==2){
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('AG' . $i, $optVal[0]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('BL' . $i, $optVal[0]['opt_price']);
									$opt_cost3=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BM' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost3=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BL' . $i, 0);
									$opt_cost3= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('AH' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('BN' . $i, $optVal[1]['opt_price']);
									$opt_cost4=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BO' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost4=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BN' . $i, 0);
									$opt_cost4= 0;
								}									
							}			
						}elseif($optKey ==3){
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('AI' . $i, $optVal[0]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('BP' . $i, $optVal[0]['opt_price']);
									$opt_cost5=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BQ' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost5=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BP' . $i, 0);
									$opt_cost5= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('AJ' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('BR' . $i, $optVal[1]['opt_price']);
									$opt_cost6=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BS' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost6=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BR' . $i, 0);
									$opt_cost6= 0;
								}								
							}			
						}elseif($optKey ==4){
							if(isset($optVal[0]['R04_Optional_Tour_Name'])){
								if($optVal[0]['R04_STS'] == 2 || $optVal[0]['R04_STS'] == 7){
									$objSheet->setCellValue('AK' . $i, $optVal[0]['R04_Optional_Tour_Name']);
								}
								
								//手配完了
								if($optVal[0]['R04_STS'] == 2){
									$objSheet->setCellValue('BT' . $i, $optVal[0]['opt_price']);
									$opt_cost7=$optVal[0]['opt_price'];
								}elseif($optVal[0]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BU' . $i, $optVal[0]['R04_Cancel_Cost']);
									$opt_cost7=$optVal[0]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BT' . $i, 0);
									$opt_cost7= 0;
								}								
							}
							if(isset($optVal[1]['R04_Optional_Tour_Name'])){
								if($optVal[1]['R04_STS'] == 2 || $optVal[1]['R04_STS'] == 7){
									$objSheet->setCellValue('AL' . $i, $optVal[1]['R04_Optional_Tour_Name']);
								}
								//手配完了
								if($optVal[1]['R04_STS'] == 2){
									$objSheet->setCellValue('BV' . $i, $optVal[1]['opt_price']);
									$opt_cost8=$optVal[1]['opt_price'];
								}elseif($optVal[1]['R04_STS'] == 7 && $row['R01_Plan']==0){
									$objSheet->setCellValue('BW' . $i, $optVal[1]['R04_Cancel_Cost']);
									$opt_cost8=$optVal[1]['R04_Cancel_Cost'];
								}else{
									$objSheet->setCellValue('BV' . $i, 0);
									$opt_cost8= 0;
								}	
								
							}		
						}
					}
				}
				$total +=$opt_cost1;
				$total +=$opt_cost2;
				$total +=$opt_cost3;
				$total +=$opt_cost4;
				$total +=$opt_cost5;
				$total +=$opt_cost6;
				$total +=$opt_cost7;
				$total +=$opt_cost8;
				$objSheet->setCellValue('AP' . $i, $row['R01_Cost3']);//自己負担旅行代金
				$total += $row['R01_Cost3'];			
				$objSheet->setCellValue('AQ' . $i, $row['R01_Cost2']);//会費不足代金
				$total += $row['R01_Cost2'];
				$objSheet->setCellValue('AR' . $i, $row['R01_Cost4']);//一人部屋追加代金
				$total += $row['R01_Cost4'];
				$objSheet->setCellValue('AS' . $i, $row['R01_Cost8']);//ビジネスクラス追加代金
				$total += $row['R01_Cost8'];
				$objSheet->setCellValue('AT' . $i, $row['R01_Cancel_Cost']);//旅行キャンセル料
				$total += $row['R01_Cancel_Cost'];
				$objSheet->setCellValue('AU' . $i, $row['R01_Cost9']);//旅行変更料
				$total += $row['R01_Cost9'];
				$objSheet->setCellValue('AV' . $i, $row['R01_Cost10']);//自己負担交通代金
				$total += $row['R01_Cost10'];
				$objSheet->setCellValue('AW' . $i, $row['R01_Cost11']);//交通変更取消料
				$total += $row['R01_Cost11'];
				$objSheet->setCellValue('AX' . $i, ($row['R01_Cost5']+$row['R01_Cost6']+$row['R01_Cost7']));//その他	
				$total += $row['R01_Cost5'];			
				$total += $row['R01_Cost6'];			
				$total += $row['R01_Cost7'];			
				$objSheet->setCellValue('AY' . $i, $before_stay_cost1 );//前泊１	
				$total += $before_stay_cost1;			
				$objSheet->setCellValue('AZ' . $i, $before_stay_cost2 );//前泊２	
				$total += $before_stay_cost2;			
				$objSheet->setCellValue('BA' . $i, $before_stay_cost3 );//前泊３
				$total += $before_stay_cost3;
				$objSheet->setCellValue('BB' . $i, $after_stay_cost1 );//後泊１	
				$total +=  $after_stay_cost1;			
				$objSheet->setCellValue('BC' . $i, $after_stay_cost2 );//後泊２		
				$total +=  $after_stay_cost2;
				$objSheet->setCellValue('BD' . $i, $after_stay_cost3 );//後泊３
				$total +=  $after_stay_cost3;
				if($row['R00_Dest_Code'] == 'HNL'){//ESTA料金
					$esta_cost = $row['R01_Cost1'];
				}else{
					$esta_cost = 0;
				}
				$total +=  $esta_cost;
				$objSheet->setCellValue('BE' . $i, $esta_cost );
				if($row['R00_Dest_Code'] == 'SYD'){//ETAS料金
					$etas_cost = $row['R01_Cost1'];
				}else{
					$etas_cost = 0;
				}
				$total +=  $etas_cost;
				$objSheet->setCellValue('BF' . $i, $etas_cost );//後泊３
				
				for($seq=1;$seq<=5;$seq++){
					$paymentArr = $this->getPayment($row['R01_Id'], $seq);
					if(count($paymentArr)>0){
						if($seq==1){
							if($row['R01_Plan'] == 0){
								$objSheet->setCellValue('BZ' . $i, $CI->convert_format->ChangeJpDay($paymentArr['R13_Payment_Date']));//入返金日
								$objSheet->setCellValue('CA' . $i, $this->getPaymentMethod($paymentArr['R13_Payment_Type']));//入返金方法
								$objSheet->setCellValue('CB' . $i, $paymentArr['R13_Payment_Cost']);//入返金額
								$payment_total +=$paymentArr['R13_Payment_Cost'];
							}
						}elseif($seq==2){
							if($row['R01_Plan'] == 0){
								$objSheet->setCellValue('CC' . $i, $CI->convert_format->ChangeJpDay($paymentArr['R13_Payment_Date']));//入返金日
								$objSheet->setCellValue('CD' . $i, $this->getPaymentMethod($paymentArr['R13_Payment_Type']));//入返金方法
								$objSheet->setCellValue('CE' . $i, $paymentArr['R13_Payment_Cost']);//入返金額
								$payment_total +=$paymentArr['R13_Payment_Cost'];
							}
						}elseif($seq==3){
							if($row['R01_Plan'] == 0){
								$objSheet->setCellValue('CF' . $i, $CI->convert_format->ChangeJpDay($paymentArr['R13_Payment_Date']));//入返金日
								$objSheet->setCellValue('CG' . $i, $this->getPaymentMethod($paymentArr['R13_Payment_Type']));//入返金方法
								$objSheet->setCellValue('CH' . $i, $paymentArr['R13_Payment_Cost']);//入返金額
								$payment_total +=$paymentArr['R13_Payment_Cost'];
							}
						}elseif($seq==4){
							if($row['R01_Plan'] == 0){
								$objSheet->setCellValue('CI' . $i, $CI->convert_format->ChangeJpDay($paymentArr['R13_Payment_Date']));//入返金日
								$objSheet->setCellValue('CJ' . $i, $this->getPaymentMethod($paymentArr['R13_Payment_Type']));//入返金方法
								$objSheet->setCellValue('CK' . $i, $paymentArr['R13_Payment_Cost']);//入返金額
								$payment_total +=$paymentArr['R13_Payment_Cost'];
							}
						}elseif($seq==5){
							if($row['R01_Plan'] == 0){
								$objSheet->setCellValue('CL' . $i, $CI->convert_format->ChangeJpDay($paymentArr['R13_Payment_Date']));//入返金日
								$objSheet->setCellValue('CM' . $i, $this->getPaymentMethod($paymentArr['R13_Payment_Type']));//入返金方法
								$objSheet->setCellValue('CN' . $i, $paymentArr['R13_Payment_Cost']);//入返金額
								$payment_total +=$paymentArr['R13_Payment_Cost'];
							}
						}
					}
				}
				
			
				if($row['R01_Cancel_Day'] != NULL || $row['R01_Cancel_Day'] != ''){
					$objSheet->setCellValue('CQ' . $i,  $row['R01_Cancel_Day'] );//	//キャンセル日	
					$diff_can_day = $this->diff_day($row['R01_Cancel_Day'],$CourseDataMaster['M01_Dep_Date']);
					$objSheet->setCellValue('CR' . $i, $diff_can_day.'日');//CXL出発の何日前
				}
				//全員の合計金額
				if($row['R01_Plan']==0){
					$all_total = $this->total_expense($row['R01_Id']);
					$all_total += $before_stay_cost1 + $before_stay_cost2+ $before_stay_cost3+$after_stay_cost1+$after_stay_cost2+$after_stay_cost3;				
					$opt_all_total = $CI->ledger_mo->getOptAllTotal($row['R01_Id']);
					$opt_cancel_total = $CI->ledger_mo->getOptCancelTotal($row['R01_Id']);
					$all_total += $opt_all_total+$opt_cancel_total;
					$result = $all_total-$payment_total;
					$objSheet->setCellValue('BY' . $i, $all_total);//請求総合計
					$objSheet->setCellValue('CP' . $i, $result);//差額
				}
				$objSheet->setCellValue('CO' . $i, $payment_total);//入金合計						
				$objSheet->setCellValue('BX' . $i, $total);//請求合計			
				$payment_total=0;
				$total =0;			
				$all_total=0;
				$i ++;
			}
        }
    }
	function getOptionalTour($R04_Id, $R01_Plan, $R01_Birthday, $M01_Dep_Date){
		$CI = & get_instance();        
		$CI->load->model('ledger_mo');			
		$opt_result = $CI->ledger_mo->getOptionalTour( $R04_Id, $R01_Plan);
		$optArr = array();
		$NewOptArr = array();
		if(count($opt_result)>0){
			$j =0;
			foreach($opt_result as $opt){
				/*if($opt['R04_Optional_Kibou_Date'] == 1){
					$optArr[$opt['R04_Optional_Kibou_Date']][$j]=$opt;
					$optArr[$opt['R04_Optional_Kibou_Date']][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				}elseif($opt['R04_Optional_Kibou_Date'] == 2){
					$optArr['2'][$j]=$opt;
					$optArr['2'][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
					
				}elseif($opt['R04_Optional_Kibou_Date'] == 3){
					$optArr['3'][$j]=$opt;
					$optArr['3'][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				}elseif($opt['R04_Optional_Kibou_Date'] == 4){
					$optArr['4'][$j]=$opt;
					$optArr['4'][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				}*/
				$optArr[$opt['R04_Optional_Kibou_Date']][$j]=$opt;
				$optArr[$opt['R04_Optional_Kibou_Date']][$j]['opt_price'] = $this->getOptPrice($opt, $R01_Birthday, $M01_Dep_Date);
				$j++;
			}
		}	
		
		if(count($optArr)>0){
			foreach ($optArr as $key=>$val){
				foreach ($val as $key1=>$val1){
					$NewOptArr[$key][]=$val1;
				}
			}
		}
		return $NewOptArr;
	}
	/*
	*
	*
	*/
	public function hotel_reserve($R09_ReserveId, $R09_Type){
		$CI = & get_instance();        
		$CI->load->model('hotel_mo');
		$hotel_result = $CI->hotel_mo->getR09_Hotel_Reserve($R09_ReserveId, $R09_Type);
		return $hotel_result;
	}
	/*
	*
	*各位のオプションナルツーア取得
	*/
	public function getOptPrice($optional_tour, $R01_Birthday, $M01_Dep_Date){
		$age = floor((date('Ymd', strtotime($M01_Dep_Date)) - date('Ymd', strtotime($R01_Birthday))) / 10000);
		$opt_price =0;
		if ($age <= $optional_tour['M08_Child1_Limit_Max'] && $age >= $optional_tour['M08_Child1_Limit_Min']) {
			$opt_price = $optional_tour['M08_Optional_Cost_Child1'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Child1_haya'];
		}elseif ($age <= $optional_tour['M08_Child2_Limit_Max'] && $age >= $optional_tour['M08_Child2_Limit_Min']) {
			$opt_price = $optional_tour['M08_Optional_Cost_Child2'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Child2_haya'];
		}elseif($age <= $optional_tour['M08_Infant_Limit_Max'] && $age >= $optional_tour['M08_Infant_Limit_Min']){
			$opt_price = $optional_tour['M08_Optional_Cost_Infant'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Infant_haya'];
		}elseif($age > $optional_tour['M08_Child1_Limit_Max']){
			$opt_price = $optional_tour['M08_Optional_Cost_Adult'] * $optional_tour['R04_Tour_Rate'];
			$opt_price = $opt_price-$optional_tour['R04_Cost_Adult_haya'];			
		}
		if($opt_price==''){
			$opt_price=0;
		}		
		return round($opt_price, -1);
	}
	/*
	*入金取得
	*
	*/
	public function getPayment($R13_Id, $R13_Seq){
		$CI = & get_instance();        
		$CI->load->model('ledger_mo');
		$paymentArr = $CI->ledger_mo->getPayment($R13_Id, $R13_Seq);
		return $paymentArr;
	}
	/*
	*
	*/
	public function getPaymentMethod($data){
		$payment_method =array(
			'1'=>'銀行振込み',
			'2'=>'クレジットカード'
		);			
		return $payment_method[$data];
	}
	/*
	*CXL出発の何日前
	*/
	public function diff_day($day1, $day2){
		$dept_date = strtotime($day1);
		$can_date = strtotime($day2);
		$datediff = $can_date - $dept_date;		
		return floor($datediff / (60 * 60 * 24));
	}
	/*
	*全員合計
	*
	*/
	public function total_expense($R01_Id){
		$CI = & get_instance();        
		$CI->load->model('ledger_mo');
		$total_exp_arr = $CI->ledger_mo->getTotal_expense($R01_Id);	
		$total_exp = 0;
		foreach( $total_exp_arr as $data ){
			$total_exp += $data['R01_Cost1'];
			$total_exp += $data['R01_Cost3'];
			$total_exp += $data['R01_Cost2'];
			$total_exp += $data['R01_Cost4'];
			$total_exp += $data['R01_Cost8'];
			$total_exp += $data['R01_Cancel_Cost'];
			$total_exp += $data['R01_Cost9'];
			$total_exp += $data['R01_Cost10'];
			$total_exp += $data['R01_Cost11'];
			$total_exp += $data['R01_Cost5'];
			$total_exp += $data['R01_Cost6'];
			$total_exp += $data['R01_Cost7'];
		}
		return $total_exp;
	}
}