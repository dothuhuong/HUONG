<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Ledger_con extends CI_Controller {
    public function Ledger_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config'); 
		$this->load->model('ledger_mo');
		$this->load->model('operating_mo');
		$this->load->library('ExcelLedger');
        date_default_timezone_set('Asia/Tokyo');
    }
    public function index() {
		//セクションの確認
		$admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
		if (isset($admin_id)) {
			$Course = $this->input->post('Course');
			$param = array(
                "M01_Dest_Kbn" => $Course['R00_Dest_Kbn'],
                "M01_Dest_Code" =>  $Course['R00_Dest_Code'],
                "M01_Han" => $Course['R00_Han'],
                "M01_Dep_Id" => $Course['R00_Dep_Id'],
                "M01_Air_Program" => $Course['R00_Air_Program']
            );
			$CourseDataMaster = $this->operating_mo->getCourseDataByParam($Course);
			
			$LedgerArr = $this->ledger_mo->getLedgerData($Course);
			/*echo '<pre>';
			print_r($LedgerArr);
			echo '</pre>';
			exit;*/
			$this->excelledger->getExcelLedger($LedgerArr, $CourseDataMaster);			
		
		}else{
			redirect(base_url("admin_con"));
		}
    }
	/*
	*
	*	台帳タイトル
	*/
	/*public function getLedgerHead(){
		$headers = array (
			""
		);
		return $headers;
	}*/
	
}
