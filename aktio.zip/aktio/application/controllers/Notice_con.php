﻿<?php defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Notice_con extends CI_Controller {

    public function Notice_con() {
        parent::__construct ();
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('validation');
        $this->load->model('menu_mo');
		$this->load->model('notice_mo');
        
    }  

    /**
    * メニュー作成するメソッド
    */
    public function index() {
        // Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');	

        if (isset($admin_id)) {
			$param = array(
				'R04_Dest_Kbn'  => $this->input->post('M01_Dest_Kbn'),
				'R04_Dest_Code'        => $this->input->post('M01_Dest_Code'),
				'R04_Han'        => $this->input->post('M01_Han'),
				'R04_Dep_Id'        => $this->input->post('M01_Dep_Id'),
				'R04_Air_Program'        => $this->input->post('M01_Air_Program')
			);
			
			$NoticeData =  $this->notice_mo->getNoticeInfoByCondition($param);
			$CourseData =  $this->notice_mo->getCourseInfoByCondition($param);
			
			$data['CourseData'] = $CourseData[0];
			$data['NoticeData']	= $NoticeData;
			$data['title'] = "管理画面告知一覧";
			$this->load->view('header_admin_vi' , $data);
			$this->load->view('notice/notice_list_vi', $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }

	/*
	*
	*　編集機能
	*/
	public function edit(){
		// Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');		
		 
        if (isset($admin_id)) {
			$param = array(
				'R04_Dest_Kbn'  => $_POST['R04_Dest_Kbn'],
				'R04_Dest_Code'        => $_POST['R04_Dest_Code'],
				'R04_Dep_Id'        => $_POST['R04_Dep_Id'],
				'R04_Air_Program'        => $_POST['R04_Air_Program'],
				'R04_Order'        => $_POST['R04_Order'],
				'R04_Han'  => $_POST['R04_Han']
			);
			
			$R04_Notice = $this->notice_mo->getNoticeInfoByCondition($param);
			$CourseData = $this->notice_mo->getCourseInfoByCondition($param);
			
			$DestData = $this->notice_mo->getDestFromM01();
			
			$startDateArr = explode(' ', $R04_Notice[0]['R04_startDate']);
			$R04_Notice[0]['R04_startDate'] = $startDateArr[0];
			$startTime = explode(':', $startDateArr[1]);
			$R04_Notice[0]['R04_startHr'] = $startTime[0];
			$R04_Notice[0]['R04_startMin'] = $startTime[1];
			$R04_Notice[0]['R04_startSecond'] = $startTime[2];
			
			$endDateArr = explode(' ', $R04_Notice[0]['R04_endDate']);
			$R04_Notice[0]['R04_endDate'] = $endDateArr[0];
			$endTime = explode(':', $endDateArr[1]);
			$R04_Notice[0]['R04_endHr'] = $endTime[0];
			$R04_Notice[0]['R04_endMin'] = $endTime[1];
			$R04_Notice[0]['R04_endSecond'] = $endTime[2];
			
			$data['title'] = "管理画面告知編集";
			$data['CourseData'] = $CourseData[0];
			$data['NoticeData']	= $R04_Notice[0];
			$data['DestData'] = $DestData;
			 
			$this->load->view('header_admin_vi' , $data);
			$this->load->view('notice/notice_edit_vi', $data);
			
        } else {
            redirect(base_url("admin_con"));
        }
	}
	
	//方面コード
	public function getSelectDestId()
	{
		$Dest_Kbn = $_POST['copyDest_Kbn'];
		$DestIdData = $this->notice_mo->getDestIdFromM01($Dest_Kbn);
		echo $this->JSON($DestIdData);
	}
		
	function arrayRecursive(&$array, $function, $apply_to_keys_also = false)
	{
		static $recursive_counter = 0;
		if (++$recursive_counter > 1000) {
			die('possible deep recursion attack');
		}
		foreach ($array as $key => $value) {
			if (is_array($value)) {
				$this->arrayRecursive($array[$key], $function, $apply_to_keys_also);
			} else {
				$array[$key] = $function($value);
			}
			if ($apply_to_keys_also && is_string($key)) {
				$new_key = $function($key);
				if ($new_key != $key) {
					$array[$new_key] = $array[$key];
					unset($array[$key]);
				}
			}
		}
		$recursive_counter--;
	}

	function JSON($array) {
		$this->arrayRecursive($array, 'urlencode', true);
		$json = json_encode($array);
		return urldecode($json);
	}
	
	//班
	public function getSelectHan()
	{
		$Dest_Kbn = $_POST['copyDest_Kbn'];
		$Dest_Code = $_POST['copyDestId'];
		
		$HanData = $this->notice_mo->getHanFromM01($Dest_Kbn,$Dest_Code);
		
		echo $this->JSON($HanData);
	}
	//発着コード
	public function getSelectDep_Id()
	{
		$Dest_Kbn = $_POST['copyDest_Kbn'];
		$Dest_Code = $_POST['copyDestId'];
		$Han = $_POST['copyHan'];
		
		$Dep_IdData = $this->notice_mo->getDep_IdFromM01($Dest_Kbn,$Dest_Code,$Han);
		echo $this->JSON($Dep_IdData);
	}
	
	//AIR行程
	public function getSelectAir_Program()
	{
		$Dest_Kbn = $_POST['copyDest_Kbn'];
		$Dest_Code = $_POST['copyDestId'];
		$Han = $_POST['copyHan'];
		$Dep_Id = $_POST['copyDep_Id'];
		
		$Air_ProgramData = $this->notice_mo->getAir_ProgramFromM01($Dest_Kbn,$Dest_Code,$Han,$Dep_Id);
		echo $this->JSON($Air_ProgramData);
	}
	
	
	public function copy(){
		// Check session
        $admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');		
		 
        if (isset($admin_id)) {
			date_default_timezone_set('Asia/Tokyo');			
			$dt = new DateTime();
			$Update_time = $dt->format('Y-m-d H:i:s');
			$param = array(
				'R04_Dest_Kbn'  => $_POST['copyDest_Kbn'],
				'R04_Dest_Code'        => $_POST['copyDestId'],
				'R04_Dep_Id'        => $_POST['copyDep_Id'],
				'R04_Air_Program'        => $_POST['copyAir_Program'],
				'R04_Order'        => "",
				'R04_Han'  => $_POST['copyHan'],
				
				'R04_msg' => $this->input->post('msg'),
				'R04_msgUpdate' => $this->input->post('msgUpdate'),
				'R04_startDate' => $this->input->post('startDate'),
				'R04_endDate' => $this->input->post('endDate'),
				'R04_Display_flag' => $this->input->post('Display_flag'),
				'Update' => $Update_time		
			);
			
			$NoticeData = $this->notice_mo->getNoticeInfoByCondition($param);
			
			if(count($NoticeData) >0)
			{
				echo "データが存在です、確認してください。";
			}
			else
			{
				$max_sort   =  $this->notice_mo->getIdMaxSort($param);
				$param['R04_Order'] = $max_sort['max_sort'] +1;
				
				$result = $this->notice_mo->addNoticeInfoByCourse_Id($param);
				
				if($result > 0){
					echo "success";
				}else{
					echo "error";
				}
			}
			
		}else{
			redirect(base_url("admin_con"));
		}
	}
	/*
	*
	*更新
	*/
	public function update(){
		
		$admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
		 
        if (isset($admin_id)) {
			$param = array(
				'R04_Dest_Kbn'  => $_POST['Dest_Kbn'],
				'R04_Dest_Code'        => $_POST['Dest_Code'],
				'R04_Dep_Id'        => $_POST['Dep_Id'],
				'R04_Air_Program'        => $_POST['Air_Program'],
				'R04_Order'        => $_POST['Order'],
				'R04_Han'  => $_POST['Han'],
				
				'R04_msg'        => $_POST['msg'],
				'R04_msgUpdate'        => $_POST['msgUpdate'],
				'R04_startDate'        => $_POST['startDate'],				
				'R04_endDate'        => $_POST['endDate'],
				
				'R04_Display_flag'        => $_POST['Display_flag']
			);
			
			$oldOrder = $_POST['oldOrder'];
			$result = $this->notice_mo->updateNoticeInfoById($param,$oldOrder);
			
			if($result > 0){
				echo "success";
			}else{
				echo "error";
			}
				
		}else{
			redirect(base_url("admin_con"));
		}
	}
	
	/*
	*
	*追加 View
	*/
	public function addView(){
		$admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');		
        if (isset($admin_id)) {
			$param = array(
				'R04_Dest_Kbn'  => $_POST['Dest_Kbn'],
				'R04_Dest_Code'        => $_POST['Dest_Code'],
				'R04_Dep_Id'        => $_POST['Dep_Id'],
				'R04_Air_Program'        => $_POST['Air_Program'],
				'R04_Han'  => $_POST['Han']
			);	
			
			$CourseData =  $this->notice_mo->getCourseInfoByCondition($param);
			
			$NoticeData['R04_Dest_Kbn'] = $_POST['Dest_Kbn'];
			$NoticeData['R04_Dest_Code'] = $_POST['Dest_Code'];
			$NoticeData['R04_Han'] = $_POST['Dep_Id'];
			$NoticeData['R04_Dep_Id'] = $_POST['Dest_Kbn'];
			$NoticeData['R04_Air_Program'] = $_POST['Air_Program'];
			
			$max_sort   =  $this->notice_mo->getIdMaxSort($param);
			$data['CourseData'] = $CourseData[0];
			$data['NoticeData'] = $NoticeData;
			$data['param'] = $param;
			$data['title'] = "管理画面告知追加";
			$data['max_sort'] = $max_sort['max_sort'] +1;
			$this->load->view('header_admin_vi' , $data);
			$this->load->view('notice/notice_addView_vi', $data);		
				
		}else{
			redirect(base_url("admin_con"));
		}
	}
	
	/*
	*
	*
	*/
	public function add(){
		$admin_id     = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');		
        if (isset($admin_id)) {
			date_default_timezone_set('Asia/Tokyo');			
			$dt = new DateTime();
			$Update_time = $dt->format('Y-m-d H:i:s');
			$param = array(
				'R04_Dest_Kbn'  => $_POST['Dest_Kbn'],
				'R04_Dest_Code'        => $_POST['Dest_Code'],
				'R04_Dep_Id'        => $_POST['Dep_Id'],
				'R04_Air_Program'        => $_POST['Air_Program'],
				'R04_Order'        => $_POST['Order'],
				'R04_Han'  => $_POST['Han'],
				
				'R04_msg' => $this->input->post('msg'),
				'R04_msgUpdate' => $this->input->post('msgUpdate'),
				'R04_startDate' => $this->input->post('startDate'),
				'R04_endDate' => $this->input->post('endDate'),
				'R04_Display_flag' => $this->input->post('Display_flag'),
				'R04_Order' => $this->input->post('Order'),
				'Update' => $Update_time		
			);
			
			$NoticeData = $this->notice_mo->getNoticeInfoByCondition($param);
			
			if(count($NoticeData) >0)
			{
				echo "データが存在です、確認してください。";
			}
			else
			{
				$result = $this->notice_mo->addNoticeInfoByCourse_Id($param);
				
				if($result > 0){
					echo "success";
				}else{
					echo "error";
				}
			}
		}else{
			redirect(base_url("admin_con"));
		}
	}
}