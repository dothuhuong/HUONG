<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Anq_download_con extends CI_Controller
{
    public function Anq_download_con() {
        parent::__construct();
        // ヘプル
        $this->load->helper('url');
        // ライプラリ
		$this->load->library('session');
        $this->load->library('validation');
		$this->load->library('convert_format');
        // モデル
        $this->load->model('anq_download_mo');
		$this->load->model('menu_mo');
    }
    public function index() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
		
		if (isset($admin_id)) {
			$Course = $this->input->post('Course');
			$param = array(
                "R00_Dest_Kbn" => $Course['R00_Dest_Kbn'],
                "R00_Dest_Code" =>  $Course['R00_Dest_Code'],
                "R00_Han" => $Course['R00_Han']
            );
			
			/*echo '<pre>';
			print_r($param);
			echo '</pre>';
			exit;*/
			$this->download_csv($param);
		
		}else{
			redirect(base_url("admin_con"));
		}
    }
	public function init_header() {
        $headers = array ();
            // 参加者基本情報
			$headers = array(
				"社員番号",
				"★所属部門",
				"姓（漢字）",
				"名（漢字）",
				"1感想：ツアーについて",
				"1意見：ツアーについて",
				"2満足度：オプショナルについて",
				"2意見：オプショナルについて",
				"3満足度：パーティーについて",
				"3意見：パーティーについて",
				"4満足度：ツアーデスクについて",
				"4満足度：ツアーデスクについて",
				"5満足度：",
				"5意見：",
				"6満足度：",
				"6意見：",
				"7満足度：",
				"7意見：",
				"8満足度：",
				"8意見：：",
				"9満足度：",
				"9意見：",
				"10満足度：",
				"10意見：",
				"次回企画への意見",
				"回答日",
			);
            
       
        return $headers;
    }

    
    public function download_csv($param) {

            date_default_timezone_set('Asia/Tokyo');
            $headers = $this->init_header();

            $title = 'アンケート';
            $fileName = mb_convert_encoding("AKTIO_2016_" . $title . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

            //output headers so that the file is downloaded rather than displayed
            header('Content-Type: text/csv; charset=utf-8');
           header('Content-Disposition: attachment; filename=' . $fileName);

             //create a file pointer connected to the output stream
           $output = fopen('php://output', 'w');

            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // output the column headings
            fputcsv($output, $headers);

            // write content to csv file
            // get search result
            $searchResult = $this->anq_download_mo->getReserveIdListByCourse($param);
			//var_dump($searchResult);
            if ($searchResult != NULL && count($searchResult) > 0) {
                foreach ( $searchResult as $result ) {					
                    $csvData = array ();
					$csvData['R00_Id']  = $result['R00_Id'];
					$csvData['R00_Division'] = $result['R00_Division'];	
					$csvData['R00_Sei'] = $result['R00_Sei'];
					$csvData['R00_Name'] = $result['R00_Name'];
					$csvData['R14_Anq_1_Level'] = $result['R14_Anq_1_Level'];	
					$csvData['R14_Anq_1_Text'] = $result['R14_Anq_1_Text'];	
					$csvData['R14_Anq_2_Level'] = $result['R14_Anq_2_Level'];	
					$csvData['R14_Anq_2_Text'] = $result['R14_Anq_2_Text'];	
					
					$csvData['R14_Anq_3_Level'] = $result['R14_Anq_3_Level'];	
					$csvData['R14_Anq_3_Text'] = $result['R14_Anq_3_Text'];	
						
					$csvData['R14_Anq_4_Level'] = $result['R14_Anq_4_Level'];
					$csvData['R14_Anq_4_Text'] = $result['R14_Anq_4_Text'];	
					$csvData['R14_Anq_5_Level'] = $result['R14_Anq_5_Level'];
					$csvData['R14_Anq_5_Text'] = $result['R14_Anq_5_Text'];	
					$csvData['R14_Anq_6_Level'] = $result['R14_Anq_6_Level'];	
					$csvData['R14_Anq_6_Text'] = $result['R14_Anq_6_Text'];	
					$csvData['R14_Anq_7_Level'] = $result['R14_Anq_7_Level'];		
					$csvData['R14_Anq_7_Text'] = $result['R14_Anq_7_Text'];	
					$csvData['R14_Anq_8_Level'] = $result['R14_Anq_8_Level'];
					$csvData['R14_Anq_8_Text'] = $result['R14_Anq_8_Text'];	
					$csvData['R14_Anq_9_Level'] = $result['R14_Anq_9_Level'];
	
					$csvData['R14_Anq_9_Text'] = $result['R14_Anq_9_Text'];	
					$csvData['R14_Anq_10_Level'] = $result['R14_Anq_10_Level'];
	
					$csvData['R14_Anq_10_Text'] = $result['R14_Anq_10_Text'];	
					
					
					$csvData['R14_Anq_Other'] = $result['R14_Anq_Other'];
					$csvData['R14_Anq_Date'] = $result['R14_Anq_Date'];
                   
                    fputcsv($output, $csvData);
                }
            }
       

        // close csv file
        fclose($output);
    }
}
