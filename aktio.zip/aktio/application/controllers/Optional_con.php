<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Optional_con extends CI_Controller {
    function Optional_con() {
        parent:: __construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->config('config');
        $this->load->model('user_top_mo');
        $this->load->model('common_mo');
        $this->load->model('optional_mo');
        $this->load->library('convert_format');
        date_default_timezone_set('Asia/Tokyo');
    }

    public function index(){
        //セクションから代表者ID　取得
        $staff_id = $this->session->userdata('R00_Id');
		//2017/04/25 Add by Ken
        $TravelerInfo = $this->optional_mo->getReserve($staff_id);		//2017/04/28
        $data['TravelerInfo'] = $TravelerInfo;
        //
        
         if ($staff_id == '' || $staff_id == null) {
            // セッションがなくなった場合はログインページに移動する
            redirect(base_url('login_con/logout'));
            return;
        } else {
             // 左メーニューをロードする
            $data['user_name'] = $this->getUserName();
            $optionals = $this->optional_mo->optionalReserve($staff_id);
            $data['R04_Id'] = $staff_id;
            $search_term = array(
                    'page'    => $this->input->post('page'),
                    'keyword' => $this->input->post('keyword')
            );
            $data['search_data'] = $search_term;
            // 申込んだオプショナルのデーター
            $data['optionals'] = $optionals;
            $kakuteiInfo = $this->getKakuteiInfo($staff_id);

            if ($kakuteiInfo != null) {
                $data['rate']=$this->optional_mo->getRateId($kakuteiInfo);
                $kakuteiInfo['M18_SubSystem_ID'] = 60;
                $kakuteiInfo['M18_Seq'] = 1;

                $data['limitSet'] = $this->optional_mo->getLimitSetByCourse($kakuteiInfo);
                $data['kensaku_data'] = $this->optional_mo->searchKey($search_term,$kakuteiInfo);
                $data['kakuteiInfo'] = $kakuteiInfo;
            } else {
                $data['rate'] = null;
                $data['limitSet'] = null;
                $data['kensaku_data'] = null;
                $data['kakuteiInfo'] = null;
            }
            $submit = $this->input->post('submit');
            if($submit == "検索する"){
                $data['submit_search'] =1;
            } else{
                $data['submit_search'] =0;
            }
            //echo $submit;
            $this->load->view('head_vi');
            $this->load->view('optional_vi', $data);
            return;
        }
    }

    /*
    * セクションからユーザ名取得
    */
    public function getUserName(){
        $staff_id = $this->session->userdata('R00_Id');
        $user_name = $this->user_top_mo->getUserName($staff_id);
        $data = $user_name;
        return $data;
    }


    public function search() {
        // Get admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) { // Check admin session
            $data = array();
            $tourCodes = $this->optional_mo->getAllTourCode();
            if ($tourCodes != NULL) {
                $data['tourCodes'] = $tourCodes;
            } else {
                $data['tourCodes'] = NULL;
            }
            $tourCategories = $this->optional_mo->getAllTourCategory();
            if ($tourCategories != NULL) {
                $data['tourCategories'] = $tourCategories;
            } else {
                $data['tourCategories'] = NULL;
            }
            $tourStatus = $this->optional_mo->getAllStatus();
            if ($tourStatus != NULL) {
                $data['tourStatus'] = $tourStatus;
            } else {
                $data['tourStatus'] = NULL;
            }
            $data['Charger_Type'] = $charger_type;
            if (isset($_POST['searchbtn'])) {
                // 検索キー
                $searchKey = $this->getSearchKey();
                $data['searchKey'] = $searchKey;
                // 検索結果
                $searchResults = $this->getSearchResultData();
                $data['searchResults'] = $searchResults;
            } else {
                // 検索キー
                $data['searchKey'] = NULL;
                // 検索結果
                $data['searchResults'] = NULL;
            }
            $this->load->view('admin_optional_vi' , $data);
            return;
        } else {
            redirect(base_url("admin_con"));
        }
    }

    public function getSearchResultData() {
        $searchKey = array();

        $searchKey = $this->getSearchKey();

        // getResultSearch
        $resultSearch = $this->optional_mo->getResultSearch($searchKey);

        return $resultSearch;
    }

    public function getSearchKey() {
        $searchKey = array();

        $searchKey['R04_Id_Start'] = !isset($_POST['R04_Id_Start'])?"":$_POST['R04_Id_Start'];
        $searchKey['R04_Id_End'] = !isset($_POST['R04_Id_End'])?"":$_POST['R04_Id_End'];

        $searchKey['R01_Sei'] = !isset($_POST['R01_Sei'])?"":$_POST['R01_Sei'];
        $searchKey['R01_Name'] = !isset($_POST['R01_Name'])?"":$_POST['R01_Name'];

        $searchKey['R01_Sei_Kana'] = !isset($_POST['R01_Sei_Kana'])?"":$_POST['R01_Sei_Kana'];
        $searchKey['R01_Name_Kana'] = !isset($_POST['R01_Name_Kana'])?"":$_POST['R01_Name_Kana'];

        $searchKey['R04_Register_Start'] = !isset($_POST['R04_Register_Start'])?"":$_POST['R04_Register_Start'];
        $searchKey['R04_Register_End'] = !isset($_POST['R04_Register_End'])?"":$_POST['R04_Register_End'];

        $searchKey['R04_Optional_Tour_Code'] = !isset($_POST['R04_Optional_Tour_Code'])?"":$_POST['R04_Optional_Tour_Code'];
        $searchKey['M08_Optional_Tour_Category'] = !isset($_POST['M08_Optional_Tour_Category'])?"":$_POST['M08_Optional_Tour_Category'];
        $searchKey['R04_STS'] = !isset($_POST['R04_STS'])?"":$_POST['R04_STS'];

        return $searchKey;
    }



    public function  optional_entry(){
         //セクションからユーザID　取得
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $data['user_name'] = $this->getUserName();
            $submit = $this->input->post('submit');
            $tour_code   = $_POST['M08_Optional_Tour_Code'];
            $tour_seq   = $_POST['M08_Seq'];
            $search_term = array(
                'page'    => $this->input->post('page'),
                'keyword' => $this->input->post('keyword')
            );
            $data['search_data'] = $search_term;
            $data['tour'] = $this->optional_mo->getOptional_Code($tour_code,$tour_seq);
            $kakuteiInfo = $this->getKakuteiInfo($R00_Id);
            $data['kakuteiInfo'] = $this->getKakuteiInfo($R00_Id);
            $data['rate']=$this->optional_mo->getRateId($kakuteiInfo);
            $data['dateTypeList'] = $this->optional_mo->getDatetype();
			$data['participantInfo'] = $this->user_top_mo->getUserInfo($R00_Id);
            $data['traveler']  = $this->optional_mo->getTravelerInfo($R00_Id);
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $data['CourseTodo'] = $this->optional_mo->getM02CourseTodo($CourseArr);
            //var_dump($CourseArr );
            $optionals = $this->optional_mo->optionalReserve($R00_Id);
            $data['optionals'] = $optionals;
            $this->load->view('head_vi');
            $this->load->view('optional_entry_vi', $data);
            return;
        }
    }
    public function optional_confirm(){
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $data['user_name'] = $this->getUserName();
            $data['R04_Id'] = $R00_Id;
            $search_term = array(
                'page'    => $this->input->post('page'),
                'keyword' => $this->input->post('keyword')
            );
            $data['search_data'] = $search_term;
            $submit = $this->input->post('submit');

            $today = $this->input->post('today');
            $optHayaDate = $this->input->post('M02_OP_Haya_Schedule');
            if (strtotime($today) < strtotime($optHayaDate)) {
                $R04_Cost_Adult_haya = !isset($_POST['M08_Optional_Cost_Adult_haya'])?"0":$_POST['M08_Optional_Cost_Adult_haya'];
                $R04_Cost_Child1_haya = !isset($_POST['M08_Optional_Cost_Child1_haya'])?"0":$_POST['M08_Optional_Cost_Child1_haya'];
                $R04_Cost_Child2_haya = !isset($_POST['M08_Optional_Cost_Child2_haya'])?"0":$_POST['M08_Optional_Cost_Child2_haya'];
				$R04_Cost_Child3_haya = !isset($_POST['M08_Optional_Cost_Child3_haya'])?"0":$_POST['M08_Optional_Cost_Child3_haya'];
                $R04_Cost_Infant_haya = !isset($_POST['M08_Optional_Cost_Infant_haya'])?"0":$_POST['M08_Optional_Cost_Infant_haya'];
            } else {
                $R04_Cost_Adult_haya = 0;
                $R04_Cost_Child1_haya = 0;
                $R04_Cost_Child2_haya = 0;
				$R04_Cost_Child3_haya = 0 ;
                $R04_Cost_Infant_haya = 0;
            }
            $optional = array(
                'R04_Optional_Tour_Code' =>!isset($_POST['R04_Optional_Tour_Code'])?"":$_POST['R04_Optional_Tour_Code'],
                'R04_Seq' =>!isset($_POST['R04_Seq'])?"":$_POST['R04_Seq'],
                'R04_Optional_Tour_Name'=>!isset($_POST['R04_Optional_Tour_Name'])?"":$_POST['R04_Optional_Tour_Name'],
                'R04_Optional_Tour_Title'=>!isset($_POST['R04_Optional_Tour_Title'])?"":$_POST['R04_Optional_Tour_Title'],
                'R04_Optional_Kibou_Date' => !isset($_POST['R04_Optional_Kibou_Date'])?"":$_POST['R04_Optional_Kibou_Date'],
                'M08_Time' =>!isset($_POST['M08_Time'])?"":$_POST['M08_Time'],
                'R04_Optional_Kibou_Time' =>!isset($_POST['R04_Optional_Kibou_Time'])?"":$_POST['R04_Optional_Kibou_Time'],
                'R04_Tour_Adult' => !isset($_POST['R04_Tour_Adult'])?"":$_POST['R04_Tour_Adult'],
                'R04_Tour_Child1' => !isset($_POST['R04_Tour_Child1'])?"":$_POST['R04_Tour_Child1'],
                'R04_Tour_Child2' => !isset($_POST['R04_Tour_Child2'])?"":$_POST['R04_Tour_Child2'],
				'R04_Tour_Child3' => !isset($_POST['R04_Tour_Child2'])?"":$_POST['R04_Tour_Child3'],
                'R04_Tour_Infant' => !isset($_POST['R04_Tour_Infant'])?"":$_POST['R04_Tour_Infant'],
                'R04_Tour_Child' => !isset($_POST['R04_Tour_Child'])?"":$_POST['R04_Tour_Child'],
                'R04_Tour_Participation_Total' => !isset($_POST['R04_Tour_Participation_Total'])?"":$_POST['R04_Tour_Participation_Total'],
                'R04_Tour_Cost'=> !isset($_POST['R04_Tour_Cost'])?"":$_POST['R04_Tour_Cost'],
                'R04_Cost_Adult_haya'=> $R04_Cost_Adult_haya,
                'R04_Cost_Child1_haya'=> $R04_Cost_Child1_haya,
                'R04_Cost_Child2_haya'=> $R04_Cost_Child2_haya,
				'R04_Cost_Child3_haya'=> $R04_Cost_Child3_haya,
                'R04_Cost_Infant_haya'=> $R04_Cost_Infant_haya,
                'R04_Tour_Jpy'=> !isset($_POST['R04_Tour_Jpy'])?"":$_POST['R04_Tour_Jpy'],
                'R04_Tour_Rate'=> !isset($_POST['R04_Tour_Rate'])?"":$_POST['R04_Tour_Rate'],
                'R04_Tour_Option_Name'=> !isset($_POST['M08_Tour_Option_Name'])?"":$_POST['M08_Tour_Option_Name'],
                'R04_Tour_Note'=> !isset($_POST['R04_Tour_Note'])?"":$_POST['R04_Tour_Note'],
                'jpy_id'=> !isset($_POST['jpy_id'])?"":$_POST['jpy_id']
            );
            for($i=0;$i<8;$i++){
                $data['R04_Tour_ParticipationPlan'][$i]= !isset($_POST['R04_Tour_ParticipationPlan'.$i])?"":1 ;
                $data['R04_option_Id'][$i]= !isset($_POST['R04_option_Id'.$i])?"":$_POST['R04_option_Id'.$i];
            }
            $tmp = "";
            for ($i = 0 ; $i <=8  ; $i++) {
                $R04_option_Id  = !isset($_POST['R04_option_Id'.$i])?"":$_POST['R04_option_Id'.$i];
                if ($R04_option_Id != '') {
                    $participant = $this->user_top_mo->getParticipantOptionalsByPlanAndUserId($R00_Id , $i);
                    if ($participant != null) {
                        $tmp['partOption'][]= $participant;
                    }
                }
            }
            $data['option']= $tmp;
            $Option_Reserve = $_POST;
            $option_name =  !isset($Option_Reserve['Optional_Reserve'])?"":$Option_Reserve['Optional_Reserve'];
            $data['option_name'] = $option_name ;

            $kakuteiInfo = $this->getKakuteiInfo($R00_Id);
            $data['kakuteiInfo'] = $kakuteiInfo ;
            $data['rate']=$this->optional_mo->getRateId($kakuteiInfo);
            $data['optional'] = $optional;
            $data['date_type'] = $this->optional_mo->getDatetypebyId($data['optional']['R04_Optional_Kibou_Date']);
            $this->load->view('head_vi');
            $this->load->view('optional_confirm_vi', $data);
            return;
        }

    }
    /**
    *update R04_Optional_Reserve
    *
    **/public function SaveReserve(){
        $today = date('Y-m-d H:i:s', time());
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        } else {
            $data['user_name'] = $this->getUserName();
            $submit = $this->input->post('submit');
            $staffId = $this->input->post('R04_Id');
            $optionalCode =

            $params = array(
                "R04_Id"                       => $this->input->post('R04_Id'),
                "R04_Optional_Tour_Code"       => $this->input->post('R04_Optional_Tour_Code'),
                "R04_Seq"                      => $this->input->post('R04_Seq'),
                "R04_Optional_Tour_Name"       => $this->input->post('R04_Optional_Tour_Name'),
                "R04_Optional_Tour_Title"      => $this->input->post('R04_Optional_Tour_Title'),
                "R04_Optional_Kibou_Date"      => $this->input->post('R04_Optional_Kibou_Date'),
                "R04_Optional_Kibou_Time"      => $this->input->post('R04_Optional_Kibou_Time'),
                "R04_Tour_Adult"               => $this->input->post('R04_Tour_Adult'),
                "R04_Tour_Child1"              => $this->input->post('R04_Tour_Child1'),
                "R04_Tour_Child2"              => $this->input->post('R04_Tour_Child2'),
				"R04_Tour_Child3"              => $this->input->post('R04_Tour_Child3'),
                "R04_Tour_Infant"              => $this->input->post('R04_Tour_Infant'),
                "R04_Tour_Participation_Total" => $this->input->post('R04_Tour_Participation_Total'),
                "R04_Tour_Cost"                => $this->input->post('R04_Tour_Cost'),
                "R04_Cost_Adult_haya"          => $this->input->post('R04_Cost_Adult_haya'),
                "R04_Cost_Child1_haya"         => $this->input->post('R04_Cost_Child1_haya'),
                "R04_Cost_Child2_haya"         => $this->input->post('R04_Cost_Child2_haya'),
				 "R04_Cost_Child3_haya"         => $this->input->post('R04_Cost_Child3_haya'),
                "R04_Cost_Infant_haya"         => $this->input->post('R04_Cost_Infant_haya'),
                "R04_Tour_Jpy"                 => $this->input->post('R04_Tour_Jpy'),
                "R04_Tour_Rate"                => $this->input->post('R04_Tour_Rate'),
                "R04_Tour_Note"                => $this->input->post('R04_Tour_Note'),
                "R04_Create_Date"              => $today
            );
            if($params['R04_Tour_Jpy'] == 0){
                $params['R04_STS'] = 8;
            }
			 if(($params['R04_Optional_Tour_Code'] == 'LAS1001') ||  ($params['R04_Optional_Tour_Code'] == 'LAS1101')  || ($params['R04_Optional_Tour_Code'] == 'LAS1201')  || ($params['R04_Optional_Tour_Code'] == 'LAS1301') ){
                $params['R04_STS'] = 8;
            }
            for ($i=0;$i<=8;$i++){
                    $params["R04_Tour_ParticipationPlan".$i] =  $this->input->post('R04_Tour_ParticipationPlan'.$i);
                }
                $partOption = !isset($_POST['R01_Plan'])?"":$_POST['R01_Plan'];
                $Option_Reserve = !isset($_POST['Option_Reserve'])?"":$_POST['Option_Reserve'];


            if ($submit=="申込"){			
                $R04_Pkey_Sub = $this->optional_mo->insertR04Reserve( $params );											
                foreach($partOption  as $key => $optionVal){
                    $k = "";
                    $option = "";
                    $option['R04_Id']				   = $R00_Id;
					$option['R04_Pkey_Sub']			   = $R04_Pkey_Sub;
                    $option['R04_Optional_Tour_Code']  = $params['R04_Optional_Tour_Code'];
                    $option['R04_Seq']				   =  $params['R04_Seq'];
                    $option['R04_Plan']				   =  $optionVal;
                    $option['R04_Optional_Tour_Name']  =  $params['R04_Optional_Tour_Name'];
                    $option['R04_Tour_Option_Name']    = !isset($_POST['R04_Tour_Option_Name'])?"":$_POST['R04_Tour_Option_Name'];
					/*希望日、希望時間*/
					$option['R04_Optional_Kibou_Date'] = !isset($_POST['R04_Optional_Kibou_Date'])?"":$_POST['R04_Optional_Kibou_Date'];
					$option['R04_Optional_Kibou_Time'] = !isset($_POST['R04_Optional_Kibou_Time'])?"":$_POST['R04_Optional_Kibou_Time'];
                    for($i = 1; $i<=10; $i++ ){
                        $k = $optionVal.$i;

                        if(isset($Option_Reserve[$k]) && $Option_Reserve[$k] != null){

                            $option['R04_Tour_Option'.$i.'_Name'] = $Option_Reserve[$k];

                        }

                    }
                    //var_dump($option);
                    $this->optional_mo->setReserve_Option($option);

                }

                redirect(base_url('optional_con'));
            }elseif ($submit=="前の画面へ"){
                $tour_code   = $this->input->post('R04_Optional_Tour_Code');
                $tour_seq   = $this->input->post('R04_Seq');
            /*$search_term = array(
            'page'    =>   $this->input->post('page'),
            'category'    =>    $this->input->post('category'),
            'keyword'    =>    $this->input->post('keyword')
            );*/
            //$data['search_data'] = $search_term;
            for ($i=0;$i<=8;$i++){
                    $data['R04_Tour_ParticipationPlan'][$i] =  $this->input->post('R04_Tour_ParticipationPlan'.$i);
                }

            $search_term = array(
            'page'    =>   $this->input->post('page'),

            'keyword'    =>    $this->input->post('keyword'));
            $data['search_data'] = $search_term;
            $submit = $this->input->post('submit');
			$data['participantInfo'] = $this->user_top_mo->getUserInfo($R00_Id);
            $data['traveler']  = $this->optional_mo->getTravelerInfo($R00_Id);
            $data['dateTypeList'] = $this->optional_mo->getDatetype();
            if(isset($partOption) && $partOption != ""){
                $data['partOption'] = $partOption;
            }
            if(isset($Option_Reserve) && $Option_Reserve != ""){
                $data['Option_Reserve'] = $Option_Reserve;
            }
            $CourseArr = $this->user_top_mo->getKakuteiCourseId($R00_Id);
            $data['CourseTodo'] = $this->optional_mo->getM02CourseTodo($CourseArr);
            $kakuteiInfo = $this->getKakuteiInfo($R00_Id);
            $data['kakuteiInfo'] = $kakuteiInfo;
            $data['rate']=$this->optional_mo->getRateId($kakuteiInfo);
            $data['tour'] = $this->optional_mo->getOptional_Code($tour_code,$tour_seq);
            $data['R04_Optional_Kibou_Date'] = $this->input->post('R04_Optional_Kibou_Date');
            $data['R04_Optional_Kibou_Time'] = $this->input->post('R04_Optional_Kibou_Time');
            $data['R04_Tour_Adult'] = $this->input->post('R04_Tour_Adult');
            $data['R04_Tour_Child1'] = $this->input->post('R04_Tour_Child1');
            $data['R04_Tour_Child2'] = $this->input->post('R04_Tour_Child2');
			$data['R04_Tour_Child3'] = $this->input->post('R04_Tour_Child3');
            $data['R04_Tour_Infant'] = $this->input->post('R04_Tour_Infant');
            $data['R04_Tour_Child'] = $this->input->post('R04_Tour_Child');
            $data['R04_Tour_Participation_Total'] = $this->input->post('R04_Tour_Participation_Total');
            $data['R04_Tour_Cost'] = $this->input->post('R04_Tour_Cost');
            $data['R04_Tour_Rate'] = $this->input->post('R04_Tour_Rate');
            $data['R04_Tour_Jpy'] = $this->input->post('R04_Tour_Jpy');
            $data['jpy_id'] = $this->input->post('jpy_id');
            $data['R04_Tour_Note']= $this->input->post('R04_Tour_Note');
                $this->load->view('head_vi');
                $this->load->view('optional_entry_vi', $data);
                return;
            }
        }
    }
    public function getKakuteiInfo($prams) {
        $CourseArr = $this->user_top_mo->getKakuteiCourseId($prams);
        $data['kakuteiInfo'] = $this->user_top_mo->getKakuteCourseById($CourseArr);
        return $data['kakuteiInfo'] ;
    }
    public function updateSTS($prams) {
        $today = date('Y-m-d H:i:s', time());
        $R00_Id = $this->session->userdata('R00_Id');
        if ($R00_Id == '' || $R00_Id == null) {
            redirect(base_url('login_con/logout'));
            return;
        }else{
            $params['R04_Id']              = $R00_Id;
            $params['R04_Optional_Tour_Code']  = $_POST['R04_Optional_Tour_Code'];
            $params['R04_Seq'] = $_POST['R04_Seq'];
            $params['R04_UpdateTime']  = $today;
            $params['R04_STS']      = 4;

            $updateResult = $this->optional_mo->UpdateSTSOptional($params);

            if($updateResult > 0){
                echo 'success';
            }else{
                echo 'error';
            }
        }
    }

}
?>
