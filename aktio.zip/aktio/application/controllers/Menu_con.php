﻿<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Menu_con extends CI_Controller
{
    public function Menu_con() {
        parent::__construct();
        // ヘプル
        $this->load->helper('url');
        // ライプラリ
        $this->load->library('session');
        $this->load->library('validation');
        // モデル
        $this->load->model('menu_mo');
        $this->load->model('common_mo');
        $this->load->model("login_mo");
        $this->load->model("entry_mo");
        $this->load->model("user_top_mo");
        $this->load->model("transport_ptn_mo");
        $this->load->model("admin_edit_mo");
        $this->load->model("total_mo");
        $this->load->library('excel');
        $this->load->library('ExcelAirNameList');
        $this->load->library('ExcelESTA');
        $this->load->library('ExcelETAS');
        $this->load->library('ExcelCNMI');
        $this->load->library('ExcelInsuranceList');
        $this->load->library('convert_format');
    }
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // メニュー画面
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * メニュー作成するメソッド
     */
    public function index() {
        // Check session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        $data['results'] = NULL;
        if (isset($admin_id)) {
            $data['charger_type'] = $charger_type;
            $charger_entitle = $this->total_mo->getChargerEntitle($admin_id , $charger_type);
            $data['charger_entitle'] = $charger_entitle;
            // ツアーデータ取得
            $data['For_Courses'] = $this->menu_mo->getCourseForeignData();
            $data['Domes_Courses'] = $this->menu_mo->getCourseDomesticData();
            // 全てのコース取得

            if($charger_type == 2){
                $All_Course = $this->menu_mo->getAllCourseDataIns();
            } elseif ($charger_type == 1) {
                $All_Course = $this->menu_mo->getAllCourseData();
            }elseif ($charger_type == 3) {
                $All_Course = $this->menu_mo->getAllCourseData();
            }

            if ($charger_type != 0) {
                foreach ( $All_Course as $key => $val ) {
                    $CourseMaster = substr($val['M01_Course_Id'], 0, strcspn($val['M01_Course_Id'], '1234567890'));
                    $M01_CourseArr = $this->createM01CourseArray($val);
                    $M01_Course_Id = $M01_CourseArr['M01_Dest_Code'] . $M01_CourseArr['M01_Han'] . $M01_CourseArr['M01_Dep_Id'] . $M01_CourseArr['M01_Air_Program'];
                    $results_AllCourse_tmp[$M01_Course_Id] = $this->menu_mo->getSearchResultByCourseMaster($M01_CourseArr, NULL, $CourseMaster, $charger_entitle , $admin_id);
                }
                $results = $this->Search_Process($results_AllCourse_tmp);
                $data['results'] = $results;
            }

            $this->load->view('header_admin_vi', $data);

            //charger_type :2 保険会社用
            if($charger_type == 2){
                $this->load->view('insurance_menu_vi', $data);
            }else{
                $this->load->view('admin_menu_vi', $data);
            }
            $this->load->view('footer_vi');
        } else {
            redirect(base_url("admin_con"));
        }
    }

    /**
     * 検索共有メソッド
     * コースの人数の計算する
     *
     * @param unknown $data
     */
    public function Search_Process($data) {
        if (count($data) > 0) {
            // 同行者取得
            $results = NULL;
            foreach ( $data as $keys => $vals ) {
                if ($vals != NULL || $vals != '') {
                    $i = 0;
                    $doko_count = 0;
                    $doko_cancelcount = 0;
                    $honnin_cancelcount = 0;
                    foreach ( $vals as $key => $val ) {

                        // 同行者人数を取得する
                        $data[$keys][$i]['doko_cnt'] = $this->menu_mo->getCountDokoshaById($val['R00_Id']);

                        //キャンセルした同行者人数を取得する。
                        $data[$keys][$i]['doko_cancelcount'] = $this->menu_mo->getTotalCancelOfDokoshaById($val['R00_Id']);

                        //キャンセルした本人数を取得する。
                        $data[$keys][$i]['honnin_cancelcount'] = $this->menu_mo->getTotalCancelOfParticipationById($val['R00_Id']);

                        //同行者人数足す
                        $doko_count += $data[$keys][$i]['doko_cnt'];
                        $data[$keys][0]['doko_cnt'] = $doko_count;

                        //キャンセルした同行者人数足す
                        $doko_cancelcount += $data[$keys][$i]['doko_cancelcount'];
                        $data[$keys][0]['doko_cancelcount'] = $doko_cancelcount;

                        //キャンセルした本人数足す
                        $honnin_cancelcount += $data[$keys][$i]['honnin_cancelcount'];
                        $data[$keys][0]['honnin_cancelcount'] = $honnin_cancelcount;

                        $i ++;
                    }
                }
            }
            $i = 0;
            foreach ( $data as $key => $val ) {
                if ($val != NULL || $val != '') {
                    $results[$i] = $val[0];
                    $results[$i]['shainn'] = count($val);
                    unset($results[$i]['R00_Id']);
                }
                $i ++;
            }
            if (count($results) > 0) {
                foreach ( $results as $result ) {
                    $newArray[] = $result;
                }
                return $newArray;
            } else {
                return NULL;
            }
        }
    }

    /**
     * 検索処理
     */
    public function search() {
        // Get admin session
        $admin_id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_id)) { // Check admin session
            // 初期化
            $data = array ();
            // 制限データー
            $charger_entitle = $this->total_mo->getChargerEntitle($admin_id , $charger_type);
            $data['charger_type'] = $charger_type;
            $data['charger_entitle'] = $charger_entitle;
            // 検索分の処理
            $data['results'] = NULL;
            $results_tmp = NULL;
            $M00_Course_Id_Pre = ! isset($_POST['tour']) ? "" : $_POST['tour'];
            $kako = ! isset($_POST['kako']) ? "" : $_POST['kako'];
            if ($M00_Course_Id_Pre != '' || $M00_Course_Id_Pre != NULL) {
                // コースマスタ取得
                $M01_Course = $this->menu_mo->getCoursesById($M00_Course_Id_Pre);
                if (count($M01_Course) > 0) {
                    foreach ( $M01_Course as $key => $val ) {
                        $M01_CourseArr = $this->createM01CourseArray($val);
                        $M01_Course_Id = $M01_CourseArr['M01_Dest_Code'] . $M01_CourseArr['M01_Han'] . $M01_CourseArr['M01_Dep_Id'] . $M01_CourseArr['M01_Air_Program'];
                        $results_tmp[$M01_Course_Id] = $this->menu_mo->getSearchResultByCourseMaster($M01_CourseArr, $kako, $M00_Course_Id_Pre, $charger_entitle , $admin_id);
                    }
                }
            } else {
                // 未選択
                // 全てのコース取得
                if($charger_type ==2){
                    $All_Course = $this->menu_mo->getAllCourseDataIns();
                }else{
                    $All_Course = $this->menu_mo->getAllCourseData();
                }
                $results_tmp = null;
                /*
                foreach ( $All_Course as $key => $val ) {
                    $CourseMaster = substr($val['M01_Course_Id'], 0, strcspn($val['M01_Course_Id'], '1234567890'));
                    $M01_CourseArr = $this->createM01CourseArray($val);
                    $M01_Course_Id = $M01_CourseArr['M01_Dest_Code'] . $M01_CourseArr['M01_Han'] . $M01_CourseArr['M01_Dep_Id'] . $M01_CourseArr['M01_Air_Program'];
                    $results_tmp[$M01_Course_Id] = $this->menu_mo->getSearchResultByCourseMaster($M01_CourseArr, $kako, $CourseMaster, $charger_entitle , $admin_id);
                }
                */

            }
            $results = $this->Search_Process($results_tmp);
            $data['results'] = $results;
            $data['tour'] = $M00_Course_Id_Pre;
            $data['kako'] = $kako;
            $data['title'] = '管理画面';
            // ツーアデータ取得
            $data['For_Courses'] = $this->menu_mo->getCourseForeignData();
            $data['Domes_Courses'] = $this->menu_mo->getCourseDomesticData();
            $this->load->view('header_admin_vi', $data);
            if($charger_type ==2){
                $this->load->view('insurance_menu_vi', $data);
            }else{
                $this->load->view('admin_menu_vi', $data);
            }


            $this->load->view('footer_vi');
        } else {
            redirect(base_url("admin_con"));
        }
    }
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 検索ー画面
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * コース詳細画面
     */
    public function course_detail() {
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        // 初期化
        $CourseData = NULL;
        $data['results'] = NULL;
        $error = NULL;
        $data['error'] = NULL;
        $param = array (
                'R00_Id_St' => '',
                'R00_Id_End' => '',
                'R00_Sei' => '',
                'R00_Name' => '',
                'R00_Sei_Kana' => '',
                'R00_Name_Kana' => '',
                'R00_Mailaddress' => '',
                'R00_Division' => '',
                'R00_Group_No'=>'',
                'R05_Kojin_Finish_flag_zumi' => '1',
                'R05_Kojin_Finish_flag_mi' => '1',
                'R05_OP_Yes' => '1',
                'R05_OP_No' => '1' ,
                'R01_Cancel_flag' => '0'
        );
        if (isset($admin_Id)) {
            $Course_Data = ! isset($_POST['Course']) ? "" : $_POST['Course'];
            // メール検索と通常
            $process = ! isset($_POST['process']) ? "" : $_POST['process'];
            // コースの取得
            if (isset($Course_Data['R00_Dest_Code'])) {
                // データ取得の為配列キー変更
                $CourseArr = $this->ChangeArrKey($Course_Data, 'M01');
                $TodoArr = $this->ChangeArrKey($Course_Data, 'M02');
                $LimitSetArr = $this->ChangeArrKey($Course_Data , 'M18');

                $CourseDataMaster = $this->menu_mo->getM01Course($CourseArr);
                $Course_Todo = $this->menu_mo->getM02CourseTodo($TodoArr);
                $Course_Optional_Limit = $this->menu_mo->getM18CourseOptionalLimit($LimitSetArr);
                $Course_Payment_Limit = $this->menu_mo->getM18CoursePaymentLimit($LimitSetArr);

                // convert key with optional , payment
                if ($Course_Optional_Limit != null) {
                    $optional_limit = $this->convertKeyLimitSet($Course_Optional_Limit, 'Optional');
                } else {
                    $optional_limit = null;
                }
                if ($Course_Payment_Limit != null) {
                    $payment_limit  = $this->convertKeyLimitSet($Course_Payment_Limit , 'Payment');
                } else {
                    $payment_limit = null;
                }
                if ($optional_limit != null) {
                    $Course_Todo = array_merge($Course_Todo , $optional_limit);
                }
                if ($payment_limit != null) {
                    $Course_Todo = array_merge($Course_Todo , $payment_limit);
                }

                // 所属の取得
                $DivisionData = $this->menu_mo->getAllDivisionName();
                if ($this->input->post('status') == 'search') {
                    // エーラチェック
                    $param = array (
                            'R00_Dest_Kbn' => $Course_Data['R00_Dest_Kbn'],
                            'R00_Dest_Code' => $Course_Data['R00_Dest_Code'],
                            'R00_Han' => $Course_Data['R00_Han'],
                            'R00_Dep_Id' => $Course_Data['R00_Dep_Id'],
                            'R00_Air_Program' => $Course_Data['R00_Air_Program'],
                            'R00_Id_St' => $this->input->post('R00_Id_St'),
                            'R00_Id_End' => $this->input->post('R00_Id_End'),
                            'R00_Sei' => $this->input->post('R00_Sei'),
                            'R00_Name' => $this->input->post('R00_Name'),
                            'R00_Sei_Kana' => $this->input->post('R00_Sei_Kana'),
                            'R00_Name_Kana' => $this->input->post('R00_Name_Kana'),
                            'R00_Mailaddress' => $this->input->post('R00_Mailaddress'),
                            'R00_Division' => $this->input->post('R00_Division'),
                            'R00_Group_No' => $this->input->post('R00_Group_No'),
                            'R05_Kojin_Finish_flag_zumi' => $this->input->post('R05_Kojin_Finish_flag_zumi'),
                            'R05_Kojin_Finish_flag_mi' => $this->input->post('R05_Kojin_Finish_flag_mi'),
                            'R05_OP_Yes' => $this->input->post('R05_OP_Yes'),
                            'R05_OP_No' => $this->input->post('R05_OP_No') ,
                            'R01_Cancel_flag' => $this->input->post('R01_Cancel_flag')
                    );
                    $data['param'] = $param;
                    if ($param['R00_Id_St'] != '' || $param['R00_Id_End'] != '') {
                        if (($this->validation->HankakuChk($param['R00_Id_St']) == FALSE) || ($this->validation->HankakuChk($param['R00_Id_End']) == FALSE)) {
                            $error['R00_Id'] = '＊社員番号は半角で入力してください。';
                        }
                    }
                    if ($param['R00_Sei'] != '') {
                        if (($this->validation->kanji_chk($param['R00_Sei']) == FALSE)) {
                            $error['R00_Sei'] = '＊お名前(姓)は漢字で入力してください。';
                        }
                    }
                    if ($param['R00_Name'] != '') {
                        if (($this->validation->kanji_chk($param['R00_Name']) == FALSE)) {
                            $error['R00_Name'] = '＊お名前(名)は漢字で入力してください。';
                        }
                    }
                    if ($param['R00_Sei_Kana'] != '') {
                        if (($this->validation->kana_chk($param['R00_Sei_Kana']) == FALSE)) {
                            $error['R00_Sei_Kana'] = '＊お名前(姓)はカナで入力してください。';
                        }
                    }
                    if ($param['R00_Name_Kana'] != '') {
                        if (($this->validation->kana_chk($param['R00_Name_Kana']) == FALSE)) {
                            $error['R00_Name_Kana'] = '＊お名前(名)はカナで入力してください。';
                        }
                    }
                    if ($param['R00_Mailaddress'] != '') {
                        if (! $this->validation->mail_chk($param['R00_Mailaddress'])) {
                            $error['R00_Mailaddress'] = '＊メールアドレスが不正です。';
                        }
                    }
                    if ($param['R00_Group_No'] != '') {
                        if (($this->validation->HankakuChk($param['R00_Group_No']) == FALSE)) {
                            $error['R00_Group_No'] = '＊グループIDは半角で入力してください。';
                        }
                    }
                    if (empty($error)) {
                        $data['results'] = $this->menu_mo->SearchReservation($param);
                        if (count($data['results']) > 0) {
                            $i = 0;
                            foreach ( $data['results'] as $row ) {
                                $data['results'][$i]['doko'] = $this->menu_mo->getCountDokoshaById($row['R00_Id']);
                                $i ++;
                            }
                        }
                    }
                }
            } else {
                redirect(base_url("menu_con"));
            }
            $data['param'] = $param;
            $data['charger_type'] = $charger_type;
            $data['CourseData'] = $CourseDataMaster[0];
            $data['Course_Todo'] = $Course_Todo;

            $data['DivisionDatas'] = $DivisionData;
            $data['error'] = $error;
            $destESTA = $this->menu_mo->getDestCodeByESTA();
            $data['destESTA'] = $destESTA;
            $destETAS = $this->menu_mo->getDestCodeByETAS();
            $data['destETAS'] = $destETAS;
            $destCNMI = $this->menu_mo->getDestCodeByCNMI();
            $data['destCNMI'] = $destCNMI;
            if ($process == 'mail') {
                $data['title'] = "コース検索画面メール送信用";
                $this->load->view('header_admin_vi', $data);
                $this->load->view('mail/admin_search_mail_vi', $data);
            } else {
                $errorFlg = '';
                if ($process == 'download_passport') {
                    $errorFlg = $this->download_passport_img();
                }
                if ($process == 'download_esta') {
                    $errorFlg = $this->download_esta_info();
                }
                if ($process == 'download_etas') {
                    $errorFlg = $this->download_etas_info();
                }
                if ($process == 'download_cnmi') {
                    $errorFlg = $this->download_cnmi_info();
                }
                $data['errorFlg'] = $errorFlg;
                $data['title'] = "コース検索画面";
                $this->load->view('header_admin_vi', $data);
                $this->load->view('admin_search_vi', $data);
            }
        } else {
            redirect(base_url('admin_con'));
        }
    }

    private function convertKeyLimitSet($limitSetData , $newStrKey) {
        $tmp = array();
        foreach ($limitSetData as $key => $limitSet) {
            $newKey = str_replace('M18', 'M18_' . $newStrKey , $key);
            $tmp[$newKey] = $limitSet;
        }
        return $tmp;
    }

    /**
     * 検索画面の初期化メソッド
     */
    public function menu() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $data = array ();
            $data['Charger_Type'] = $charger_type;
            $course_id = ! isset($_POST['course_id']) ? "" : $_POST['course_id'];
            $getcourse_id = $this->menu_mo->getIdCourseData($course_id);
            $data['course_id'] = $getcourse_id;
            // var_dump($data['course_id']);
            // 会社のリスト
            $companyList = $this->menu_mo->getAllCompanyName();
            $data['companies'] = $companyList;
            // 部署のリスト
            $divisionList = $this->menu_mo->getAllDivisionName();
            $data['divisons'] = $divisionList;
            // 支店のリスト
            $branchList = $this->menu_mo->getAllBranchName();
            $data['branchs'] = $branchList;
            // 出発地方リスト
            $departureList = $this->menu_mo->getAllDepartureData();
            $data['depertures'] = $departureList;
            // コースリストを取得
            $data['course_data'] = $this->menu_mo->getAllCourseData();
            $data['result'] = NULL;
            $this->load->view('header_admin_vi', $data);
            $this->load->view('admin_search_vi', $data);
        } else {
            redirect(base_url('admin_con'));
        }
    }

    /*
     *
     * 終了日　更新,完了
     */
    public function ChangeFinishDate() {
        $param = array (
            'date' => $this->input->post('date'),
            'data' => $this->input->post('data'),
            'M18_SubSystem_ID' => $this->input->post('M18_SubSystem_ID'),
            'Han' => $this->input->post('Han'),
            'Dest_kbn' => $this->input->post('Dest_kbn'),
            'Dest_Code' => $this->input->post('Dest_Code'),
            'Dep_Id' => $this->input->post('Dep_Id'),
            'Air_Program' => $this->input->post('Air_Program')
        );
        if ($this->menu_mo->isExistLimitSet($param)) {
            $result = $this->menu_mo->UpdateFinishDate($param);
        } else {
            $result = $this->menu_mo->insertFinishDate($param);
        }
        if ($result != - 1) {
            echo trim('success');
        } else {
            echo trim('fail');
        }
    }
    public function table() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $data = array ();
            $data['Charger_Type'] = $charger_type;
            $data['course_data'] = $this->menu_mo->getTableCourseData();
            $this->load->view('tour_calendar', $data);
        } else {
            redirect(base_url('admin_con'));
        }
    }

    /**
     * コース取得
     */
    public function getCourse() {
        $course = $this->input->post('course');
        $result = $this->entry_mo->getCourseByDest($course);
        $data = array ();
        foreach ( $result as $row ) {
            $data[] = $row;
        }
        echo json_encode($data);
    }

    /**
     * 海外国内取得
     */
    public function getTourType() {
        $course = $this->input->post('course');
        $result = $this->entry_mo->getTourByStatus($course);
        $data = array ();
        foreach ( $result as $row ) {
            $data[] = $row;
        }
        echo json_encode($data);
    }

    /**
     * 検索ページからの検索キーを取得する
     *
     * @return キー配列
     */
    public function getSearchKey() {
        $searchKey = array ();

        $searchKey['R00_Id_Start'] = ! isset($_POST['R00_Id_Start']) ? "" : $_POST['R00_Id_Start'];
        $searchKey['R00_Id_End'] = ! isset($_POST['R00_Id_End']) ? "" : $_POST['R00_Id_End'];
        $searchKey['R00_Sei'] = ! isset($_POST['R00_Sei']) ? "" : $_POST['R00_Sei'];
        $searchKey['R00_Name'] = ! isset($_POST['R00_Name']) ? "" : $_POST['R00_Name'];
        $searchKey['R00_Sei_Kana'] = ! isset($_POST['R00_Sei_Kana']) ? "" : $_POST['R00_Sei_Kana'];
        $searchKey['R00_Name_Kana'] = ! isset($_POST['R00_Name_Kana']) ? "" : $_POST['R00_Name_Kana'];
        $searchKey['R00_Mailaddress'] = ! isset($_POST['R00_Mailaddress']) ? "" : $_POST['R00_Mailaddress'];
        $searchKey['R01_DepertureAirport'] = ! isset($_POST['R01_DepertureAirport']) ? "" : $_POST['R01_DepertureAirport'];
        $searchKey['R00_Entry'] = ! isset($_POST['R00_Entry']) ? "" : $_POST['R00_Entry'];
        $searchKey['R00_Company'] = ! isset($_POST['R00_Company']) ? "" : $_POST['R00_Company'];
        $searchKey['R00_Division'] = ! isset($_POST['R00_Division']) ? "" : $_POST['R00_Division'];
        $searchKey['R00_Branch'] = ! isset($_POST['R00_Branch']) ? "" : $_POST['R00_Branch'];
        // パスポート投稿
        $searchKey['R00_Passpost_Upload_Flag'] = ! isset($_POST['R00_Passpost_Upload_Flag']) ? "0" : $_POST['R00_Passpost_Upload_Flag'];
        // 本人参加
        $searchKey['R01_Participation'] = ! isset($_POST['R01_Participation']) ? "0" : $_POST['R01_Participation'];
        // 確定コース
        $searchKey['R00_kibou0'] = ! isset($_POST['getcourseid']) ? "" : $_POST['getcourseid'];
        // 第1希望
        $searchKey['R00_kibou1'] = ! isset($_POST['R00_kibou1']) ? "" : $_POST['R00_kibou1'];
        // 第2希望
        $searchKey['R00_kibou2'] = ! isset($_POST['R00_kibou2']) ? "" : $_POST['R00_kibou2'];
        // 第3希望
        $searchKey['R00_kibou3'] = ! isset($_POST['R00_kibou3']) ? "" : $_POST['R00_kibou3'];

        return $searchKey;
    }

    /**
     * データーベースから検索結果を取得すること
     *
     * @return array $data 検索結果配列
     */
    public function getSearchResultData() {
        $data = array ();
        $searchKey = $this->getSearchKey();
        $data = $this->menu_mo->getSearchResult($searchKey); // 検索結果
        return $data;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 本人情報の詳細画面
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * 検索結果の行をクリクすると、ユーザーの詳細画面（ユーザー情報の修正画面）に移動する
     */
    public function edit() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            if (isset($_POST['optionalBtn'])) { // Sau khi dang ky xong new optional
                $newOptional = array ();
                $newOptional = $this->getRegisterOptionalInfo();
                $userId = $newOptional['R04_Id'];
                $optionalCode = $newOptional['R04_Optional_Tour_Code'];
                $existOptFlag = $this->menu_mo->checkExistReseverOptional($userId, $optionalCode);
                if (! $existOptFlag) {
                    $result = $this->menu_mo->addNewOptional($newOptional);
                    if ($result != - 1) {
                        $addOptionalStatus = 1; // 追加することが成功にしました。
                    } else {
                        $addOptionalStatus = 2; // 追加することが失敗にしました。
                    }
                } else {
                    $addOptionalStatus = 2; // 追加することが失敗にしました。
                }
            } else {
                $data = array ();
                // 検索結果の行をクリクするとき、ユーザー番号を取得する
                $userId = $_POST['R00_Id'];
                // アップデートする前に、フラグは 0 として
                $addOptionalStatus = 0;
            }
            $updateStatus = 0;
            $removeStatus = 0;
            $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
        } else {
            redirect(base_url('admin_con'));
        }
    }

    /**
     * 詳細画面のFORM ACTION メソッド
     * admin_edit_vi.phpから呼び出す
     */
    public function editInfoUser() {
        $userInfo = array ();

        // 社員情報更新(旅行代金再計算)
        if (isset($_POST['upd_info1'])) {
        }
        // 社員情報更新
        if (isset($_POST['upd_info2'])) {
            $userInfo = $this->getUpdateUserInfo();
            $userId = $userInfo['R00_Id'];

            // アップデート結果
            $result = $this->menu_mo->updateUserInfo1($userInfo);
            $removeStatus = 0;
            $addOptionalStatus = 0;
            if ($result != - 1) { // 変更成功しました。
                $updateStatus = 1;
            } else { // 変更失敗しました。
                $updateStatus = 2;
            }
            $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
        }
    }

    /**
     * ユーザー詳細画面を作成する
     *
     * @param int $userId
     *            社員番号
     * @param int $updateStatus
     *            0:初期化 , 1:アップデート成功 , アップデート失敗
     */
    public function loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus) {
        $data = array ();

        // 個人情報取得 -> $data配列を作成する
        $data = $this->menu_mo->getReseverInfoById($userId);

        // 人数取得
        $sankaNum = $this->menu_mo->getCountParticipationById($userId);

        // コースリストを取得
        $data['course_data'] = $this->menu_mo->getAllCourseData();

        // 同行ユーザーの情報を取得する
        $groups = $this->menu_mo->getAllOtherUserInGroupByPrimaryUserId($userId);

        // 同行の中に最高順番を習得する（削除する為）
        $maxSequence = $this->menu_mo->getMaxSequence($userId);

        // $dataに追加分
        if ($sankaNum != NULL) {
            $data['sankaNum'] = $sankaNum;
        } else {
            $data['sankaNum'] = "0";
        }

        $optionals = $this->menu_mo->getReseverOptionalById($userId);
        if ($optionals != NULL) {
            $data['optionals'] = $optionals;
        } else {
            $data['optionals'] = NULL;
        }

        // オプショナルリスト
        $data['optionalList'] = $this->menu_mo->getAllOptionals();

        // 代金合計とオプショナル数をまとめる
        $resultCount = $this->menu_mo->getTotalCountById($userId);
        $data['totalCount'] = $resultCount['totalCount'];
        $data['userCount'] = $resultCount['userCount'];

        $data['groups'] = $groups;
        $data['maxSequence'] = $maxSequence;
        $data['updateStatus'] = $updateStatus;
        $data['removeStatus'] = $removeStatus;
        $data['addOptionalStatus'] = $addOptionalStatus;

        $this->load->view("admin_edit_vi", $data);
    }
    public function getUpdateUserInfo() {
        $userInfo = array ();

        $userInfo['R00_Id'] = ! isset($_POST['R00_Id']) ? "" : $_POST['R00_Id'];
        $userInfo['R00_kakutei'] = ! isset($_POST['R00_kakutei']) ? "" : $_POST['R00_kakutei'];
        $userInfo['R00_Kakutei_2bed_Room_Num'] = ! isset($_POST['R00_Kakutei_2bed_Room_Num']) ? "0" : $_POST['R00_Kakutei_2bed_Room_Num'];
        $userInfo['R00_Kakutei_3bed_Room_Num'] = ! isset($_POST['R00_Kakutei_3bed_Room_Num']) ? "0" : $_POST['R00_Kakutei_3bed_Room_Num'];

        $userInfo['R00_emargency_mei'] = ! isset($_POST['R00_emargency_mei']) ? "" : $_POST['R00_emargency_mei'];
        $userInfo['R00_emargency_zoku'] = ! isset($_POST['R00_emargency_zoku']) ? "" : $_POST['R00_emargency_zoku'];
        $userInfo['R00_emargency_tel'] = ! isset($_POST['R00_emargency_tel']) ? "" : $_POST['R00_emargency_tel'];
        $userInfo['R00_Mailaddress'] = ! isset($_POST['R00_Mailaddress']) ? "" : $_POST['R00_Mailaddress'];
        $userInfo['R00_Nyusha_Date'] = ! isset($_POST['R00_Nyusha_Date']) ? "0000-00-00 00:00:00" : $_POST['R00_Nyusha_Date'];

        $userInfo['R00_kibou1'] = ! isset($_POST['R00_kibou1']) ? "" : $_POST['R00_kibou1'];
        $userInfo['R00_kibou2'] = ! isset($_POST['R00_kibou2']) ? "" : $_POST['R00_kibou2'];
        $userInfo['R00_kibou3'] = ! isset($_POST['R00_kibou3']) ? "" : $_POST['R00_kibou3'];

        $userInfo['R00_Company_Tel'] = ! isset($_POST['R00_Company_Tel']) ? "" : $_POST['R00_Company_Tel'];
        $userInfo['R00_Company_Fax'] = ! isset($_POST['R00_Company_Fax']) ? "" : $_POST['R00_Company_Fax'];
        $userInfo['R00_Company_Naisen'] = ! isset($_POST['R00_Company_Naisen']) ? "" : $_POST['R00_Company_Naisen'];
        $userInfo['R00_Customer_Note'] = ! isset($_POST['R00_Customer_Note']) ? "" : $_POST['R00_Customer_Note'];
        $userInfo['R00_Admin_Note'] = ! isset($_POST['R00_Admin_Note']) ? "" : $_POST['R00_Admin_Note'];
        $userInfo['R00_Fusanka_Note'] = ! isset($_POST['R00_Fusanka_Note']) ? "" : $_POST['R00_Fusanka_Note'];
        $userInfo['R00_Travel_Cost_Note'] = ! isset($_POST['R00_Travel_Cost_Note']) ? "" : $_POST['R00_Travel_Cost_Note'];

        return $userInfo;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (編)ユーザー情報の変更画面
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * (編)ボタンをクリクすると、このメソッドを呼び出す
     */
    public function editOther() {
        $otherData = array ();

        $R01_Sequence = $_POST['R01_Sequence'];
        $userId = $_POST['R01_Id'];

        $otherData = $this->menu_mo->getGroupInfoByIdAndSequence($userId, $R01_Sequence);

        // 出発地方リスト
        $departureList = $this->menu_mo->getAllDepartureData();
        $otherData['depertures'] = $departureList;

        $updateStatus = 0;
        $otherData['updateStatus'] = $updateStatus;

        $this->load->view("admin_edit_other_vi", $otherData);
    }

    /**
     * Ham nay duoc goi tu admin_edit_other_vi
     */
    public function editOtherInfo() {
        $otherInfo = array ();

        $otherInfo = $this->getOtherInfoUpdate();

        $result = $this->menu_mo->updateUserInfo2($otherInfo);

        if ($result != - 1) { // 変更成功しました。
            $updateStatus = 1;
        } else { // 変更失敗しました。
            $updateStatus = 2;
        }

        $userId = $otherInfo['R01_Id'];
        $R01_Sequence = $otherInfo['R01_Sequence'];

        // Load view ++++++++++++++++++++++++++++++++++++++
        $otherData = array ();
        $otherData = $this->menu_mo->getGroupInfoByIdAndSequence($userId, $R01_Sequence);

        // 出発地方リスト
        $departureList = $this->menu_mo->getAllDepartureData();
        $otherData['depertures'] = $departureList;

        $otherData['updateStatus'] = $updateStatus;

        $this->load->view("admin_edit_other_vi", $otherData);
        // Load view ++++++++++++++++++++++++++++++++++++++
    }

    /**
     * ユーザーの情報を取得する
     */
    public function getOtherInfoUpdate() {
        $otherInfo = array ();

        $otherInfo['R01_Id'] = ! isset($_POST['R01_Id']) ? "" : $_POST['R01_Id'];
        $otherInfo['R01_Sequence'] = ! isset($_POST['R01_Sequence']) ? "" : $_POST['R01_Sequence'];
        $otherInfo['R01_Plan'] = ! isset($_POST['R01_Plan']) ? "" : $_POST['R01_Plan'];
        $otherInfo['R01_Sei'] = ! isset($_POST['R01_Sei']) ? "" : $_POST['R01_Sei'];
        $otherInfo['R01_Name'] = ! isset($_POST['R01_Name']) ? "" : $_POST['R01_Name'];
        $otherInfo['R01_Sei_Kana'] = ! isset($_POST['R01_Sei_Kana']) ? "" : $_POST['R01_Sei_Kana'];
        $otherInfo['R01_Name_Kana'] = ! isset($_POST['R01_Name_Kana']) ? "" : $_POST['R01_Name_Kana'];
        $otherInfo['R01_Sei_Eng'] = ! isset($_POST['R01_Sei_Eng']) ? "" : $_POST['R01_Sei_Eng'];
        $otherInfo['R01_Name_Eng'] = ! isset($_POST['R01_Name_Eng']) ? "" : $_POST['R01_Name_Eng'];
        $otherInfo['R01_Travel_Cost'] = ! isset($_POST['R01_Travel_Cost']) ? "0" : $_POST['R01_Travel_Cost'];
        $otherInfo['R01_Cancel_Cost'] = ! isset($_POST['R01_Cancel_Cost']) ? "0" : $_POST['R01_Cancel_Cost'];
        $otherInfo['R01_Cancel_Day'] = ! isset($_POST['R01_Cancel_Day']) ? "0000-00-00 00:00:00" : $_POST['R01_Cancel_Day'];
        $otherInfo['R01_Participation'] = ! isset($_POST['R01_Participation']) ? "" : $_POST['R01_Participation'];
        $otherInfo['R01_Nationality'] = ! isset($_POST['R01_Nationality']) ? "" : $_POST['R01_Nationality'];
        $otherInfo['R01_Passport_No'] = ! isset($_POST['R01_Passport_No']) ? "" : $_POST['R01_Passport_No'];
        $otherInfo['R01_Passport_Issue'] = ! isset($_POST['R01_Passport_Issue']) ? "" : $_POST['R01_Passport_Issue'];
        $otherInfo['R01_Passport_Expire'] = ! isset($_POST['R01_Passport_Expire']) ? "" : $_POST['R01_Passport_Expire'];
        $otherInfo['R01_Passport_Sei'] = ! isset($_POST['R01_Passport_Sei']) ? "" : $_POST['R01_Passport_Sei'];
        $otherInfo['R01_Passport_Name'] = ! isset($_POST['R01_Passport_Name']) ? "" : $_POST['R01_Passport_Name'];
        $otherInfo['R01_Betsusei'] = ! isset($_POST['R01_Betsusei']) ? "" : $_POST['R01_Betsusei'];
        $otherInfo['R01_Sex'] = ! isset($_POST['R01_Sex']) ? "" : $_POST['R01_Sex'];
        $otherInfo['R01_Birthday'] = ! isset($_POST['R01_Birthday']) ? "" : $_POST['R01_Birthday'];
        $otherInfo['R01_Meal'] = ! isset($_POST['R01_Meal']) ? "" : $_POST['R01_Meal'];
        $otherInfo['R01_DepertureAirport'] = ! isset($_POST['R01_DepertureAirport']) ? "" : $_POST['R01_DepertureAirport'];
        $otherInfo['R01_ZipCode'] = ! isset($_POST['R01_ZipCode']) ? "" : $_POST['R01_ZipCode'];
        $otherInfo['R01_Address'] = ! isset($_POST['R01_Address']) ? "" : $_POST['R01_Address'];
        $otherInfo['R01_Tel'] = ! isset($_POST['R01_Tel']) ? "" : $_POST['R01_Tel'];
        $otherInfo['R01_Mobile'] = ! isset($_POST['R01_Mobile']) ? "" : $_POST['R01_Mobile'];

        return $otherInfo;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // （削）ユーザー削除の処理
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * （削）ボタンをクリクすると、ユーザーノデータを削除することを実行する
     */
    public function removeUser() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $data = array ();

            // 「削」ボタンをクリクすると、ユーザーノデータを削除することを実行する
            $userId = ! isset($_POST['R01_Id']) ? "" : $_POST['R01_Id'];
            $userSequence = ! isset($_POST['R01_Sequence']) ? "" : $_POST['R01_Sequence'];

            $result = $this->menu_mo->removeUserByIdAndSequence($userId, $userSequence);
            $updateStatus = 0;
            $addOptionalStatus = 0;
            if ($result != - 1) {
                // 削除成功する場合、フラグは 1になっている として
                $removeStatus = 1;
            } else {
                $removeStatus = 2;
            }

            $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
        } else {
            redirect(base_url('admin_con'));
        }
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 新規ユーザーの追加画面
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function addNewUser() {
        $data = array ();

        $userId = $_POST['R01_Id'];

        // 出発地方リスト
        $departureList = $this->menu_mo->getAllDepartureData();
        $data['depertures'] = $departureList;

        //
        $wifeCount = $this->menu_mo->getWifeCountById($userId);

        $data['R01_Id'] = $userId;
        $data['wifeCount'] = $wifeCount;
        $this->load->view("admin_add_user_vi", $data);
    }
    public function addUser() {
        // 新しいメンーバの情報
        $newUserInfo = $this->getNewUserInfo();

        // var_dump($newUserInfo);

        $result = $this->menu_mo->insertNewUser($newUserInfo);

        if ($result != - 1) {
            // redirect(base_url("menu_con/edit"));
            $userId = $newUserInfo['R01_Id'];
            // アップデートする前に、フラグは 0 として
            $updateStatus = 0;
            $removeStatus = 0;
            $addOptionalStatus = 0;
            $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
        }
    }
    public function getNewUserInfo() {
        $newUserInfo = array ();

        $newUserInfo['R01_Id'] = ! isset($_POST['R01_Id']) ? "" : $_POST['R01_Id'];
        $newUserInfo['R01_Plan'] = ! isset($_POST['R01_Plan']) ? "" : $_POST['R01_Plan'];
        $newUserInfo['R01_Sei'] = ! isset($_POST['R01_Sei']) ? "" : $_POST['R01_Sei'];
        $newUserInfo['R01_Name'] = ! isset($_POST['R01_Name']) ? "" : $_POST['R01_Name'];
        $newUserInfo['R01_Sei_Kana'] = ! isset($_POST['R01_Sei_Kana']) ? "" : $_POST['R01_Sei_Kana'];
        $newUserInfo['R01_Name_Kana'] = ! isset($_POST['R01_Name_Kana']) ? "" : $_POST['R01_Name_Kana'];
        $newUserInfo['R01_Sei_Eng'] = ! isset($_POST['R01_Sei_Eng']) ? "" : $_POST['R01_Sei_Eng'];
        $newUserInfo['R01_Name_Eng'] = ! isset($_POST['R01_Name_Eng']) ? "" : $_POST['R01_Name_Eng'];
        $newUserInfo['R01_Participation'] = ! isset($_POST['R01_Participation']) ? "" : $_POST['R01_Participation'];

        $newUserInfo['R01_Nationality'] = ! isset($_POST['R01_Nationality']) ? "" : $_POST['R01_Nationality'];
        $newUserInfo['R01_Passport_No'] = ! isset($_POST['R01_Passport_No']) ? "" : $_POST['R01_Passport_No'];
        $newUserInfo['R01_Passport_Issue'] = ! isset($_POST['R01_Passport_Issue']) ? "" : $_POST['R01_Passport_Issue'];
        $newUserInfo['R01_Passport_Expire'] = ! isset($_POST['R01_Passport_Expire']) ? "" : $_POST['R01_Passport_Expire'];
        $newUserInfo['R01_Passport_Sei'] = ! isset($_POST['R01_Passport_Sei']) ? "" : $_POST['R01_Passport_Sei'];
        $newUserInfo['R01_Passport_Name'] = ! isset($_POST['R01_Passport_Name']) ? "" : $_POST['R01_Passport_Name'];
        $newUserInfo['R01_Betsusei'] = ! isset($_POST['R01_Betsusei']) ? "" : $_POST['R01_Betsusei'];
        $newUserInfo['R01_Sex'] = ! isset($_POST['R01_Sex']) ? "" : $_POST['R01_Sex'];
        $newUserInfo['R01_Birthday'] = ! isset($_POST['R01_Birthday']) ? "" : $_POST['R01_Birthday'];
        $newUserInfo['R01_Meal'] = ! isset($_POST['R01_Meal']) ? "" : $_POST['R01_Meal'];
        $newUserInfo['R01_DepertureAirport'] = ! isset($_POST['R01_DepertureAirport']) ? "" : $_POST['R01_DepertureAirport'];
        $newUserInfo['R01_ZipCode'] = ! isset($_POST['R01_ZipCode']) ? "" : $_POST['R01_ZipCode'];
        $newUserInfo['R01_Address'] = ! isset($_POST['R01_Address']) ? "" : $_POST['R01_Address'];
        $newUserInfo['R01_Tel'] = ! isset($_POST['R01_Tel']) ? "" : $_POST['R01_Tel'];
        $newUserInfo['R01_Mobile'] = ! isset($_POST['R01_Mobile']) ? "" : $_POST['R01_Mobile'];

        return $newUserInfo;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // パスワード変更の処理
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function changePassword() {
        $data = array ();

        $userId = $_POST['R00_Id'];

        // 個人情報取得 -> $data配列を作成する
        $data = $this->menu_mo->getReseverInfoById($userId);
        $data['resetStatus'] = 0;
        $this->load->view("admin_change_password_vi", $data);
    }

    /**
     * ユーザーのパスワードをリセットするメソッド
     */
    public function resetPassword() {
        $data = array ();

        $userId = ! isset($_POST['R00_Id']) ? "" : $_POST['R00_Id'];

        // 個人情報取得 -> $data配列を作成する
        $data = $this->menu_mo->getReseverInfoById($userId);

        $result = $this->menu_mo->resetPasswordById($userId);
        if ($result != - 1) {
            $data['resetStatus'] = 1;
            $data['R00_Password'] = "";
        } else {
            $data['resetStatus'] = 2;
        }

        $this->load->view("admin_change_password_vi", $data);
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // オプショナルの支払方法について
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * クレジットカードで支払い情報をアップデート処理メソッド
     */
    public function paymentOptional() {
        $paymentInfo = array ();

        $paymentInfo = $this->getPaymentInfo();
        $userId = $paymentInfo['R00_Id'];
        // アップデート結果
        $result = $this->menu_mo->updateUserInfo3($paymentInfo);
        $removeStatus = 0;
        $addOptionalStatus = 0;
        if ($result != - 1) { // 変更成功しました。
            $updateStatus = 1;
        } else { // 変更失敗しました。
            $updateStatus = 2;
        }
        $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
    }

    /**
     * クレジットカードで支払い場合、必須の情報を習得するメソッド
     *
     * @return array() クレジットで入金する情報の配列
     */
    public function getPaymentInfo() {
        $paymentInfo = array ();

        $paymentInfo['R00_Id'] = ! isset($_POST['UserId']) ? "" : $_POST['UserId'];

        $paymentInfo['R00_Optional_Credit_link1'] = ! isset($_POST['R00_Optional_Credit_link1']) ? "" : $_POST['R00_Optional_Credit_link1'];
        $paymentInfo['R00_Optional_Credit_link_Text1'] = ! isset($_POST['R00_Optional_Credit_link_Text1']) ? "" : $_POST['R00_Optional_Credit_link_Text1'];

        $paymentInfo['R00_Optional_Credit_link2'] = ! isset($_POST['R00_Optional_Credit_link2']) ? "" : $_POST['R00_Optional_Credit_link2'];
        $paymentInfo['R00_Optional_Credit_link_Text2'] = ! isset($_POST['R00_Optional_Credit_link_Text2']) ? "" : $_POST['R00_Optional_Credit_link_Text2'];

        $paymentInfo['R00_Optional_Credit_link3'] = ! isset($_POST['R00_Optional_Credit_link3']) ? "" : $_POST['R00_Optional_Credit_link3'];
        $paymentInfo['R00_Optional_Credit_link_Text3'] = ! isset($_POST['R00_Optional_Credit_link_Text3']) ? "" : $_POST['R00_Optional_Credit_link_Text3'];

        return $paymentInfo;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 新しいオプショナルを申す込みの処理
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * オプショナルを申す込みする処理メソッド
     * Dang ky noi dung optional moi (menu_conm/edit -> menu_con->registerOptional)
     */
    public function registerOptional() {
        $data = array ();

        // Thiet lap cac gia tri can thiet khi dang ki va khi back

        if (isset($_POST['backBtn'])) { // back tu admin_optional_confirm_vi
            $data['R04_Id'] = ! isset($_POST['R04_Id']) ? "" : $_POST['R04_Id'];
            $data['R04_Optional_Tour_Code'] = ! isset($_POST['R04_Optional_Tour_Code']) ? "" : $_POST['R04_Optional_Tour_Code'];

            $data['R04_Optional_Kibou_Date'] = ! isset($_POST['R04_Optional_Kibou_Date']) ? "" : $_POST['R04_Optional_Kibou_Date'];
            $data['R04_Optional_Kibou_Time'] = ! isset($_POST['R04_Optional_Kibou_Time']) ? "" : $_POST['R04_Optional_Kibou_Time'];
            $data['R04_Tour_Option'] = ! isset($_POST['R04_Tour_Option']) ? "" : $_POST['R04_Tour_Option'];

            $data['R04_Tour_Note'] = ! isset($_POST['R04_Tour_Note']) ? "" : $_POST['R04_Tour_Note'];
            $data['R04_Ans'] = ! isset($_POST['R04_Ans']) ? "" : $_POST['R04_Ans'];

            $data['R04_Tour_Adult'] = ! isset($_POST['R04_Tour_Adult']) ? "" : $_POST['R04_Tour_Adult'];
            $data['R04_Tour_Child1'] = ! isset($_POST['R04_Tour_Child1']) ? "" : $_POST['R04_Tour_Child1'];
            $data['R04_Tour_Child2'] = ! isset($_POST['R04_Tour_Child2']) ? "" : $_POST['R04_Tour_Child2'];
            $data['R04_Tour_Infant'] = ! isset($_POST['R04_Tour_Infant']) ? "" : $_POST['R04_Tour_Infant'];

            $data['R04_Tour_ParticipationSeq0'] = ! isset($_POST['R04_Tour_ParticipationSeq0']) ? "0" : $_POST['R04_Tour_ParticipationSeq0'];
            $data['R04_Tour_ParticipationSeq1'] = ! isset($_POST['R04_Tour_ParticipationSeq1']) ? "0" : $_POST['R04_Tour_ParticipationSeq1'];
            $data['R04_Tour_ParticipationSeq2'] = ! isset($_POST['R04_Tour_ParticipationSeq2']) ? "0" : $_POST['R04_Tour_ParticipationSeq2'];
            $data['R04_Tour_ParticipationSeq3'] = ! isset($_POST['R04_Tour_ParticipationSeq3']) ? "0" : $_POST['R04_Tour_ParticipationSeq3'];
            $data['R04_Tour_ParticipationSeq4'] = ! isset($_POST['R04_Tour_ParticipationSeq4']) ? "0" : $_POST['R04_Tour_ParticipationSeq4'];
            $data['R04_Tour_ParticipationSeq5'] = ! isset($_POST['R04_Tour_ParticipationSeq5']) ? "0" : $_POST['R04_Tour_ParticipationSeq5'];
            $data['R04_Tour_ParticipationSeq6'] = ! isset($_POST['R04_Tour_ParticipationSeq6']) ? "0" : $_POST['R04_Tour_ParticipationSeq6'];
            $data['R04_Tour_ParticipationSeq7'] = ! isset($_POST['R04_Tour_ParticipationSeq7']) ? "0" : $_POST['R04_Tour_ParticipationSeq7'];
            $data['R04_Tour_ParticipationSeq8'] = ! isset($_POST['R04_Tour_ParticipationSeq8']) ? "0" : $_POST['R04_Tour_ParticipationSeq8'];
            $data['R04_Tour_ParticipationSeq9'] = ! isset($_POST['R04_Tour_ParticipationSeq9']) ? "0" : $_POST['R04_Tour_ParticipationSeq9'];

            $data['R04_Tour_Cost'] = ! isset($_POST['R04_Tour_Cost']) ? "" : $_POST['R04_Tour_Cost'];
            $data['R04_Tour_Jpy'] = ! isset($_POST['R04_Tour_Jpy']) ? "" : $_POST['R04_Tour_Jpy'];

            $data['AllSankaUser'] = $data['R04_Tour_Adult'] + $data['R04_Tour_Child1'] + $data['R04_Tour_Child2'] + $data['R04_Tour_Infant'];
        } else {

            $data['R04_Id'] = ! isset($_POST['R04_Id']) ? "" : $_POST['R04_Id'];
            $data['R04_Optional_Tour_Code'] = ! isset($_POST['R04_Optional_Tour_Code']) ? "" : $_POST['R04_Optional_Tour_Code'];

            $data['R04_Optional_Kibou_Date'] = "";
            $data['R04_Optional_Kibou_Time'] = "";
            $data['R04_Tour_Option'] = "";

            $data['R04_Tour_Note'] = "";
            $data['R04_Ans'] = "";

            $data['R04_Tour_Adult'] = "0";
            $data['R04_Tour_Child1'] = "0";
            $data['R04_Tour_Child2'] = "0";
            $data['R04_Tour_Option'] = "0";

            $data['R04_Tour_ParticipationSeq0'] = "0";
            $data['R04_Tour_ParticipationSeq1'] = "0";
            $data['R04_Tour_ParticipationSeq2'] = "0";
            $data['R04_Tour_ParticipationSeq3'] = "0";
            $data['R04_Tour_ParticipationSeq4'] = "0";
            $data['R04_Tour_ParticipationSeq5'] = "0";
            $data['R04_Tour_ParticipationSeq6'] = "0";
            $data['R04_Tour_ParticipationSeq7'] = "0";
            $data['R04_Tour_ParticipationSeq8'] = "0";
            $data['R04_Tour_ParticipationSeq9'] = "0";

            $data['R04_Tour_Cost'] = "0";
            $data['R04_Tour_Jpy'] = "0";

            $data['AllSankaUser'] = "0";
        }

        $R04_Optional_Tour_Code = trim($data['R04_Optional_Tour_Code']);
        $R04_Id = trim($data['R04_Id']);

        // オプショナル情報を取得する
        // Lay tat ca noi dung cua optional
        $optional_info = $this->menu_mo->getOptionalInfoByTourCode($R04_Optional_Tour_Code);

        if ($optional_info != NULL) {
            $data = array_merge($data, $optional_info);
        }

        // Lay thong tin nguoi dung
        $userInfo = $this->menu_mo->getReseverInfoById($R04_Id);
        // Lay thong tin cua nhung nguoi di cung
        $otherUsers = $this->menu_mo->getGroupUserInfoWithSequence($R04_Id);

        // 確定コースの情報を取得する
        // Lay thong tin cua kakutei course
        $kakuteiCourse = $this->menu_mo->getKakuteiCourseById($userInfo['R00_kakutei']);

        // オプショナルを展開日付までに、ユーザーズの年齢を取得する
        // Tu thong tin ngay xuat phat cua kakutei course, lay duoc do tuoi cua nhung nguoi tham gia -> tu do tinh toan phi tham gia
        date_default_timezone_set("Asia/Tokyo");
        $startCourse = DateTime::createFromFormat('Y年m月d日', $kakuteiCourse['M01_Dep_Date']);
        $start = $startCourse->format('Y-m-d');

        $temp = array ();
        foreach ( $otherUsers as $user ) {
            $birthDay = $user['R01_Birthday'];
            $diff = abs(strtotime($start) - strtotime($birthDay));
            $age = floor($diff / (365 * 60 * 60 * 24));
            $user['R01_Age'] = $age;

            $temp[] = $user;
        }

        // Tat ca thong tin cua nguoi tham gia duoc luu trong mang $data['otherUsers']
        $data['otherUsers'] = $temp;

        // Lay rate moi nhat
        $rateInfo = $this->menu_mo->getCurrentRate();
        if ($rateInfo != NULL) {
            $data = array_merge($data, $rateInfo);
        } else {
            $data['rateInfo'] = NULL;
        }

        $this->load->view("admin_optional_register_vi", $data);
    }

    /**
     * オプショナルの予約情報を習得すると、データーベースに保存する
     * Ham confirm lai noi dung da dien vao form register optional
     */
    public function registerNewOptional() {
        $newOptional = array ();

        $newOptional = $this->getRegisterOptionalInfo();
        $R04_Optional_Tour_Code = $newOptional['R04_Optional_Tour_Code'];
        // オプショナル情報を取得する
        // Lay thong tin optional theo Tour Code
        $optional_info = $this->menu_mo->getOptionalInfoByTourCode($R04_Optional_Tour_Code);

        if ($optional_info != NULL) {
            $newOptional = array_merge($newOptional, $optional_info);
        }

        // var_dump($newOptional);
        $addStatus = 0;
        $newOptional['addOptionalStatus'] = $addStatus;

        // var_dump($newOptional);
        $this->load->view("admin_optional_confirm_vi", $newOptional);
    }

    /**
     */
    public function confirmNewOptional() {
        $newOptional = array ();

        $newOptional = $this->getRegisterOptionalInfo();

        $userId = $newOptional['R04_Id'];
        $optionalCode = $newOptional['R04_Optional_Tour_Code'];

        $existOptFlag = $this->menu_mo->checkExistReseverOptional($userId, $optionalCode);

        if (! $existOptFlag) {
            $result = $this->menu_mo->addNewOptional($newOptional);

            if ($result != - 1) {
                $updateStatus = 0;
                $removeStatus = 0;
                $addOptionalStatus = 1; // 追加することが成功にしました。
                $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
            } else {
                $updateStatus = 0;
                $removeStatus = 0;
                $addOptionalStatus = 2; // 追加することが失敗にしました。
                $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
            }
        } else {
            $updateStatus = 0;
            $removeStatus = 0;
            $addOptionalStatus = 2; // 追加することが失敗にしました。
            $this->loadEditView($userId, $updateStatus, $removeStatus, $addOptionalStatus);
        }
    }
    public function getRegisterOptionalInfo() {
        $newOptional = array ();

        $newOptional['R04_Id'] = ! isset($_POST['R04_Id']) ? "" : $_POST['R04_Id']; // NOT NULL

        $newOptional['R04_Optional_Tour_Code'] = ! isset($_POST['R04_Optional_Tour_Code']) ? "" : $_POST['R04_Optional_Tour_Code']; // NOT NULL
        $newOptional['R04_Optional_Tour_Name'] = ! isset($_POST['R04_Optional_Tour_Name']) ? "" : $_POST['R04_Optional_Tour_Name'];
        $newOptional['R04_Optional_Tour_Title'] = ! isset($_POST['R04_Optional_Tour_Title']) ? "" : $_POST['R04_Optional_Tour_Title'];

        $newOptional['R04_Optional_Kibou_Date'] = ! isset($_POST['R04_Optional_Kibou_Date']) ? "0" : $_POST['R04_Optional_Kibou_Date']; // NOT NULL
        $newOptional['R04_Optional_Kibou_Time'] = ! isset($_POST['R04_Optional_Kibou_Time']) ? "" : $_POST['R04_Optional_Kibou_Time'];

        $newOptional['R04_Create_Date'] = ! isset($_POST['R04_Create_Date']) ? "0000-00-00 00:00:00" : $_POST['R04_Create_Date'];

        $newOptional['R04_Tour_Adult'] = ! isset($_POST['R04_Tour_Adult']) ? "0" : $_POST['R04_Tour_Adult']; // NOT NULL
        $newOptional['R04_Tour_Child1'] = ! isset($_POST['R04_Tour_Child1']) ? "0" : $_POST['R04_Tour_Child1']; // NOT NULL
        $newOptional['R04_Tour_Child2'] = ! isset($_POST['R04_Tour_Child2']) ? "0" : $_POST['R04_Tour_Child2']; // NOT NULL
        $newOptional['R04_Tour_Infant'] = ! isset($_POST['R04_Tour_Infant']) ? "0" : $_POST['R04_Tour_Infant']; // NOT NULL
        $newOptional['R04_Tour_Participation_Total'] = $newOptional['R04_Tour_Adult'] + $newOptional['R04_Tour_Child1'] + $newOptional['R04_Tour_Child2'] + $newOptional['R04_Tour_Infant']; // NOT NULL

        $newOptional['R04_Tour_Note'] = ! isset($_POST['R04_Tour_Note']) ? "" : $_POST['R04_Tour_Note'];
        $newOptional['R04_STS'] = ! isset($_POST['R04_STS']) ? "1" : $_POST['R04_STS']; // NOT NULL (1-手配中)
        $newOptional['R04_Tour_ParticipationSeq0'] = ! isset($_POST['R04_Tour_ParticipationSeq0']) ? "0" : $_POST['R04_Tour_ParticipationSeq0']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq1'] = ! isset($_POST['R04_Tour_ParticipationSeq1']) ? "0" : $_POST['R04_Tour_ParticipationSeq1']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq2'] = ! isset($_POST['R04_Tour_ParticipationSeq2']) ? "0" : $_POST['R04_Tour_ParticipationSeq2']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq3'] = ! isset($_POST['R04_Tour_ParticipationSeq3']) ? "0" : $_POST['R04_Tour_ParticipationSeq3']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq4'] = ! isset($_POST['R04_Tour_ParticipationSeq4']) ? "0" : $_POST['R04_Tour_ParticipationSeq4']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq5'] = ! isset($_POST['R04_Tour_ParticipationSeq5']) ? "0" : $_POST['R04_Tour_ParticipationSeq5']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq6'] = ! isset($_POST['R04_Tour_ParticipationSeq6']) ? "0" : $_POST['R04_Tour_ParticipationSeq6']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq7'] = ! isset($_POST['R04_Tour_ParticipationSeq7']) ? "0" : $_POST['R04_Tour_ParticipationSeq7']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq8'] = ! isset($_POST['R04_Tour_ParticipationSeq8']) ? "0" : $_POST['R04_Tour_ParticipationSeq8']; // NOT NULL
        $newOptional['R04_Tour_ParticipationSeq9'] = ! isset($_POST['R04_Tour_ParticipationSeq9']) ? "0" : $_POST['R04_Tour_ParticipationSeq9']; // NOT NULL

        $newOptional['R04_Tour_Option'] = ! isset($_POST['R04_Tour_Option']) ? "0" : $_POST['R04_Tour_Option']; // NOT NULL
        $newOptional['R04_Tour_Cost'] = ! isset($_POST['R04_Tour_Cost']) ? "0" : $_POST['R04_Tour_Cost']; // NOT NULL
        $newOptional['R04_Tour_Rate'] = ! isset($_POST['R04_Tour_Rate']) ? "" : $_POST['R04_Tour_Rate'];
        $newOptional['R04_Tour_Jpy'] = ! isset($_POST['R04_Tour_Jpy']) ? "0" : $_POST['R04_Tour_Jpy']; // NOT NULL
        $newOptional['R04_UpdateTime'] = ! isset($_POST['R04_UpdateTime']) ? "0000-00-00 00:00:00" : $_POST['R04_UpdateTime']; // NOT NULL
        $newOptional['R04_Ans'] = ! isset($_POST['R04_Ans']) ? "" : $_POST['R04_Ans'];

        return $newOptional;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // オプショナルの詳細情報の管理画面
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function optionalEdit() {
        $R04_Optional_Tour_Code = trim(! isset($_POST['R04_Optional_Tour_Code']) ? "" : $_POST['R04_Optional_Tour_Code']);
        $R04_Id = trim(! isset($_POST['R04_Id']) ? "" : $_POST['R04_Id']);
        $tabFlag = trim(! isset($_POST['tabFlag']) ? "1" : $_POST['tabFlag']); // 1: Menu , 2: Optional

        $updateStatus = 0;

        $this->loadOptionalView($R04_Id, $R04_Optional_Tour_Code, $updateStatus, $tabFlag);
    }
    public function editOptional() {
        $updateOptional = $this->getRegisterOptionalInfo();
        $R04_Id = $updateOptional['R04_Id'];
        $R04_Optional_Tour_Code = $updateOptional['R04_Optional_Tour_Code'];

        $result = $this->menu_mo->updateOptional($updateOptional);

        if ($result != - 1) {
            $updateStatus = 1;
        } else {
            $updateStatus = 2;
        }

        // var_dump($updateOptional);

        $this->loadOptionalView($R04_Id, $R04_Optional_Tour_Code, $updateStatus);
    }
    public function loadOptionalView($R04_Id, $R04_Optional_Tour_Code, $updateStatus, $tagFlag) {
        $data = array ();

        $data['R04_Id'] = $R04_Id;
        $data['R04_Optional_Tour_Code'] = $R04_Optional_Tour_Code;

        // オプショナル情報を取得する
        // Lay thong tin optional theo Tour Code
        $optional_info = $this->menu_mo->getOptionalInfoByTourCode($R04_Optional_Tour_Code);

        if ($optional_info != NULL) {
            $data = array_merge($data, $optional_info);
        }

        // var_dump($data);

        // Lay thong tin nguoi di cung
        $userInfo = $this->menu_mo->getReseverInfoById($R04_Id);
        $otherUsers = $this->menu_mo->getGroupUserInfoWithSequence($R04_Id);

        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ユーザーズの年齢を取得する
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 確定コースの情報を取得する
        $kakuteiCourse = $this->menu_mo->getKakuteiCourseById($userInfo['R00_kakutei']);

        // オプショナルを展開日付までに、ユーザーズの年齢を取得する
        date_default_timezone_set("Asia/Tokyo");
        $startCourse = DateTime::createFromFormat('Y年m月d日', $kakuteiCourse['M01_Dep_Date']);
        $start = $startCourse->format('Y-m-d');

        $temp = array ();
        foreach ( $otherUsers as $user ) {
            $birthDay = $user['R01_Birthday'];
            $diff = abs(strtotime($start) - strtotime($birthDay));
            $age = floor($diff / (365 * 60 * 60 * 24));
            $user['R01_Age'] = $age;

            $temp[] = $user;
        }

        $data['otherUsers'] = $temp;

        $rateInfo = $this->menu_mo->getCurrentRate();
        if ($rateInfo != NULL) {
            $data = array_merge($data, $rateInfo);
        } else {
            $data['rateInfo'] = NULL;
        }

        $optional_resever = $this->menu_mo->getReseverOptionalDataByUserIdAndTourCode($R04_Id, $R04_Optional_Tour_Code);
        if ($optional_resever != NULL) {
            $data = array_merge($data, $optional_resever);
        } else {
            $data['optional_resever'] = NULL;
        }

        $data['statusList'] = $this->menu_mo->getAllStatus();
        $data['updateStatus'] = $updateStatus;
        $data['tabFlag'] = $tagFlag;

        $this->load->view("admin_optional_edit_vi", $data);
    }
    public function download_csv_1() {
        date_default_timezone_set('Asia/Tokyo');
        $list = array ();

        // ヘッダ文字列
        $headers = array (
                "社員番号",
                "社員名",
                "カナ名",
                "英語名",
                "会社",
                "部署",
                "入社日",
                "性別",
                "誕生日",
                "メールアドレス",
                "確定",
                "参加",
                "希望1",
                "希望2",
                "希望3",
                "連絡先(緊)",
                "続柄(緊)",
                "電話(緊)",
                "エントリー",
                "参加人数",
                "パスポート投稿",
                "通信欄",
                "不参加理由",
                "管理者備考"
        );

        $fileName = mb_convert_encoding("ACTIO_" . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

        // output headers so that the file is downloaded rather than displayed
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $fileName);

        // create a file pointer connected to the output stream
        $output = fopen('php://output', 'w');

        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        // output the column headings
        fputcsv($output, $headers);

        // データ抽出する
        $list_data = $this->getSearchResultData();

        if ($list_data != NULL && count($list_data) > 0) {
            foreach ( $list_data as $data ) {

                // output the column headings
                // fputcsv($output, $data);

                $csv_row = $this->common_mo->get_csv_row_1($data);

                $csvdata = array ();

                $csvdata['R00_Id'] = $csv_row['R00_Id'];
                $csvdata['R00_Full_Name_Kanji'] = $csv_row['R00_Full_Name_Kanji'];
                $csvdata['R00_Full_Name_Kana'] = $csv_row['R00_Full_Name_Kana'];
                $csvdata['R00_Full_Name_Roman'] = $csv_row['R00_Full_Name_Roman'];

                $csvdata['R00_Company'] = $csv_row['R00_Company'];
                $csvdata['R00_Branch'] = $csv_row['R00_Branch'];

                $csvdata['R00_Nyusha_Date'] = $csv_row['R00_Nyusha_Date'];
                $csvdata['R01_Sex'] = $csv_row['R01_Sex'];
                $csvdata['R01_Birthday'] = $csv_row['R01_Birthday'];
                $csvdata['R00_Mailaddress'] = $csv_row['R00_Mailaddress'];

                // 確定コース
                $csvdata['R00_kakutei'] = $csv_row['R00_kakutei'];

                // 参加・不参加
                $csvdata['R01_Participation'] = $csv_row['R01_Participation'];

                // 第1希望
                $csvdata['R00_Kibou_1'] = $csv_row['R00_Kibou_1'];
                // 第2希望
                $csvdata['R00_Kibou_2'] = $csv_row['R00_Kibou_2'];
                // 第3希望
                $csvdata['R00_Kibou_3'] = $csv_row['R00_Kibou_3'];

                // 緊
                $csvdata['R00_emargency_mei'] = $csv_row['R00_emargency_mei'];
                $csvdata['R00_emargency_zoku'] = $csv_row['R00_emargency_zoku'];
                $csvdata['R00_emargency_tel'] = $csv_row['R00_emargency_tel'];

                // エントリー
                $csvdata['R00_Entry'] = $csv_row['R00_Entry'];

                // 参加人数
                $csvdata['ParticipationTotal'] = $csv_row['ParticipationTotal'];

                // パスポート投稿
                $csvdata['R00_Passpost_Upload_Flag'] = $csv_row['R00_Passpost_Upload_Flag'];

                // 通信欄
                $csvdata['R00_Customer_Note'] = $csv_row['R00_Customer_Note'];

                // 不参加理由
                $csvdata['R00_Fusanka_Note'] = $csv_row['R00_Fusanka_Note'];

                // 管理者備考
                $csvdata['R00_Admin_Note'] = $csv_row['R00_Admin_Note'];

                // END
                fputcsv($output, $csvdata);
            }
        }

        fclose($output);
    }
    public function download_csv_2() {
        date_default_timezone_set('Asia/Tokyo');
        $list = array ();

        // ヘッダ文字列
        $headers = array (
                "社員番号",
                "枝番",
                "区分",
                "氏名（姓）",
                "氏名（名）",
                "カナ(姓)",
                "カナ(名)",
                "英語名(姓)",
                "英語名(名)",
                "参加",
                "国籍",
                "パスポート番号",
                "Passport Issue",
                "Passport Expire",
                "パスポート(姓)",
                "パスポート(ミドルネーム)",
                "パスポート(名)",
                "パスポート投稿",
                "別姓",
                "性別",
                "生年月日",
                "機内食",
                "出発地",
                "郵便番号",
                "住所",
                "電話番号",
                "携帯番号",
                "会社",
                "所属コード",
                "部署",
                "入社日",
                "メールアドレス",
                "確定",
                "希望１",
                "希望2",
                "希望3",
                "連絡先(緊))",
                "続柄(緊)",
                "電話(緊)",
                "参加人数",
                "確定2ベット部屋",
                "確定3ベット部屋",
                "通信欄",
                "不参加理由",
                "管理者備考",
                "旅行代金",
                "旅行代金合計",
                "ご旅行代金備考",
                "部署（オリジナル）",
                "OP1ツアーコード",
                "OP1ツアー名",
                "OP1参加希望日",
                "OP1選択オプション",
                "OP1ご希望開始時間",
                "OP1参加人数合計",
                "OP1大人OP1子供1",
                "OP1子供2",
                "OP1幼児",
                "OP1手配状況",
                "OP1参加者名",
                "OP1備考",
                "OP1ツアー料金(USD)",
                "OP1レート",
                "OP1ツアー料金(JPY)",
                "OP2ツアーコード",
                "OP2ツアー名",
                "OP2参加希望日",
                "OP2選択オプション",
                "OP2ご希望開始時間",
                "OP2参加人数合計",
                "OP2大人",
                "OP2子供1",
                "OP2子供2",
                "OP2幼児",
                "OP2手配状況",
                "OP2参加者名",
                "OP2備考",
                "OP2ツアー料金(USD)",
                "OP2レート",
                "OP2ツアー料金(JPY)",
                "OP3ツアーコード",
                "OP3ツアー名",
                "OP3参加希望日",
                "OP3選択オプション",
                "OP3ご希望開始時間",
                "OP3参加人数合計",
                "OP3大人",
                "OP3子供1",
                "OP3子供2",
                "OP3幼児",
                "OP3手配状況",
                "OP3参加者名",
                "OP3備考",
                "OP3ツアー料金(USD)",
                "OP3レート",
                "OP3ツアー料金(JPY)",
                "OP4ツアーコード",
                "OP4ツアー名",
                "OP4参加希望日",
                "OP4選択オプション",
                "OP4ご希望開始時間",
                "OP4参加人数合計",
                "OP4大人",
                "OP4子供1",
                "OP4子供2",
                "OP4幼児",
                "OP4手配状況",
                "OP4参加者名",
                "OP4備考",
                "OP4ツアー料金(USD)",
                "OP4レート",
                "OP4ツアー料金(JPY)",
                "OP5ツアーコード",
                "OP5ツアー名",
                "OP5参加希望日",
                "OP5選択オプション",
                "OP5ご希望開始時間",
                "OP5参加人数合計",
                "OP5大人",
                "OP5子供1",
                "OP5子供2",
                "OP5幼児",
                "OP5手配状況",
                "OP5参加者名",
                "OP5備考",
                "OP5ツアー料金(USD)",
                "OP5レート",
                "OP5ツアー料金(JPY)",
                "合計額"
        );

        $fileName = mb_convert_encoding("ACTIO_" . date('Ymd_His') . ".csv", "SJIS", "UTF-8");

        // output headers so that the file is downloaded rather than displayed
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $fileName);

        // create a file pointer connected to the output stream
        $output = fopen('php://output', 'w');

        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        // output the column headings
        fputcsv($output, $headers);

        // データ抽出する
        $list_data = $this->getSearchResultData();

        if ($list_data != NULL && count($list_data) > 0) {
            foreach ( $list_data as $data ) {

                $csvdata = array ();

                // END
                fputcsv($output, $csvdata);
            }
        }

        fclose($output);
    }
    public function download_csv_3() {
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 基本機能の処理（共有機能の項目）
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     * Menuボタンをクリクする処理
     */
    public function back_menu() {
        redirect(base_url('menu_con'));
    }

    /**
     * ログアウト
     */
    public function logout() {
        $this->session->unset_userdata('admin_id_session');
        $this->session->unset_userdata('charger_type');
        redirect(base_url('admin_con'));
    }
    /*
     * メール送信管理
     *
     */
    public function manage_email() {
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $Course_Id = ! isset($_POST['Course_Id']) ? "" : $_POST['Course_Id'];
            $Han = ! isset($_POST['Han']) ? "" : $_POST['Han'];
        } else {
            redirect(base_url('admin_con'));
        }
    }

    /*
     *
     * コースマスタ配列作成
     */
    public function createM01CourseArray($val) {
        $M01_CourseArr = array (
                "M01_Dest_Kbn" => $val['M01_Dest_Kbn'],
                "M01_Dest_Code" => $val['M01_Dest_Code'],
                "M01_Han" => $val['M01_Han'],
                "M01_Dep_Id" => $val['M01_Dep_Id'],
                "M01_Air_Program" => $val['M01_Air_Program']
        );
        return $M01_CourseArr;
    }
    /*
     * データ名合わないため変更
     */
    public function ChangeArrKey($params, $value) {
        foreach ( $params as $key => $val ) {
            $changeVal = str_replace("R00", $value, $key);
            $Participate[$changeVal] = $val;
        }
        return $Participate;
    }
    public function changePWD() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $this->load->view("admin_pwd_vi");
        } else {
            redirect(base_url("admin_con"));
        }
    }
    public function ConfirmResever_PWD() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $params['R00_Id'] = isset($_POST['R00_Id']) ? $_POST['R00_Id'] : '';
            $data['user'] = $this->menu_mo->getReseverData($params);
            $data['user_id'] = isset($_POST['R00_Id']) ? $_POST['R00_Id'] : '';
            $this->load->view("admin_pwd_vi", $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }
    public function updateResever_PWD() {
        // Check admin session
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            $params['R00_Id'] = $_POST['R00_Id'];
            $params['R00_Password'] = null;
            $params['R00_login_flag'] = 0;
            $params['R00_first_login_date'] = null;
            $params['R00_last_login_date'] = null;

            $updateResult = $this->menu_mo->UpdateResever($params);

            if ($updateResult > 0) {
                echo 'success';
            } else {
                echo 'error';
            }
        } else {
            redirect(base_url("admin_con"));
        }
    }
    /*
     *
     * 全員の検索
     */
    public function detail_participant() {
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        // 初期化
        if ($admin_Id != null) {
            $data['Charger_Type'] = $charger_type;
            $data['admin_Id'] = $admin_Id;
            $data['searchKey'] = null;
            $data['results'] = null;
            if (isset($_POST['search'])) {
                $searchKey = $this->getSearchKeyForAll();
                $data['searchKey'] = $searchKey;
                $searchResult = $this->getSearchResult();
                $data['results'] = $searchResult;
                if (count($data['results']) > 0) {
                    $i = 0;
                    foreach ( $data['results'] as $row ) {
                        $data['results'][$i]['doko'] = $this->menu_mo->getCountDokoshaById($row['R00_Id']);
                        $i ++;
                    }
                }
            }
            $this->load->view("admin_search_participant_vi", $data);
        } else {
            redirect(base_url("admin_con"));
        }
    }

    /**
     * 全員の検索項目
     *
     * @return array() | NULL 検索キー
     */
    public function getSearchKeyForAll() {
        $infoType = $this->input->post('info_type');
        $searchKey = array (
                'R00_Id_Start' => $this->input->post('R00_Id_Start'),
                'R00_Id_End' => $this->input->post('R00_Id_End'),
                'R00_Sei' => $this->input->post('R00_Sei'),
                'R00_Name' => $this->input->post('R00_Name')
        );
        return $searchKey;
    }

    /**
     * 全員の検索結果
     */
    public function getSearchResult() {
        $results = array ();
        $searchKey = $this->getSearchKeyForAll();
        $searchResult = $this->admin_edit_mo->findSearchResult($searchKey);
        return $searchResult;
    }

    /*
     *
     * コース別空席状況確認
     */
    public function course_vacancy(){
        // Check session
        $admin_id = $this->session->userdata ( 'admin_id_session' );
        $charger_type = $this->session->userdata ( 'charger_type' );
        $updateDate = $this->input->get('updateDate');
        $data ['results'] = NULL;
        if (isset ( $admin_id )) {
            $data ['Charger_Type'] = $charger_type;
            // ツアーデータ取得
            $data ['For_Courses'] = $this->menu_mo->getCourseForeignData ();
            $data ['Domes_Courses'] = $this->menu_mo->getCourseDomesticData ();

            // 全てのコース取得

            $All_Course = $this->menu_mo->getAllCourseData ();
            $results_AllCourse_tmp = $this->menu_mo->getSearchResultByCourseMasterCode ();
            $Dep_Date = $results_AllCourse_tmp [0] ['M01_Dep_Date'];
            $Arr_Date = $results_AllCourse_tmp [0] ['M01_Arr_Date'];
            $iDate = 0;
            $iLength = 1;
            foreach ( $results_AllCourse_tmp as $key => $val ) {
                $val ['honnin'] = $this->menu_mo->getCountHonninBy ( $val ['M01_Dest_Kbn'], $val ['M01_Dest_Code'], $val ['M01_Han'], $val ['M01_Dep_Id'], $val ['M01_Air_Program'] );
                $val ['docosha'] = $this->menu_mo->getCountDokoshaBy ( $val ['M01_Dest_Kbn'], $val ['M01_Dest_Code'], $val ['M01_Han'], $val ['M01_Dep_Id'], $val ['M01_Air_Program'] );
                $results_AllCourse_tmp [$key] = $val;

                if ($iDate == 0 || ($results_AllCourse_tmp [$key] ['M01_Dep_Date'] != $Dep_Date && $results_AllCourse_tmp [$key] ['M01_Arr_Date'] != $Arr_Date)) {
                    $keydate = $key;
                    $iDate ++;
                    $iLength = 1;
                } else {
                    $iLength ++;
                }

                $results_AllCourse_tmp [$keydate] ['rowspan'] = $iLength;
                if ($results_AllCourse_tmp [$key] ['M01_Dep_Date'] != $Dep_Date && $results_AllCourse_tmp [$key] ['M01_Arr_Date'] != $Arr_Date) {
                    $Dep_Date = $results_AllCourse_tmp [$key] ['M01_Dep_Date'];
                    $Arr_Date = $results_AllCourse_tmp [$key] ['M01_Arr_Date'];
                }
            }
            $CourseKbn = $this->menu_mo->countDestkbn ();
            foreach ( $CourseKbn as $val ) {
                $Kbn ['kbn_' . $val ['M01_Dest_Kbn']] = $val ['totalCount'];
            }

            $CourseCode = $this->menu_mo->countDestCode ();
            foreach ( $CourseCode as $val ) {
                $Code ['code_' . $val ['M01_Dest_Code']] = $val ['totalCount'];
            }

            $data ['Kbn'] = $Kbn;
            $data ['alldest'] = $this->menu_mo->getAllDest ();
            $data ['code'] = $Code;
            $data ['results'] = $results_AllCourse_tmp;
            if(!empty($updateDate)){
                $data['updateDate'] = $updateDate;
            }
            $this->load->view ( "admin_course_vacancy_vi", $data );
        }else {
            redirect ( base_url ( 'admin_con' ) );
        }
        }
        /**
         * 空き状況追加
         */
        public function savevacancy() {
            // セッション取得
            date_default_timezone_set('Asia/Tokyo');
            $inputs = $this->input->post();
            $updateDate =  $inputs['updateDate'];
            unset($inputs['updateDate']);
            unset($inputs['updateVacancy']);
            foreach ($inputs as $key=>$val){
              $vacancy_arr = explode("_", $key);
              $Air_Program = $this->menu_mo->getAir($vacancy_arr);

              if ($Air_Program !=FALSE){
                  $insert_data['R12_Dest_Kbn'] = $vacancy_arr[0];
                  $insert_data['R12_Dest_Code'] = $vacancy_arr[1];
                  $insert_data['R12_Han'] = $vacancy_arr[2];
                  $insert_data['R12_Dep_Id'] = $vacancy_arr[3];
                  $insert_data['R12_Air_Program'] = $vacancy_arr[4];
                  $insert_data['R12_Vacancy'] = $val;
                  $insert_data['R12_Date'] = $updateDate;
                  $this->menu_mo->save_Reserve_Information($insert_data);
              }
            }
            redirect ( base_url ( 'menu_con/course_vacancy?updateDate='.$updateDate ) );
        }

    /**
     * お申込み内容確認書 EXCEL
     */
    public function entry_info() {
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            date_default_timezone_set('Asia/Tokyo');
            $Course_Data = ! isset($_POST['Course']) ? "" : $_POST['Course'];
            $param = array (
                    'R00_Dest_Kbn' => $Course_Data['R00_Dest_Kbn'],
                    'R00_Dest_Code' => $Course_Data['R00_Dest_Code'],
                    'R00_Han' => $Course_Data['R00_Han'],
                    'R00_Dep_Id' => $Course_Data['R00_Dep_Id'],
                    'R00_Air_Program' => $Course_Data['R00_Air_Program']
            );
            $SearchData   = $this->input->post('Search');
            $SearchData['R00_Dest_Kbn'] = $Course_Data['R00_Dest_Kbn'];
            $SearchData['R00_Dest_Code'] = $Course_Data['R00_Dest_Code'];
            $SearchData['R00_Han'] = $Course_Data['R00_Han'];
            $SearchData['R00_Dep_Id'] = $Course_Data['R00_Dep_Id'];
            $SearchData['R00_Air_Program'] = $Course_Data['R00_Air_Program'];
            $data_reserve = $this->menu_mo->getResverCourseById($SearchData);

            $kakuteiInfo = $this->user_top_mo->getKakuteCourseById($param);
            $cost_travel = 0;
            $cost_room = 0;
            $today = date('Y-m-d H:i:s', time());
            foreach ( $data_reserve as $ReKey => $reserve ) {
                $participantInfo_arr = $this->user_top_mo->getUserInfo($reserve['R00_Id']);
                foreach ( $participantInfo_arr as $info_key => $participant ) {

                    $old = floor((date('Ymd', strtotime($kakuteiInfo['M01_Dep_Date'])) - date('Ymd', strtotime($participant['R01_Birthday']))) / 10000);
                    // 代表者
                    if ($participant['R01_Plan'] == 0) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Me'];
                    }
                    // 大人
                    if ($participant['R01_Plan'] != 0 && $old >= 12) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Adult1'];
                    }
                    // 海外:子供
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 1) && (2 <= $old) && ($old < 12)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Child'];
                    }
                    // 国内:子供
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 2) && (3 <= $old) && ($old < 12)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Child'];
                    }
                    // 海外:幼児
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 1) && (0 <= $old) && ($old < 2)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Baby'];
                    }
                    // 国内:幼児
                    if (($kakuteiInfo['M01_Dest_Kbn'] == 2) && (0 <= $old) && ($old < 3)) {
                        $cost_travel = $kakuteiInfo['M01_Cost_Baby'];
                    }
                    $traVal['R01_Id'] = $participant['R01_Id'];
                    $traVal['R01_Plan'] = $participant['R01_Plan'];
                    $traVal['R01_Cost_Name3'] = "参加料金";
                    $traVal['R01_Cost3'] = $cost_travel;
                    $traVal['R01_UpdateTime'] = $today;
                    //$result = $this->menu_mo->CostTravelinfo($traVal);
                }
                // 1人部屋料金
                $data_room = trim($reserve['R00_1Room_wish']);

                $cost_room = $kakuteiInfo['M01_Cost_1Room'];
                $roomVal['R01_Id'] = $reserve['R00_Id'];
                $roomVal['R01_Plan'] = '0';
                $roomVal['R01_Cost_Name4'] = "1人部屋料金";
                $roomVal['R01_Cost4'] = $cost_room;
                $roomVal['R01_UpdateTime'] = $today;
                $pos = strpos($data_room, '希望する');

                if ($pos !== false) {
                    //$result_room = $this->menu_mo->CostRoominfo($roomVal);
                }
            }

            foreach ( $data_reserve as $ReKey => $reserve ) {
                $excelfile = $this->excel->excel_entry_info($param, $reserve);
                $fileNameList[] = APPPATH . 'excel_data/' . $excelfile;
                // $fileNameList[] = '/var/www/nssproduct/html10/excel_data/'.$excelfile;
            }

            // var_dump($fileNameList);exit;
            $zip = new ZipArchive();
            // Zipファイル名
            $zipFileName = "Entry_" . date("Ymdhis") . '.zip';
            // Zipファイル一時保存ディレクトリ
            $zipTmpDir = APPPATH . 'excel_data/';
            // $zipTmpDir = '/var/www/nssproduct/html10/excel_data/';

            // Zipファイルオープン
            $result = $zip->open($zipTmpDir . $zipFileName, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE);
            if ($result !== true) {
                // 失敗した時の処理
            }

            // ここでDB等から画像イメージ配列を取ってくる
            // $fileNameList_array = "/var/www/nssproduct/html10/pdf/".$fileNameList;

            // 処理制限時間を外す
            set_time_limit(0);

            foreach ( $fileNameList as $filepath ) {

                $filename = basename($filepath);

                // 取得ファイルをZipに追加していく
                $zip->addFromString($filename, file_get_contents($filepath));
            }

            $zip->close();

            // remove excel file , zip file only exist
            foreach ($fileNameList as $path) {
                if (is_file($path))  unlink($path);
            }

            // $zipFileName = "FIT.zip";
            // $zipTmpDir = "/var/www/nssproduct/html10/pdf/";
            // ストリームに出力
            /*
             * header('Content-Type: application/zip; name="' . $zipFileName . '"');
             * header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
             * header('Content-Length: '.filesize($zipTmpDir.$zipFileName));
             * echo file_get_contents($zipTmpDir.$zipFileName);
             *
             * // 一時ファイルを削除しておく
             * unlink($zipTmpDir.$zipFileName);
             */

            $filepath = $zipTmpDir . $zipFileName;
            header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
            header('Content-Type: application/octet-stream');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($filepath));
            ob_end_clean();
            readfile($filepath);

            exit();

            $this->course_detail($param);
        } else {
            redirect(base_url('admin_con'));
        }
    }

    /**
     * パスポート画像ダウンロード
     *
     * @author VienCQ
     * @return コースの参加者パスポート画像をすべてダウンロードする（保存フォルダが選択できる）
     */
    private function download_passport_img() {
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            date_default_timezone_set('Asia/Tokyo');
            $Course_Data = ! isset($_POST['Course']) ? "" : $_POST['Course'];
            $param = array (
                    'R00_Dest_Kbn' => $Course_Data['R00_Dest_Kbn'],
                    'R00_Dest_Code' => $Course_Data['R00_Dest_Code'],
                    'R00_Han' => $Course_Data['R00_Han'],
                    'R00_Dep_Id' => $Course_Data['R00_Dep_Id'],
                    'R00_Air_Program' => $Course_Data['R00_Air_Program']
            );
            $travelPassportImgs = $this->getTravelPassportImgByCourse($param);
            $errorFlg = 0;
            if ($travelPassportImgs != null) {
                $this->downloadFile($travelPassportImgs);
            } else {
                return $errorFlg = 1;
            }
        } else {
            redirect(base_url("admin_con"));
        }
        return $errorFlg;
    }

    /**
     * コースによって、予約本人ID配列を取得する
     * @param array $param コース主キー
     * @return array|null 予約本人ID配列
     */
    private function getReserveIdListByCourse($param) {
        $reserves = $this->menu_mo->getReserveIdListByCourse($param);
        $reserveIdList = array ();
        if ($reserves != null) {
            foreach ( $reserves as $reserve ) {
                $reserveIdList[] = $reserve['R00_Id'];
            }
            return $reserveIdList;
        }
        return null;
    }
    private function getTravelPassportImgByCourse($param) {
        $reserveIdList = $this->getReserveIdListByCourse($param);
        $travelPassportImgs = $this->menu_mo->getTravelPassportImgByCourse($reserveIdList);
        return $travelPassportImgs;
    }
    private function getFileExtension($passportFile) {
        return substr(strrchr($passportFile, '.'), 1);
    }
    private function downloadFile($travelPassportImgs) {
        $fileNameList = array ();
        $baseDir = realpath(realpath(dirname(__FILE__) . '/../') . '/../') . "/pass_img/";
        foreach ( $travelPassportImgs as $travelPassportImg ) {
            $reserveId = $travelPassportImg['R01_Id'];
            $passportFile = $travelPassportImg['R01_PassportImg'];
            $filepath = $baseDir . $passportFile;
            $fileNameList[] = $filepath;
        }
        $zip = new ZipArchive();
        $zipFileName = "Passport_" . date("Ymdhis") . '.zip'; // Zipファイル名
        // Zipファイルオープン
        $result = $zip->open($baseDir . $zipFileName, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE);
        if ($result !== true) {
            // 失敗した時の処理
        }
        // 処理制限時間を外す
        set_time_limit(0);
        foreach ( $travelPassportImgs as $travelPassportImg ) {
            $reserveId = $travelPassportImg['R01_Id'];
            $passportFile = $travelPassportImg['R01_PassportImg'];
            $plan = $travelPassportImg['R01_Plan'];
            $ext = $this->getFileExtension($passportFile);
            // file name
            $fileName = "Passport_" . $reserveId . '_' . ($plan + 1) . '_' . date("Ymdhis") . '.' . $ext;
            // full path
            $filepath = $baseDir . $passportFile;
            $zip->addFromString($fileName, file_get_contents($filepath));
        }
        $zip->close();

        $zipPath = $baseDir . $zipFileName;
        header('Content-Disposition: attachment; filename="' . basename($zipPath) . '"');
        header('Content-Type: application/octet-stream');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($zipPath));
        ob_end_clean();
        readfile($zipPath);

        exit();
    }

    /**
     * ESTAエックセルファイルをダウンロードする
     */
    private function download_esta_info() {
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            date_default_timezone_set('Asia/Tokyo');
            $Course_Data = ! isset($_POST['Course']) ? "" : $_POST['Course'];
            $param = array (
                    'R00_Dest_Kbn' => $Course_Data['R00_Dest_Kbn'],
                    'R00_Dest_Code' => $Course_Data['R00_Dest_Code'],
                    'R00_Han' => $Course_Data['R00_Han'],
                    'R00_Dep_Id' => $Course_Data['R00_Dep_Id'],
                    'R00_Air_Program' => $Course_Data['R00_Air_Program']
            );
            $SearchData   = $this->input->post('Search');
            $SearchData['R00_Dest_Kbn'] = $Course_Data['R00_Dest_Kbn'];
            $SearchData['R00_Dest_Code'] = $Course_Data['R00_Dest_Code'];
            $SearchData['R00_Han'] = $Course_Data['R00_Han'];
            $SearchData['R00_Dep_Id'] = $Course_Data['R00_Dep_Id'];
            $SearchData['R00_Air_Program'] = $Course_Data['R00_Air_Program'];
            // get ESTA data
            $estaData = array ();
            $staffs = $this->menu_mo->getStaffInfoByCourse($SearchData);
            if ($staffs != null) {
                $estaData = $this->getESTAData($staffs);
            }
            $errorFlg = 0;
            if ($estaData != null) {
                $this->downloadESTA($estaData);
            } else {
                $errorFlg = 1;
            }
            return $errorFlg;
        } else {
            redirect(base_url('admin_con'));
        }
    }

    private function getESTAData($staffs) {
        $estaData = array ();
        foreach ($staffs as $staff) {
            if ($this->menu_mo->isExistESTA($staff['R00_Id'])) {
                $travels = $this->menu_mo->getTravelInfoById($staff['R00_Id']);
                foreach ($travels as $travel) {
                    $estaInfo = $this->menu_mo->getESTAInfoByIdAndSeq($staff['R00_Id'] , $travel['R01_Plan']);
                    if ($estaInfo != null) {
                        if ($travel['R01_Plan'] == 0) {
                            $estaData[$staff['R00_Id']][0] = array_merge(array_merge($staff , $travel) , $estaInfo);
                        } else {
                            $estaData[$staff['R00_Id']][$travel['R01_Plan']] = array_merge($travel , $estaInfo);
                        }
                    }
                }
            }
        }
        return $estaData;
    }

    private function downloadESTA($estaData) {
        $fileNameList = array();
        foreach ($estaData as $userId => $estaArr) {
            foreach ($estaArr as $plan => $esta) {
                $excelFile = $this->excelesta->excel_esta_info($esta , $plan);
                $fileNameList[] = APPPATH . 'excel_data/' . $excelFile;
            }
        }
        $zip = new ZipArchive();
        $zipFileName = "ESTA_" . date("Ymdhis") . '.zip';
        // Zipファイル一時保存ディレクトリ
        $zipTmpDir = APPPATH . 'excel_data/';
        // Zipファイルオープン
        $result = $zip->open($zipTmpDir . $zipFileName, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE);
        if ($result !== true) {
            // 失敗した時の処理
        }
        // 処理制限時間を外す
        set_time_limit(0);

        foreach ( $fileNameList as $filepath ) {
            $filename = basename($filepath);
            // 取得ファイルをZipに追加していく
            $zip->addFromString($filename, file_get_contents($filepath));
        }

        $zip->close();

        // remove excel file , zip file only exist
        foreach ($fileNameList as $path) {
            if (is_file($path))  unlink($path);
        }

        $filepath = $zipTmpDir . $zipFileName;
        header("Content-Disposition: attachment;filename=".mb_convert_encoding(basename($filepath) , 'sjis-win', 'UTF-8'));
        header('Content-Type: application/octet-stream');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($filepath));
        ob_end_clean();
        readfile($filepath);

        exit();
    }
    /*
    *ExcelAirNameList
    *
    */
    public function ExcelAirNameList(){
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        if(isset($admin_Id)){
            $Course = $this->input->post('Course');
            $param = array(
                "M01_Dest_Kbn" => $Course['R00_Dest_Kbn'],
                "M01_Dest_Code" =>  $Course['R00_Dest_Code'],
                "M01_Han" => $Course['R00_Han'],
                "M01_Dep_Id" => $Course['R00_Dep_Id'],
                "M01_Air_Program" => $Course['R00_Air_Program']
            );

            $SearchData   = $this->input->post('Search');
            $SearchData['R00_Dest_Kbn'] = $Course['R00_Dest_Kbn'];
            $SearchData['R00_Dest_Code'] = $Course['R00_Dest_Code'];
            $SearchData['R00_Han'] = $Course['R00_Han'];
            $SearchData['R00_Dep_Id'] = $Course['R00_Dep_Id'];
            $SearchData['R00_Air_Program'] = $Course['R00_Air_Program'];
            $Result = $this->menu_mo->SearchReservation($SearchData);

            //同行者情報取得
            $SearchTmp = array();
            foreach($Result as $row){
                $SearchTmp[] = $this->menu_mo->getParticipation($row['R00_Id']);
            }

            //excel に書き込むためデータ作る
            $AllSearchResult = array();
            foreach($SearchTmp as $key=>$val){
                foreach($val as $key1=>$val1){
                    $AllSearchResult[] = $val1;
                }
            }
            //$SearchResult = array_slice($AllSearchResult, 0, 150);
			$SearchResult = $AllSearchResult;
            $data['SearchResult'] = $SearchResult;
            $CourseDataMaster     = $this->menu_mo->getM01Course($param);
            $data['CourseDataMaster'] = $CourseDataMaster[0];
            $this->excelairnamelist->AirNameList($data);
        }else{
            redirect(base_url("admin_con"));
        }
    }

    /**
     * ETASエックセルファイルをダウンロードする
     */
    private function download_etas_info(){
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            date_default_timezone_set('Asia/Tokyo');
            $Course_Data = ! isset($_POST['Course']) ? "" : $_POST['Course'];
            $param = array (
                    'R00_Dest_Kbn' => $Course_Data['R00_Dest_Kbn'],
                    'R00_Dest_Code' => $Course_Data['R00_Dest_Code'],
                    'R00_Han' => $Course_Data['R00_Han'],
                    'R00_Dep_Id' => $Course_Data['R00_Dep_Id'],
                    'R00_Air_Program' => $Course_Data['R00_Air_Program']
            );

            $SearchData   = $this->input->post('Search');
            $SearchData['R00_Dest_Kbn'] = $Course_Data['R00_Dest_Kbn'];
            $SearchData['R00_Dest_Code'] = $Course_Data['R00_Dest_Code'];
            $SearchData['R00_Han'] = $Course_Data['R00_Han'];
            $SearchData['R00_Dep_Id'] = $Course_Data['R00_Dep_Id'];
            $SearchData['R00_Air_Program'] = $Course_Data['R00_Air_Program'];

            $etasData = array ();
            $staffs = $this->menu_mo->getStaffInfoByCourseAll($SearchData);
            if ($staffs != null) {
                $etasData = $this->getETASData($staffs);
            }
            $errorFlg = 0;
            if ($etasData != null) {
                $this->downloadETAS($etasData);
            } else {
                $errorFlg = 1;
            }
            return $errorFlg;
        } else {
            redirect(base_url('admin_con'));
        }
    }

    private function getETASData($staffs) {
        $etasData = array ();
        foreach ($staffs as $staff) {
            if ($this->menu_mo->isExistETAS($staff['R00_Id'])) {
                $travels = $this->menu_mo->getTravelInfoById($staff['R00_Id']);
                foreach ($travels as $travel) {
                    $etasInfo = $this->menu_mo->getETASInfoByIdAndSeq($staff['R00_Id'] , $travel['R01_Plan']);
                    if ($etasInfo != null) {
                        if ($travel['R01_Plan'] == 0) {
                            $etasData[$staff['R00_Id']][0] = array_merge(array_merge($staff , $travel) , $etasInfo);
                        } else {
                            $etasData[$staff['R00_Id']][$travel['R01_Plan']] = array_merge($travel , $etasInfo);
                        }
                    }
                }
            }
        }
        return $etasData;
    }


    private function downloadETAS($etasData) {
        // 処理制限時間を外す
        set_time_limit(0);

        $fileNameList = array();
        foreach ($etasData as $userId => $etasArr) {
            foreach ($etasArr as $plan => $etas) {
                if ($plan == '0') {
                    $dep_date = $this->menu_mo->getM01DepDate($etas['R00_Id']);
                } else {
                    $dep_date = $this->menu_mo->getM01DepDate($etas['R01_Id']);
                }

                $tmp['M01_Dep_Date'] = ($dep_date != null) ? $dep_date : '';
                $etas = array_merge($etas , $tmp);
                $excelFile = $this->exceletas->excel_etas_info($etas , $plan);
                $fileNameList[] = APPPATH . 'excel_data/' . $excelFile;
            }
        }
        $zip = new ZipArchive();
        $zipFileName = "ETAS" . date("Ymdhis") . '.zip';
        // Zipファイル一時保存ディレクトリ
        $zipTmpDir = APPPATH . 'excel_data/';
        // Zipファイルオープン
        $result = $zip->open($zipTmpDir . $zipFileName, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE);
        if ($result !== true) {
            // 失敗した時の処理
        }

        foreach ( $fileNameList as $filepath ) {
            $filename = basename($filepath);
            // 取得ファイルをZipに追加していく
            $zip->addFromString($filename, file_get_contents($filepath));
        }

        $zip->close();
        // remove excel file , zip file only exist
        foreach ($fileNameList as $path) {
            if (is_file($path))  unlink($path);
        }
        $filepath = $zipTmpDir . $zipFileName;
        header("Content-Disposition: attachment;filename=".mb_convert_encoding(basename($filepath) , 'sjis-win', 'UTF-8'));
        header('Content-Type: application/octet-stream');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($filepath));
        ob_end_clean();
        readfile($filepath);

        exit();
    }

    /**
     * CNMIエックセルファイルをダウンロードする
     */
    private function download_cnmi_info(){
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        $charger_type = $this->session->userdata('charger_type');
        if (isset($admin_Id)) {
            date_default_timezone_set('Asia/Tokyo');
            $Course_Data = ! isset($_POST['Course']) ? "" : $_POST['Course'];
            $param = array (
                    'R00_Dest_Kbn' => $Course_Data['R00_Dest_Kbn'],
                    'R00_Dest_Code' => $Course_Data['R00_Dest_Code'],
                    'R00_Han' => $Course_Data['R00_Han'],
                    'R00_Dep_Id' => $Course_Data['R00_Dep_Id'],
                    'R00_Air_Program' => $Course_Data['R00_Air_Program']
            );
            $SearchData   = $this->input->post('Search');
            $SearchData['R00_Dest_Kbn'] = $Course_Data['R00_Dest_Kbn'];
            $SearchData['R00_Dest_Code'] = $Course_Data['R00_Dest_Code'];
            $SearchData['R00_Han'] = $Course_Data['R00_Han'];
            $SearchData['R00_Dep_Id'] = $Course_Data['R00_Dep_Id'];
            $SearchData['R00_Air_Program'] = $Course_Data['R00_Air_Program'];
            // get CNMI data
            $cnmiData = array ();
            $staffs = $this->menu_mo->getStaffInfoByCourseAll($SearchData);

            if ($staffs != null) {
                $cnmiData = $this->getCNMIData($staffs);
            }
            $errorFlg = 0;
            if ($cnmiData != null) {
                $this->downloadCNMI($cnmiData);
            } else {
                $errorFlg = 1;
            }
            return $errorFlg;
        } else {
            redirect(base_url('admin_con'));
        }
    }

    private function getCNMIData($staffs) {
        $cnmiData = array ();
        foreach ($staffs as $staff) {
            if ($this->menu_mo->isExistCNMI($staff['R00_Id'])) {
                $travels = $this->menu_mo->getTravelInfoById($staff['R00_Id']);
                foreach ($travels as $travel) {
                    $cnmiInfo = $this->menu_mo->getCNMIInfoByIdAndSeq($staff['R00_Id'] , $travel['R01_Plan']);
                    if ($cnmiInfo != null) {
                        if ($travel['R01_Plan'] == 0) {
                            $cnmiData[$staff['R00_Id']][0] = array_merge(array_merge($staff , $travel) , $cnmiInfo);
                        } else {
                            $cnmiData[$staff['R00_Id']][$travel['R01_Plan']] = array_merge($travel , $cnmiInfo);
                        }
                    }
                }
            }
        }
        return $cnmiData;
    }

    private function downloadCNMI($cnmiData) {
        $fileNameList = array();
        foreach ($cnmiData as $userId => $cnmiArr) {
            foreach ($cnmiArr as $plan => $cnmi) {
                $excelFile = $this->excelcnmi->excel_cnmi_info($cnmi , $plan);
                $fileNameList[] = APPPATH . 'excel_data/' . $excelFile;
            }
        }
        $zip = new ZipArchive();
        $zipFileName = "CNMI" . date("Ymdhis") . '.zip';
        // Zipファイル一時保存ディレクトリ
        $zipTmpDir = APPPATH . 'excel_data/';
        // Zipファイルオープン
        $result = $zip->open($zipTmpDir . $zipFileName, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE);
        if ($result !== true) {
            // 失敗した時の処理
        }
        // 処理制限時間を外す
        set_time_limit(0);

        foreach ( $fileNameList as $filepath ) {
            $filename = basename($filepath);
            // 取得ファイルをZipに追加していく
            $zip->addFromString($filename, file_get_contents($filepath));
        }

        $zip->close();
        // remove excel file , zip file only exist
        foreach ($fileNameList as $path) {
            if (is_file($path))  unlink($path);
        }

        $filepath = $zipTmpDir . $zipFileName;
        header("Content-Disposition: attachment;filename=".mb_convert_encoding(basename($filepath) , 'sjis-win', 'UTF-8'));
        header('Content-Type: application/octet-stream');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($filepath));
        ob_end_clean();
        readfile($filepath);

        exit();
    }

    /*
    *InsuranceList
    *
    */

    public function InsuranceList(){
        // セッション取得
        $admin_Id = $this->session->userdata('admin_id_session');
        if(isset($admin_Id)){
            $Course = $this->input->post('Course');
            $param = array(
                "M01_Dest_Kbn" => $Course['R00_Dest_Kbn'],
                "M01_Dest_Code" =>  $Course['R00_Dest_Code'],
                "M01_Han" => $Course['R00_Han'],
                "M01_Dep_Id" => $Course['R00_Dep_Id'],
                "M01_Air_Program" => $Course['R00_Air_Program']
            );
            $SearchData['R00_Dest_Kbn'] = $Course['R00_Dest_Kbn'];
            $SearchData['R00_Dest_Code'] = $Course['R00_Dest_Code'];
            $SearchData['R00_Han'] = $Course['R00_Han'];
            $SearchData['R00_Dep_Id'] = $Course['R00_Dep_Id'];
            $SearchData['R00_Air_Program'] = $Course['R00_Air_Program'];
            $SearchResult = $this->menu_mo->getInsuranceList($SearchData);
            $data['SearchResult'] = $SearchResult;
            $CourseDataMaster     = $this->menu_mo->getM01Course($param);
            //M00_Tour_Name取得
            $data['Tour_Name'] = $this->menu_mo->getTourName($Course['R00_Dest_Code']);
            //M011_Flight_Ptn取得
            $data['Flight_Ptn'] = $this->menu_mo->getFlightPtn($param);
            $data['CourseDataMaster'] = $CourseDataMaster[0];
            $this->excelinsurancelist->InsuranceList($data);
        }else{
            redirect(base_url("admin_con"));
        }
    }
}
