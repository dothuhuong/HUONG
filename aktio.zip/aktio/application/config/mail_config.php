<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'SMTP';
//$config['smtp_host'] = '172.20.1.64';
$config['smtp_host'] = '172.20.1.64';
$config['smtp_user'] = '';
$config['smtp_pass'] = '';
$config['smtp_port'] = '25';
